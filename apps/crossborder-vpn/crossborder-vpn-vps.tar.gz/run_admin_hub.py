"""跑量众创跨境公司内部专线 VPN —— 管理员集中管控后台 & 官网下载分发中心启动入口。
支持在 Windows 本机运行，也支持通过 --headless 部署在 Linux VPS 云服务器上 24 小时运行。
"""

from __future__ import annotations

import argparse
import atexit
import json
import os
import sys
import time
import webbrowser
from pathlib import Path

from app import hub_server


def get_base_dir() -> Path:
    if getattr(sys, "frozen", False):
        return Path(sys.executable).resolve().parent
    return Path(__file__).resolve().parent


def _run_cli_action(args: argparse.Namespace, base_dir: Path) -> bool:
    if not (args.set_admin or args.admin_status or args.set_domain is not None):
        return False

    store = hub_server.HubStore(base_dir / "data", base_dir=base_dir)
    if args.stdin_json:
        payload = json.loads(sys.stdin.read() or "{}")
    else:
        payload = {}

    if args.set_admin:
        user = str(payload.get("username") or args.admin_user or "admin").strip()
        pwd = str(payload.get("password") or args.admin_pass or "").strip()
        comp = str(payload.get("company_name") or args.company_name or "").strip()
        store.set_admin_credentials(user, pwd, company_name=comp)
        print(json.dumps({"ok": True, "username": store.state.get("admin_username"), "has_password": bool(store.state.get("admin_password"))}, ensure_ascii=False))
        return True

    if args.admin_status:
        print(
            json.dumps(
                {
                    "ok": True,
                    "company_name": store.state.get("company_name", "跑量众创 · 内部专线 VPN"),
                    "admin_username": store.state.get("admin_username", "admin"),
                    "has_password": bool((store.state.get("admin_password") or "").strip()),
                    "hub_public_url": store.state.get("hub_public_url", ""),
                },
                ensure_ascii=False,
            )
        )
        return True

    if args.set_domain is not None:
        with store._lock:
            store.state["hub_public_url"] = str(args.set_domain or "").strip().rstrip("/")
            store._save_unlocked()
        hub_server.sync_local_release_bundle(base_dir, store.bundle_dat_file)
        print(json.dumps({"ok": True, "hub_public_url": store.state.get("hub_public_url", "")}, ensure_ascii=False))
        return True

    return False


def main() -> None:
    parser = argparse.ArgumentParser(description="跑量众创 · 跨境专线 VPN 管控后台与下载中心")
    parser.add_argument("--browser", action="store_true", help="使用系统默认浏览器打开后台")
    parser.add_argument("--headless", action="store_true", help="无头服务器模式（Linux VPS 部署专用，不打开任何本地窗口）")
    parser.add_argument("--port", type=int, default=int(os.environ.get("VPN_HUB_PORT", "18800")), help="管控后台监听端口 (默认 18800)")
    parser.add_argument("--set-admin", action="store_true", help="设置/重置管理员账号与密码后退出")
    parser.add_argument("--admin-user", default="", help="配合 --set-admin 使用的管理员账号")
    parser.add_argument("--admin-pass", default="", help="配合 --set-admin 使用的管理员密码")
    parser.add_argument("--company-name", default="", help="设置公司名称")
    parser.add_argument("--stdin-json", action="store_true", help="从标准输入读取 JSON 参数")
    parser.add_argument("--admin-status", action="store_true", help="输出当前管理员账号配置状态并退出")
    parser.add_argument("--set-domain", default=None, help="更新主服务公网域名地址 (传空字符串可清空)")
    args = parser.parse_args()

    base_dir = get_base_dir()
    if _run_cli_action(args, base_dir):
        return

    srv = hub_server.HubServerThread(base_dir=base_dir, host="0.0.0.0", port=args.port)
    actual_port = srv.start()
    atexit.register(srv.stop)

    lan_ip = hub_server.get_lan_ip()
    home_url = f"http://{lan_ip}:{actual_port}/"
    admin_url = f"http://{lan_ip}:{actual_port}/admin"
    portal_url = f"http://{lan_ip}:{actual_port}/portal"

    print("=" * 68)
    print("🛡️  跑量众创 · 跨境专线 VPN 云端管控与下载中心已启动！")
    print(f"🌐 公司介绍与客户端下载首页: {home_url}")
    print(f"🔑 管理员登录后台地址: {admin_url} (本机 http://127.0.0.1:{actual_port}/admin)")
    print(f"📱 手机端员工订阅门户: {portal_url}")
    print("=" * 68)

    # Linux VPS 无图形界面时自动进入 headless 模式
    is_linux_headless = sys.platform != "win32" and not os.environ.get("DISPLAY")
    if args.headless or is_linux_headless:
        print("==> 当前运行于 VPS 无头服务器模式 (Headless Server Mode)，按 Ctrl+C 停止服务...")
        try:
            while True:
                time.sleep(3600)
        except KeyboardInterrupt:
            srv.stop()
        return

    local_admin_url = f"http://127.0.0.1:{actual_port}/admin"
    if not args.browser:
        try:
            import webview
            webview.create_window(
                title="跑量众创 · 跨境专线管控与飞书告警后台",
                url=local_admin_url,
                width=1280,
                height=840,
                resizable=True,
            )
            webview.start()
            srv.stop()
            return
        except Exception:
            pass

    webbrowser.open(local_admin_url)
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        srv.stop()


if __name__ == "__main__":
    main()
