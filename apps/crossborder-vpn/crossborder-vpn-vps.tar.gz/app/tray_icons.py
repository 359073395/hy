"""iOS 极简圆角矢量图标生成器（Pillow 超采样抗锯齿渲染）。

四态实时配色：
- idle   : #8E8E93 高级灰（未连接 / 后台待命）
- smart  : #34C759 苹果绿（智能分流已连接）
- global : #007AFF 苹果蓝（全局代理已连接）
- error  : #FF3B30 警示红（节点异常 / 连接失败）
"""

from __future__ import annotations

from pathlib import Path
from typing import Literal

IconState = Literal["idle", "smart", "global", "error"]

STATE_PALETTES: dict[str, tuple[int, int, int]] = {
    "idle": (142, 142, 147),    # #8E8E93
    "smart": (52, 199, 89),     # #34C759
    "global": (0, 122, 255),    # #007AFF
    "error": (255, 59, 48),     # #FF3B30
}


def render_status_icon(state: str = "idle", size: int = 64):
    """生成指定状态的高清透明底 RGBA PIL Image（4 倍超采样抗锯齿）。"""
    from PIL import Image, ImageDraw

    rgb = STATE_PALETTES.get(state, STATE_PALETTES["idle"])
    fill_rgba = (*rgb, 255)
    hi = max(128, size * 4)

    img = Image.new("RGBA", (hi, hi), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)

    # 1. iOS 圆角矩形底板
    pad = round(hi * 0.06)
    radius = round(hi * 0.24)
    draw.rounded_rectangle(
        (pad, pad, hi - pad, hi - pad),
        radius=radius,
        fill=fill_rgba,
    )

    # 2. 纯白简约盾牌轮廓
    cx = hi * 0.5
    shield_pts = [
        (cx, hi * 0.22),
        (hi * 0.72, hi * 0.31),
        (hi * 0.72, hi * 0.49),
        (hi * 0.70, hi * 0.57),
        (hi * 0.65, hi * 0.65),
        (hi * 0.58, hi * 0.72),
        (cx, hi * 0.78),
        (hi * 0.42, hi * 0.72),
        (hi * 0.35, hi * 0.65),
        (hi * 0.30, hi * 0.57),
        (hi * 0.28, hi * 0.49),
        (hi * 0.28, hi * 0.31),
    ]
    draw.polygon(shield_pts, fill=(255, 255, 255, 245))

    # 3. 盾内状态标识（普通/连接为向上专线箭头，异常为感叹号）
    stroke_w = max(4, round(hi * 0.065))
    if state == "error":
        bar_w = max(4, round(hi * 0.072))
        half_bar = bar_w / 2.0
        draw.rounded_rectangle(
            (cx - half_bar, hi * 0.38, cx + half_bar, hi * 0.54),
            radius=round(half_bar),
            fill=fill_rgba,
        )
        dot_r = hi * 0.042
        draw.ellipse(
            (cx - dot_r, hi * 0.61 - dot_r, cx + dot_r, hi * 0.61 + dot_r),
            fill=fill_rgba,
        )
    else:
        top_y = hi * 0.38
        bot_y = hi * 0.62
        wing_y = hi * 0.47
        wing_dx = hi * 0.095
        draw.line([(cx, top_y), (cx, bot_y)], fill=fill_rgba, width=stroke_w)
        draw.line([(cx - wing_dx, wing_y), (cx, top_y), (cx + wing_dx, wing_y)], fill=fill_rgba, width=stroke_w, joint="curve")
        # 补圆头端点让线条更像 SF Symbols
        cap_r = stroke_w * 0.48
        for px, py in ((cx, top_y), (cx, bot_y), (cx - wing_dx, wing_y), (cx + wing_dx, wing_y)):
            draw.ellipse((px - cap_r, py - cap_r, px + cap_r, py + cap_r), fill=fill_rgba)

    resample = Image.Resampling.LANCZOS if hasattr(Image, "Resampling") else Image.LANCZOS
    return img.resize((size, size), resample)


def ensure_app_ico(out_path: Path) -> Path:
    """生成用于 EXE 与 Windows 安装包的多分辨率 .ico 品牌图标。"""
    out_path.parent.mkdir(parents=True, exist_ok=True)
    img = render_status_icon("global", size=256)
    img.save(
        out_path,
        format="ICO",
        sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)],
    )
    return out_path
