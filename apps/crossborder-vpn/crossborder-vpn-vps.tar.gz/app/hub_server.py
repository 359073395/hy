"""跨境公司 VPN 云端管控中心与三端分发服务 (Hub Server)：
- 支持本地运行或部署在 Linux VPS（支持多备用 VPS 与动态导航切换）
- 管理 VLESS / VMess / Trojan / Shadowsocks / Hysteria2 / TUIC / AnyTLS / WireGuard 节点池
- 支持【TCP 端口握手 + Mihomo / Xray-core / sing-box 多核真连接实测】
- 支持【姓名 + 专属激活码】授权、IP 归属地与跨区异常检测、个人飞书安全告警、后台一键封禁（不限设备数）
- 自动生成加密配置包 client_bundle.dat（节点配置加密缓存不落地明文，内置飞书 Webhook 永不掉绑）
"""

from __future__ import annotations

import base64
import concurrent.futures
import datetime
import hashlib
import hmac
import http.cookies
import http.server
import json
import os
import secrets
import shutil
import socket
import threading
import time
import urllib.parse
import urllib.request
import uuid
import zipfile
from pathlib import Path
from typing import Any

import yaml

from app import __version__, core_updater, crypto_store, feishu_notifier, ip_geo, mihomo_engine, node_parser


def get_lan_ip() -> str:
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("223.5.5.5", 80))
            return s.getsockname()[0]
    except Exception:
        return "127.0.0.1"


def _generate_code(prefix: str = "CB") -> str:
    alphabet = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
    token = "".join(secrets.choice(alphabet) for _ in range(6))
    return f"{prefix}-{token}"


class HubStore:
    def __init__(self, data_dir: Path, base_dir: Path | None = None) -> None:
        self.data_dir = data_dir
        self.base_dir = base_dir or data_dir.parent
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.store_file = self.data_dir / "hub_store.json"
        self.bundle_dat_file = self.data_dir / "client_bundle.dat"
        self.legacy_bundle_json = self.data_dir / "client_bundle.json"
        self._lock = threading.Lock()
        self.state: dict[str, Any] = self._load()

        env_user = os.environ.get("VPN_ADMIN_USER", "").strip()
        env_pwd = os.environ.get("VPN_ADMIN_PASSWORD", "").strip()
        env_company = os.environ.get("VPN_COMPANY_NAME", "").strip()
        need_save_init = False
        if not self.state.get("_session_secret"):
            self.state["_session_secret"] = secrets.token_hex(32)
            need_save_init = True
        if env_user and self.state.get("admin_username", "admin") == "admin" and not self.state.get("admin_password"):
            self.state["admin_username"] = env_user
            need_save_init = True
        if env_pwd and not self.state.get("admin_password"):
            self.state["admin_password"] = env_pwd
            need_save_init = True
        if env_company and self.state.get("company_name") in ("", "跨境内部专线 VPN", "跑量众创 · 内部专线 VPN"):
            self.state["company_name"] = env_company
            need_save_init = True

        # 首次初始化时若没有任何激活码，提供一个默认激活码方便立即测试（可随时在后台删除或封禁）
        groups = self.state.setdefault("groups", {})
        if "default" not in groups or not isinstance(groups.get("default"), dict):
            groups["default"] = {
                "id": "default",
                "name": "全区通用组",
                "allowed_regions": [],
                "description": "默认允许访问公司全部地区专线（勾选列表为空代表不限制）",
            }
            need_save_init = True

        if not self.state.get("auth_codes"):
            now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            self.state["auth_codes"] = {
                "CB-2026": {
                    "code": "CB-2026",
                    "employee_name": "默认体验码(可改名或删除)",
                    "department": "全体默认",
                    "group_id": "default",
                    "status": "active",
                    "created_at": now_str,
                    "last_seen": "",
                    "login_ips": [],
                    "regions_seen": [],
                    "anomaly_flag": False,
                    "anomaly_reason": "",
                }
            }
            self._save_unlocked()
        elif need_save_init:
            self._save_unlocked()
        else:
            self._sync_bundle_unlocked()

    def set_admin_credentials(self, username: str, password: str, company_name: str = "") -> None:
        with self._lock:
            clean_user = str(username or "").strip() or "admin"
            clean_pwd = str(password or "").strip()
            self.state["admin_username"] = clean_user
            if clean_pwd:
                self.state["admin_password"] = clean_pwd
            if str(company_name or "").strip():
                self.state["company_name"] = str(company_name).strip()
            self._save_unlocked()

    def _default_state(self) -> dict[str, Any]:
        return {
            "company_name": "跑量众创 · 内部专线 VPN",
            "notice": "遇到连接异常系统会自动通知管理员处理",
            "feishu_webhook": "",
            "feishu_secret": "",
            "hub_public_url": "",
            "backup_hub_urls": "",
            "discovery_url": "",
            "admin_username": "admin",
            "admin_password": "",
            "_session_secret": secrets.token_hex(32),
            "app_version": __version__,
            "app_changelog": "初始化稳定版",
            "app_download_url": "",
            "app_force_update": False,
            "nodes": [],
            "groups": {
                "default": {
                    "id": "default",
                    "name": "全区通用组",
                    "allowed_regions": [],
                    "description": "默认允许访问公司全部地区专线（勾选列表为空代表不限制）",
                }
            },
            "auth_codes": {},
            "employees": {},
            "failure_reports": [],
        }

    def _load(self) -> dict[str, Any]:
        if not self.store_file.exists():
            return self._default_state()
        try:
            data = json.loads(self.store_file.read_text(encoding="utf-8"))
            base = self._default_state()
            base.update(data)
            return base
        except Exception:
            return self._default_state()

    def save(self) -> None:
        with self._lock:
            self._save_unlocked()

    def _save_unlocked(self) -> None:
        self.store_file.write_text(
            json.dumps(self.state, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
        self._sync_bundle_unlocked()

    def _sync_bundle_unlocked(self) -> None:
        """同步生成加密内置包 data/client_bundle.dat（不留明文 client_bundle.json）。"""
        bundle = {
            "company_name": self.state.get("company_name", "跨境内部专线 VPN"),
            "notice": self.state.get("notice", ""),
            "hub_url": self.state.get("hub_public_url", ""),
            "backup_hub_urls": self.state.get("backup_hub_urls", ""),
            "discovery_url": self.state.get("discovery_url", ""),
            "feishu_webhook": self.state.get("feishu_webhook", ""),
            "feishu_secret": self.state.get("feishu_secret", ""),
            "updated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "nodes": self.state.get("nodes", []),
        }
        crypto_store.save_encrypted_file(self.bundle_dat_file, bundle)
        if self.legacy_bundle_json.exists():
            try:
                self.legacy_bundle_json.unlink()
            except Exception:
                pass

    def write_embedded_secrets_py(self) -> Path:
        """将当前个人飞书 Webhook、密钥、主/备 VPS 地址及初始配置加密写入 app/embedded_secrets.py，
        供 PyInstaller 彻底编译进 CompanyVPN.exe 字节码本体，保证飞书永不掉绑。
        """
        bundle = {
            "company_name": self.state.get("company_name", "跨境内部专线 VPN"),
            "notice": self.state.get("notice", ""),
            "hub_url": self.state.get("hub_public_url", ""),
            "backup_hub_urls": self.state.get("backup_hub_urls", ""),
            "discovery_url": self.state.get("discovery_url", ""),
            "feishu_webhook": self.state.get("feishu_webhook", ""),
            "feishu_secret": self.state.get("feishu_secret", ""),
            "updated_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "nodes": self.state.get("nodes", []),
        }
        token = crypto_store.encrypt_json(bundle)
        target = self.base_dir / "app" / "embedded_secrets.py"
        content = (
            '"""编译期植入 EXE 本体的加密绑定配置（由 build.ps1 或管理后台自动写入）。"""\n\n'
            f'EMBEDDED_BUNDLE_TOKEN = "{token}"\n'
        )
        target.write_text(content, encoding="utf-8")
        return target

    def import_nodes(self, raw_text: str, explicit_region: str = "") -> tuple[int, list[dict[str, Any]]]:
        text = raw_text.strip()
        if not text:
            return 0, []

        if text.startswith(("http://", "https://")) and "\n" not in text and " " not in text:
            req = urllib.request.Request(text, headers={"User-Agent": "clash.meta/1.19 sing-box/1.10"})
            with urllib.request.urlopen(req, timeout=15) as resp:
                text = resp.read().decode("utf-8", errors="ignore")

        parsed_list = node_parser.parse_batch_nodes(text, explicit_region=explicit_region)
        if not parsed_list:
            return 0, []

        with self._lock:
            existing: list[dict[str, Any]] = self.state.get("nodes", [])
            by_id = {n["id"]: n for n in existing if isinstance(n, dict) and n.get("id")}
            added = 0
            now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
            for item in parsed_list:
                item["created_at"] = now_str
                if item["id"] not in by_id:
                    added += 1
                by_id[item["id"]] = item
            self.state["nodes"] = node_parser.deduplicate_node_names(list(by_id.values()))
            self._save_unlocked()
            return added if added > 0 else len(parsed_list), parsed_list

    def delete_node(self, node_id: str) -> bool:
        with self._lock:
            before = len(self.state.get("nodes", []))
            if node_id == "__ALL__":
                self.state["nodes"] = []
            else:
                self.state["nodes"] = [n for n in self.state.get("nodes", []) if n.get("id") != node_id]
            after = len(self.state["nodes"])
            self._save_unlocked()
            return after < before or node_id == "__ALL__"

    def update_node_region(self, node_id: str, new_region: str) -> bool:
        with self._lock:
            for n in self.state.get("nodes", []):
                if n.get("id") == node_id:
                    n["region"] = node_parser.detect_region(n.get("name", ""), n.get("server", ""), new_region)
                    self._save_unlocked()
                    return True
        return False

    def update_node_core(self, node_id: str, preferred_core: str) -> bool:
        with self._lock:
            for n in self.state.get("nodes", []):
                if n.get("id") == node_id:
                    n["preferred_core"] = preferred_core if preferred_core in ("auto", "xray", "sing-box", "mihomo") else "auto"
                    self._save_unlocked()
                    return True
        return False

    def check_nodes_connectivity(
        self,
        node_id: str | None = None,
        test_url: str = "http://cp.cloudflare.com/generate_204",
    ) -> list[dict[str, Any]]:
        all_nodes = list(self.state.get("nodes", []))
        target_nodes = [n for n in all_nodes if n.get("id") == node_id] if node_id else all_nodes
        if not target_nodes:
            return all_nodes

        def _probe_tcp(n: dict[str, Any]) -> tuple[str, int, str]:
            srv = str(n.get("server", ""))
            port = int(n.get("port", 0))
            ptype = str(n.get("type", "")).lower()
            net = str(n.get("network", "tcp")).lower()
            t0 = time.perf_counter()
            try:
                with socket.create_connection((srv, port), timeout=2.5):
                    ms = int((time.perf_counter() - t0) * 1000)
                    return n["id"], ms, f"TCP正常 ({ms}ms)"
            except Exception as exc:
                if ptype in ("hysteria2", "hy2", "tuic", "wireguard") or net in ("kcp", "quic"):
                    return n["id"], -2, "UDP协议 (以真连接为准)"
                return n["id"], -1, f"TCP不通: {exc}"

        tcp_results: dict[str, tuple[int, str]] = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=min(16, max(1, len(target_nodes)))) as pool:
            for nid, ms, msg in pool.map(_probe_tcp, target_nodes):
                tcp_results[nid] = (ms, msg)

        real_results, id_core_map = mihomo_engine.test_nodes_real_connection(
            base_dir=self.base_dir,
            nodes=target_nodes,
            test_url=test_url,
            timeout_ms=4500,
        )

        now_str = datetime.datetime.now().strftime("%H:%M:%S")
        with self._lock:
            for n in self.state.get("nodes", []):
                nid = n.get("id")
                if nid in tcp_results:
                    t_ms, t_msg = tcp_results[nid]
                    n["tcp_delay"] = t_ms
                    n["tcp_status"] = t_msg
                if nid in real_results:
                    r_ms, r_msg = real_results[nid]
                    n["real_delay"] = r_ms
                    n["real_status"] = r_msg
                    n["active_core"] = id_core_map.get(nid, "mihomo")
                    n["last_delay"] = r_ms
                    n["last_status"] = r_msg
                if nid in tcp_results or nid in real_results:
                    n["last_check"] = now_str
            self._save_unlocked()
            return list(self.state.get("nodes", []))

    def check_all_nodes_tcp(self) -> list[dict[str, Any]]:
        return self.check_nodes_connectivity(node_id=None)

    # ---------------- 用户分组与地区权限隔离 ----------------

    def save_group(
        self,
        name: str,
        allowed_regions: list[str] | None = None,
        group_id: str = "",
        description: str = "",
    ) -> dict[str, Any]:
        clean_name = (name or "").strip() or "未命名分组"
        regions = [str(r).strip() for r in (allowed_regions or []) if str(r).strip()]
        with self._lock:
            groups = self.state.setdefault("groups", {})
            gid = (group_id or "").strip() or f"grp-{secrets.token_hex(3)}"
            rec = {
                "id": gid,
                "name": clean_name,
                "allowed_regions": regions,
                "description": (description or "").strip(),
            }
            groups[gid] = rec
            self._save_unlocked()
            return rec

    def delete_group(self, group_id: str) -> bool:
        gid = (group_id or "").strip()
        if not gid or gid == "default":
            return False
        with self._lock:
            groups = self.state.get("groups", {})
            if gid not in groups:
                return False
            del groups[gid]
            for c_rec in self.state.get("auth_codes", {}).values():
                if c_rec.get("group_id") == gid:
                    c_rec["group_id"] = "default"
            self._save_unlocked()
            return True

    def set_code_group(self, code: str, group_id: str) -> bool:
        norm = (code or "").strip().upper()
        gid = (group_id or "").strip() or "default"
        with self._lock:
            codes = self.state.get("auth_codes", {})
            if norm not in codes:
                return False
            if gid not in self.state.get("groups", {}):
                gid = "default"
            codes[norm]["group_id"] = gid
            self._save_unlocked()
            return True

    def get_group_for_code(self, code: str) -> tuple[str, str, list[str]]:
        norm = (code or "").strip().upper()
        groups = self.state.get("groups", {})
        rec = self.state.get("auth_codes", {}).get(norm, {})
        gid = str(rec.get("group_id") or "default").strip() or "default"
        grp = groups.get(gid) or groups.get("default") or {"id": "default", "name": "全区通用组", "allowed_regions": []}
        return grp.get("id", "default"), grp.get("name", "全区通用组"), list(grp.get("allowed_regions") or [])

    def get_nodes_for_code(self, code: str) -> list[dict[str, Any]]:
        norm = (code or "").strip().upper()
        rec = self.state.get("auth_codes", {}).get(norm)
        if not rec or rec.get("status") == "banned":
            return []
        _gid, _gname, allowed = self.get_group_for_code(norm)
        all_nodes = list(self.state.get("nodes", []))
        if not allowed:
            return all_nodes
        allowed_set = set(allowed)
        return [n for n in all_nodes if n.get("region") in allowed_set]

    # ---------------- 员工激活码与异地异常检测 ----------------

    def create_auth_code(
        self,
        employee_name: str,
        department: str = "",
        custom_code: str = "",
        group_id: str = "default",
    ) -> dict[str, Any]:
        code = (custom_code or _generate_code()).strip().upper()
        gid = (group_id or "").strip() or "default"
        if gid not in self.state.get("groups", {}):
            gid = "default"
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        rec = {
            "code": code,
            "employee_name": employee_name.strip() or "未指定员工",
            "department": department.strip() or "运营部",
            "group_id": gid,
            "status": "active",
            "created_at": now_str,
            "last_seen": "",
            "login_ips": [],
            "regions_seen": [],
            "anomaly_flag": False,
            "anomaly_reason": "",
        }
        with self._lock:
            self.state.setdefault("auth_codes", {})[code] = rec
            self._save_unlocked()
        return rec

    def toggle_ban_code(self, code: str, ban: bool) -> bool:
        norm = (code or "").strip().upper()
        with self._lock:
            rec = self.state.get("auth_codes", {}).get(norm)
            if not rec:
                return False
            rec["status"] = "banned" if ban else "active"
            if not ban:
                rec["anomaly_flag"] = False
                rec["anomaly_reason"] = ""
            self._save_unlocked()
            return True

    def delete_auth_code(self, code: str) -> bool:
        norm = (code or "").strip().upper()
        with self._lock:
            codes = self.state.get("auth_codes", {})
            if norm in codes:
                del codes[norm]
                self._save_unlocked()
                return True
        return False

    def verify_and_track_code(
        self,
        code: str,
        employee_name: str = "",
        device: str = "",
        platform_name: str = "Windows",
        current_region: str = "",
        ip_addr: str = "",
    ) -> tuple[bool, bool, str]:
        """校验激活码有效性并记录登录 IP 与归属地。
        返回: (allowed, is_banned, error_message)
        """
        norm_code = (code or "").strip().upper()
        if not norm_code:
            return False, False, "请输入您的专属激活码"

        codes: dict[str, Any] = self.state.get("auth_codes", {})
        rec = codes.get(norm_code)
        if not rec:
            return False, False, "激活码无效，请联系管理员核实"
        if rec.get("status") == "banned":
            return False, True, "该激活码已被管理员封禁停用，请联系管理员"

        region_key, full_geo = ip_geo.lookup_ip_geo(ip_addr)
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        security_alert_to_send: tuple[str, str] | None = None

        with self._lock:
            rec = self.state["auth_codes"][norm_code]
            if rec.get("status") == "banned":
                return False, True, "该激活码已被管理员封禁停用，请联系管理员"

            rec["last_seen"] = now_str
            ips: list[dict[str, Any]] = rec.setdefault("login_ips", [])
            existing_ip = next((x for x in ips if x.get("ip") == ip_addr), None)
            if existing_ip:
                existing_ip["last_seen"] = now_str
                existing_ip["location"] = full_geo
                existing_ip["device"] = device or existing_ip.get("device", "")
                existing_ip["employee_input"] = employee_name or existing_ip.get("employee_input", "")
            else:
                ips.insert(
                    0,
                    {
                        "ip": ip_addr,
                        "location": full_geo,
                        "region_key": region_key,
                        "device": device,
                        "employee_input": employee_name,
                        "last_seen": now_str,
                    },
                )
                rec["login_ips"] = ips[:25]

            regions_seen: list[str] = rec.setdefault("regions_seen", [])
            if region_key not in ("内网/本机", "未知地区") and region_key not in regions_seen:
                regions_seen.append(region_key)
                if len(regions_seen) >= 2:
                    rec["anomaly_flag"] = True
                    rec["anomaly_reason"] = f"检测到跨地区使用: {' / '.join(regions_seen)}"
                    security_alert_to_send = (
                        f"⚠️ 跨境VPN异常使用告警 ({rec.get('employee_name')} / {norm_code})",
                        (
                            f"**👤 激活码归属：** {rec.get('employee_name')} (`{norm_code}`)\n"
                            f"**✍️ 当前使用人输入：** {employee_name or '-'}\n"
                            f"**🌍 本次登录归属地：** {full_geo} (`{ip_addr}`)\n"
                            f"**🚨 异常原因：** {rec['anomaly_reason']}\n"
                            f"**👉 建议操作：** 若确认存在外传给外人使用，请在管理后台一键封禁 `{norm_code}`"
                        ),
                    )

            # 同步更新员工终端活跃表
            emp_key = f"{employee_name.strip() or rec.get('employee_name')} ({norm_code})"
            emps = self.state.setdefault("employees", {})
            emp_rec = emps.get(emp_key, {})
            emp_rec.update(
                {
                    "employee": employee_name.strip() or rec.get("employee_name"),
                    "code": norm_code,
                    "device": device or emp_rec.get("device") or platform_name,
                    "platform": platform_name or emp_rec.get("platform") or "Windows",
                    "current_region": current_region or emp_rec.get("current_region") or "⚡ 自动最快地区",
                    "ip_addr": ip_addr,
                    "ip_location": full_geo,
                    "last_seen": now_str,
                    "first_seen": emp_rec.get("first_seen") or now_str,
                }
            )
            emps[emp_key] = emp_rec
            self._save_unlocked()

        if security_alert_to_send:
            webhook = str(self.state.get("feishu_webhook") or "").strip()
            secret = str(self.state.get("feishu_secret") or "").strip()
            if webhook:
                title, details = security_alert_to_send
                threading.Thread(
                    target=feishu_notifier.send_feishu_security_alert,
                    args=(webhook, title, details, secret),
                    daemon=True,
                ).start()

        return True, False, ""

    def register_employee(
        self,
        employee: str,
        device: str = "",
        platform_name: str = "Windows",
        current_region: str = "",
        ip_addr: str = "",
    ) -> dict[str, Any]:
        emp_key = employee.strip() or "未命名员工"
        _, full_geo = ip_geo.lookup_ip_geo(ip_addr)
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with self._lock:
            emps = self.state.setdefault("employees", {})
            rec = emps.get(emp_key, {})
            rec.update(
                {
                    "employee": emp_key,
                    "device": device or rec.get("device") or platform_name,
                    "platform": platform_name or rec.get("platform") or "Windows",
                    "current_region": current_region or rec.get("current_region") or "⚡ 自动最快地区",
                    "ip_addr": ip_addr or rec.get("ip_addr") or "",
                    "ip_location": full_geo,
                    "last_seen": now_str,
                    "first_seen": rec.get("first_seen") or now_str,
                }
            )
            emps[emp_key] = rec
            self._save_unlocked()
            return rec

    def add_failure_report(self, payload: dict[str, Any], push_feishu: bool = True) -> dict[str, Any]:
        now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        employee = str(payload.get("employee") or "未知员工").strip()
        device = str(payload.get("device") or "未知设备").strip()
        region = str(payload.get("region") or "未指定地区").strip()
        node_name = str(payload.get("node_name") or "").strip()
        protocol = str(payload.get("protocol") or "").strip()
        server_addr = str(payload.get("server_addr") or "").strip()
        reason = str(payload.get("reason") or "").strip()
        user_note = str(payload.get("user_note") or "自动检测连接失败上报").strip()

        if not reason or not server_addr:
            nodes = self.state.get("nodes", [])
            candidates = [n for n in nodes if n.get("region") == region] or nodes
            if candidates:
                target_n = candidates[0]
                node_name = node_name or str(target_n.get("name", ""))
                protocol = protocol or str(target_n.get("type", ""))
                server_addr = server_addr or f"{target_n.get('server')}:{target_n.get('port')}"
                if not reason:
                    diag = feishu_notifier.diagnose_node_failure(
                        str(target_n.get("server", "")),
                        int(target_n.get("port", 443)),
                        protocol=protocol,
                    )
                    reason = diag.get("summary", "连接超时")

        report: dict[str, Any] = {
            "id": uuid.uuid4().hex[:10],
            "employee": employee,
            "device": device,
            "region": region,
            "node_name": node_name or f"{region}节点组",
            "protocol": protocol or "auto",
            "server_addr": server_addr or "-",
            "reason": reason or "节点连接超时或真连接握手失败",
            "user_note": user_note,
            "status": "pending",
            "feishu_pushed": False,
            "feishu_msg": "",
            "created_at": now_str,
        }

        webhook = str(self.state.get("feishu_webhook") or "").strip()
        secret = str(self.state.get("feishu_secret") or "").strip()
        if payload.get("already_pushed_feishu"):
            report["feishu_pushed"] = True
            report["feishu_msg"] = "已由员工客户端直连推送至飞书"
        elif push_feishu and webhook:
            ok, msg = feishu_notifier.send_feishu_alert(webhook, report, secret=secret)
            report["feishu_pushed"] = ok
            report["feishu_msg"] = msg

        with self._lock:
            reports: list[dict[str, Any]] = self.state.setdefault("failure_reports", [])
            reports.insert(0, report)
            self.state["failure_reports"] = reports[:200]
            self._save_unlocked()
        return report


def sync_local_release_bundle(base_dir: Path, bundle_dat_file: Path) -> tuple[bool, str]:
    """将最新加密的 client_bundle.dat 同步到 release/CompanyVPN/data/ 并更新分发 zip。"""
    stage_dir = base_dir / "release" / "CompanyVPN"
    if not stage_dir.is_dir() or not bundle_dat_file.is_file():
        return False, "当前未检测到本地 release/CompanyVPN 目录（仅本地 Windows 打包后可用；VPS 请直接下载加密包）"

    dst_data = stage_dir / "data"
    dst_data.mkdir(parents=True, exist_ok=True)
    shutil.copy2(bundle_dat_file, dst_data / "client_bundle.dat")
    legacy_json = dst_data / "client_bundle.json"
    if legacy_json.exists():
        try:
            legacy_json.unlink()
        except Exception:
            pass

    zip_path = base_dir / "release" / "CompanyVPN-员工一键客户端-win64.zip"
    try:
        with zipfile.ZipFile(zip_path, "w", compression=zipfile.ZIP_DEFLATED) as zf:
            for item in stage_dir.rglob("*"):
                if item.is_file():
                    zf.write(item, arcname=item.relative_to(stage_dir))
        return True, "已将最新个人飞书绑定、VPS地址与加密节点同步进本地发布包 (CompanyVPN-员工一键客户端-win64.zip)！"
    except Exception as exc:
        return True, f"已更新 release/CompanyVPN/data/client_bundle.dat（压缩包更新跳过: {exc}）"


def create_hub_handler(store: HubStore, static_dir: Path):
    build_state: dict[str, Any] = {"running": False, "ok": None, "message": ""}

    class HubRequestHandler(http.server.BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args: Any) -> None:
            return

        def _get_real_client_ip(self) -> str:
            xff = (self.headers.get("X-Forwarded-For") or "").split(",")[0].strip()
            if xff:
                return xff
            xri = (self.headers.get("X-Real-IP") or "").strip()
            if xri:
                return xri
            return self.client_address[0]

        def _admin_creds(self) -> tuple[str, str, str]:
            req_user = str(store.state.get("admin_username") or "admin").strip() or "admin"
            req_pwd = str(store.state.get("admin_password") or "").strip()
            secret = str(store.state.get("_session_secret") or "cbvpn-fallback-secret")
            return req_user, req_pwd, secret

        def _make_admin_token(self, username: str, password: str, secret: str) -> str:
            exp = int(time.time()) + 7 * 86400
            msg = f"{username}:{exp}".encode("utf-8")
            key = hashlib.sha256(f"{secret}:{username}:{password}".encode("utf-8")).digest()
            sig = hmac.new(key, msg, hashlib.sha256).hexdigest()
            return base64.urlsafe_b64encode(f"{username}:{exp}:{sig}".encode("utf-8")).decode("ascii")

        def _verify_admin_token(self, token: str) -> bool:
            if not token:
                return False
            req_user, req_pwd, secret = self._admin_creds()
            if not req_pwd:
                return True
            try:
                decoded = base64.urlsafe_b64decode(token.encode("ascii")).decode("utf-8")
                user, exp_str, sig = decoded.rsplit(":", 2)
                if int(exp_str) < int(time.time()):
                    return False
                if not hmac.compare_digest(user, req_user):
                    return False
                msg = f"{user}:{exp_str}".encode("utf-8")
                key = hashlib.sha256(f"{secret}:{req_user}:{req_pwd}".encode("utf-8")).digest()
                expected = hmac.new(key, msg, hashlib.sha256).hexdigest()
                return hmac.compare_digest(sig, expected)
            except Exception:
                return False

        def _check_admin_auth(self, body: dict[str, Any] | None = None) -> bool:
            req_user, req_pwd, _secret = self._admin_creds()
            if not req_pwd:
                return True
            header_token = (self.headers.get("X-Admin-Token") or "").strip()
            if self._verify_admin_token(header_token):
                return True
            cookie_header = self.headers.get("Cookie") or ""
            if cookie_header:
                try:
                    c = http.cookies.SimpleCookie()
                    c.load(cookie_header)
                    if "vpn_admin_token" in c and self._verify_admin_token(c["vpn_admin_token"].value):
                        return True
                except Exception:
                    pass
            header_user = (self.headers.get("X-Admin-Username") or "").strip()
            header_pwd = (self.headers.get("X-Admin-Password") or "").strip()
            if header_pwd and hmac.compare_digest(header_pwd, req_pwd):
                if not header_user or hmac.compare_digest(header_user, req_user):
                    return True
            auth_hdr = (self.headers.get("Authorization") or "").strip()
            if auth_hdr.lower().startswith("basic "):
                try:
                    b_user, b_pwd = base64.b64decode(auth_hdr[6:].strip()).decode("utf-8").split(":", 1)
                    if hmac.compare_digest(b_user, req_user) and hmac.compare_digest(b_pwd, req_pwd):
                        return True
                except Exception:
                    pass
            if body and str(body.get("_admin_password") or "").strip() == req_pwd:
                b_user = str(body.get("_admin_username") or "").strip()
                if not b_user or hmac.compare_digest(b_user, req_user):
                    return True
            parsed = urllib.parse.urlparse(self.path)
            qs = urllib.parse.parse_qs(parsed.query)
            if (qs.get("pwd") or [""])[0] == req_pwd:
                q_user = (qs.get("user") or [""])[0].strip()
                if not q_user or hmac.compare_digest(q_user, req_user):
                    return True
            self._send_json(
                {
                    "ok": False,
                    "auth_required": True,
                    "has_admin_password": True,
                    "error": "请输入管理员账号和密码登录",
                },
                status=401,
            )
            return False

        def _send_json(self, data: Any, status: int = 200, extra_headers: dict[str, str] | None = None) -> None:
            raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header(
                "Access-Control-Allow-Headers",
                "Content-Type, X-Admin-Password, X-Admin-Username, X-Admin-Token, Authorization",
            )
            self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
            if extra_headers:
                for k, v in extra_headers.items():
                    self.send_header(k, v)
            self.end_headers()
            self.wfile.write(raw)

        def _send_text(
            self,
            text: str,
            content_type: str = "text/html; charset=utf-8",
            status: int = 200,
            extra_headers: dict[str, str] | None = None,
        ) -> None:
            raw = text.encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(len(raw)))
            self.send_header("Access-Control-Allow-Origin", "*")
            if extra_headers:
                for k, v in extra_headers.items():
                    self.send_header(k, v)
            self.end_headers()
            self.wfile.write(raw)

        def _read_json_body(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0:
                return {}
            raw = self.rfile.read(length).decode("utf-8", errors="ignore")
            try:
                return json.loads(raw)
            except Exception:
                return {}

        def _verify_mobile_sub_code(self, qs: dict[str, list[str]], ua: str) -> bool:
            code = (qs.get("code") or [""])[0].strip()
            emp = (qs.get("emp") or ["手机员工"])[0].strip()
            plat = "iPhone/iOS" if any(k in ua for k in ("iPhone", "iPad", "iOS", "Shadowrocket", "Stash")) else "Android"
            allowed, _banned, err = store.verify_and_track_code(
                code=code,
                employee_name=emp,
                device=ua[:48],
                platform_name=plat,
                ip_addr=self._get_real_client_ip(),
            )
            if not allowed:
                self._send_text(err, content_type="text/plain; charset=utf-8", status=403)
                return False
            return True

        def _stream_file(self, file_path: Path, download_name: str, content_type: str = "application/octet-stream") -> None:
            size = file_path.stat().st_size
            self.send_response(200)
            self.send_header("Content-Type", content_type)
            self.send_header("Content-Length", str(size))
            self.send_header("Content-Disposition", f'attachment; filename="{download_name}"')
            self.end_headers()
            with file_path.open("rb") as fp:
                while True:
                    chunk = fp.read(65536)
                    if not chunk:
                        break
                    self.wfile.write(chunk)

        def _resolve_download_files(self) -> tuple[Path | None, Path | None]:
            zip_uploaded = store.data_dir / "latest_client" / "CompanyVPN-win64.zip"
            zip_local = store.base_dir / "release" / "CompanyVPN-员工一键客户端-win64.zip"
            zip_file = zip_uploaded if (zip_uploaded.is_file() and zip_uploaded.stat().st_size > 1000) else (
                zip_local if (zip_local.is_file() and zip_local.stat().st_size > 1000) else None
            )
            exe_uploaded = store.data_dir / "latest_client" / "CompanyVPN.exe"
            exe_local = store.base_dir / "release" / "CompanyVPN" / "CompanyVPN.exe"
            exe_file = exe_uploaded if (exe_uploaded.is_file() and exe_uploaded.stat().st_size > 1000) else (
                exe_local if (exe_local.is_file() and exe_local.stat().st_size > 1000) else None
            )
            return zip_file, exe_file

        def do_OPTIONS(self) -> None:
            self._send_json({"ok": True})

        def do_GET(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            qs = urllib.parse.parse_qs(parsed.query)

            if path in ("/", "/index.html"):
                html = (static_dir / "index.html").read_text(encoding="utf-8")
                self._send_text(html)
                return

            if path in ("/admin", "/admin/", "/admin/login"):
                html = (static_dir / "admin.html").read_text(encoding="utf-8")
                self._send_text(html)
                return

            if path in ("/portal", "/m"):
                html = (static_dir / "portal.html").read_text(encoding="utf-8")
                self._send_text(html)
                return

            if path == "/api/public/site_info":
                nodes = store.state.get("nodes", [])
                grouped = node_parser.group_nodes_by_region(nodes)
                regions_summary = [{"region": r, "count": len(r_nodes)} for r, r_nodes in grouped.items()]
                zip_file, exe_file = self._resolve_download_files()
                core_dir = mihomo_engine.get_core_dir(store.base_dir)
                c_status = core_updater.get_core_status(core_dir)
                self._send_json(
                    {
                        "ok": True,
                        "company_name": store.state.get("company_name", "跑量众创 · 内部专线 VPN"),
                        "notice": store.state.get("notice", ""),
                        "app_version": store.state.get("app_version", __version__),
                        "app_changelog": store.state.get("app_changelog", ""),
                        "has_zip": zip_file is not None,
                        "zip_size_mb": round(zip_file.stat().st_size / (1024 * 1024), 2) if zip_file else 0,
                        "zip_download_url": "/download/CompanyVPN-win64.zip" if zip_file else "",
                        "has_exe": exe_file is not None,
                        "exe_size_mb": round(exe_file.stat().st_size / (1024 * 1024), 2) if exe_file else 0,
                        "exe_download_url": "/download/CompanyVPN.exe" if exe_file else "",
                        "custom_download_url": str(store.state.get("app_download_url") or "").strip(),
                        "regions": regions_summary,
                        "total_nodes": len(nodes),
                        "core_ready": c_status["ready"],
                        "portal_url": "/portal",
                        "admin_url": "/admin",
                    }
                )
                return

            if path == "/api/admin/overview":
                if not self._check_admin_auth():
                    return
                nodes = store.state.get("nodes", [])
                grouped = node_parser.group_nodes_by_region(nodes)
                regions_summary = [{"region": r, "count": len(r_nodes)} for r, r_nodes in grouped.items()]
                lan_ip = get_lan_ip()
                host_header = self.headers.get("Host") or f"{lan_ip}:18800"
                if host_header.startswith(("127.0.0.1", "localhost")) and lan_ip != "127.0.0.1":
                    port_part = host_header.split(":", 1)[1] if ":" in host_header else "18800"
                    lan_base = f"http://{lan_ip}:{port_part}"
                else:
                    lan_base = f"http://{host_header}"
                public_base = (store.state.get("hub_public_url") or "").strip().rstrip("/") or lan_base
                core_dir = mihomo_engine.get_core_dir(store.base_dir)
                c_status = core_updater.get_core_status(core_dir)
                exe_uploaded = store.data_dir / "latest_client" / "CompanyVPN.exe"
                zip_uploaded = store.data_dir / "latest_client" / "CompanyVPN-win64.zip"

                groups_map = store.state.get("groups", {})
                enriched_codes = []
                for c_item in store.state.get("auth_codes", {}).values():
                    gid = str(c_item.get("group_id") or "default")
                    grp = groups_map.get(gid) or groups_map.get("default") or {"name": "全区通用组"}
                    copy_item = dict(c_item)
                    copy_item["group_id"] = gid
                    copy_item["group_name"] = grp.get("name", "全区通用组")
                    enriched_codes.append(copy_item)

                self._send_json(
                    {
                        "ok": True,
                        "company_name": store.state.get("company_name", "跑量众创 · 内部专线 VPN"),
                        "notice": store.state.get("notice", ""),
                        "feishu_webhook": store.state.get("feishu_webhook", ""),
                        "feishu_secret": store.state.get("feishu_secret", ""),
                        "hub_public_url": store.state.get("hub_public_url", ""),
                        "backup_hub_urls": store.state.get("backup_hub_urls", ""),
                        "discovery_url": store.state.get("discovery_url", ""),
                        "app_version": store.state.get("app_version", __version__),
                        "app_changelog": store.state.get("app_changelog", ""),
                        "app_download_url": store.state.get("app_download_url", ""),
                        "app_has_uploaded_exe": exe_uploaded.is_file(),
                        "app_has_uploaded_zip": zip_uploaded.is_file(),
                        "exe_size_mb": round(exe_uploaded.stat().st_size / (1024 * 1024), 2) if exe_uploaded.is_file() else 0,
                        "zip_size_mb": round(zip_uploaded.stat().st_size / (1024 * 1024), 2) if zip_uploaded.is_file() else 0,
                        "admin_username": store.state.get("admin_username", "admin"),
                        "has_admin_password": bool((store.state.get("admin_password") or "").strip()),
                        "core_ready": c_status["ready"],
                        "core_status": c_status,
                        "effective_hub_url": public_base,
                        "portal_url": f"{public_base}/portal",
                        "supported_regions": node_parser.get_supported_regions(),
                        "nodes": nodes,
                        "regions": regions_summary,
                        "groups": list(groups_map.values()),
                        "auth_codes": enriched_codes,
                        "employees": list(store.state.get("employees", {}).values()),
                        "failure_reports": store.state.get("failure_reports", []),
                    }
                )
                return

            if path in ("/api/admin/export_bundle", "/api/admin/export_encrypted_bundle"):
                if not self._check_admin_auth():
                    return
                bundle_text = store.bundle_dat_file.read_text(encoding="utf-8")
                self._send_text(
                    bundle_text,
                    content_type="application/octet-stream",
                    extra_headers={"Content-Disposition": 'attachment; filename="client_bundle.dat"'},
                )
                return

            if path == "/api/client/version":
                exe_file = store.data_dir / "latest_client" / "CompanyVPN.exe"
                custom_dl = str(store.state.get("app_download_url") or "").strip()
                has_exe = exe_file.is_file() and exe_file.stat().st_size > 1000
                dl_url = custom_dl or ("/api/client/download_exe" if has_exe else "")
                self._send_json(
                    {
                        "ok": True,
                        "version": store.state.get("app_version", __version__),
                        "changelog": store.state.get("app_changelog", ""),
                        "download_url": dl_url,
                        "has_package": bool(dl_url),
                        "force_update": bool(store.state.get("app_force_update", False)),
                    }
                )
                return

            if path in ("/api/client/download_exe", "/download/CompanyVPN.exe"):
                _zip_file, exe_file = self._resolve_download_files()
                if not exe_file:
                    self._send_json({"ok": False, "error": "服务端暂未上传新版客户端 EXE，请管理员在后台上传发布包"}, status=404)
                    return
                self._stream_file(exe_file, "CompanyVPN.exe")
                return

            if path in ("/api/client/download_zip", "/download/CompanyVPN-win64.zip", "/download/client_zip"):
                zip_file, _exe_file = self._resolve_download_files()
                if not zip_file:
                    self._send_json({"ok": False, "error": "服务端暂未上传员工客户端压缩包，请管理员在 /admin 后台上传发布"}, status=404)
                    return
                self._stream_file(zip_file, "CompanyVPN-win64.zip", content_type="application/zip")
                return

            if path == "/api/sub/clash":
                ua = self.headers.get("User-Agent", "Mobile")
                if not self._verify_mobile_sub_code(qs, ua):
                    return
                sub_code = (qs.get("code") or [""])[0].strip()
                cfg = node_parser.build_mihomo_config(
                    store.get_nodes_for_code(sub_code),
                    routing_mode=(qs.get("mode") or ["smart"])[0],
                    tun_enabled=True,
                )
                yaml_text = yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False)
                self._send_text(
                    yaml_text,
                    content_type="text/yaml; charset=utf-8",
                    extra_headers={
                        "profile-update-interval": "12",
                        "subscription-userinfo": "upload=0; download=0; total=1073741824000; expire=0",
                    },
                )
                return

            if path == "/api/sub/singbox":
                ua = self.headers.get("User-Agent", "Mobile")
                if not self._verify_mobile_sub_code(qs, ua):
                    return
                sub_code = (qs.get("code") or [""])[0].strip()
                sb_cfg = node_parser.build_singbox_config(
                    store.get_nodes_for_code(sub_code),
                    routing_mode=(qs.get("mode") or ["smart"])[0],
                )
                self._send_text(
                    json.dumps(sb_cfg, ensure_ascii=False, indent=2),
                    content_type="application/json; charset=utf-8",
                )
                return

            if path == "/api/sub/raw":
                ua = self.headers.get("User-Agent", "Mobile")
                if not self._verify_mobile_sub_code(qs, ua):
                    return
                sub_code = (qs.get("code") or [""])[0].strip()
                uris = [str(n.get("raw_uri", "")).strip() for n in store.get_nodes_for_code(sub_code) if n.get("raw_uri")]
                b64_text = base64.b64encode("\n".join(uris).encode("utf-8")).decode("utf-8")
                self._send_text(b64_text, content_type="text/plain; charset=utf-8")
                return

            self._send_json({"ok": False, "error": "Not found"}, status=404)

        def do_POST(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            path = parsed.path
            qs = urllib.parse.parse_qs(parsed.query)

            # 二进制上传新版客户端（支持 .exe 单文件或 .zip 完整压缩包）
            if path in ("/api/admin/upload_client_exe", "/api/admin/upload_client_package"):
                if not self._check_admin_auth():
                    return
                length = int(self.headers.get("Content-Length") or 0)
                if length < 1000 or length > 260 * 1024 * 1024:
                    self._send_json({"ok": False, "error": "上传文件大小异常"}, status=400)
                    return
                dest_dir = store.data_dir / "latest_client"
                dest_dir.mkdir(parents=True, exist_ok=True)
                tmp_file = dest_dir / "upload_client.tmp"
                remaining = length
                with tmp_file.open("wb") as fp:
                    while remaining > 0:
                        chunk = self.rfile.read(min(65536, remaining))
                        if not chunk:
                            break
                        fp.write(chunk)
                        remaining -= len(chunk)
                with tmp_file.open("rb") as fp:
                    header_bytes = fp.read(2)
                ver = (qs.get("version") or [__version__])[0].strip() or __version__
                changelog = urllib.parse.unquote((qs.get("changelog") or ["性能优化与功能更新"])[0]).strip()
                saved_type = ""
                extracted_exe = False
                final_size = tmp_file.stat().st_size

                if header_bytes == b"MZ":
                    final_exe = dest_dir / "CompanyVPN.exe"
                    tmp_file.replace(final_exe)
                    saved_type = "exe"
                elif header_bytes == b"PK":
                    try:
                        with zipfile.ZipFile(tmp_file, "r") as zf:
                            infos = zf.infolist()
                            total_uncompressed = sum(i.file_size for i in infos)
                            if total_uncompressed > 600 * 1024 * 1024:
                                raise ValueError("压缩包解压体积超限")
                            exe_member = None
                            for info in infos:
                                if info.is_dir():
                                    continue
                                norm = info.filename.replace("\\", "/")
                                if norm.startswith("/") or ".." in norm.split("/"):
                                    raise ValueError("压缩包包含非法路径")
                                if norm.lower().endswith("companyvpn.exe"):
                                    exe_member = info
                            if exe_member is not None:
                                exe_bytes = zf.read(exe_member)
                                if exe_bytes[:2] == b"MZ":
                                    (dest_dir / "CompanyVPN.exe").write_bytes(exe_bytes)
                                    extracted_exe = True
                        final_zip = dest_dir / "CompanyVPN-win64.zip"
                        tmp_file.replace(final_zip)
                        saved_type = "zip"
                    except Exception as exc:
                        tmp_file.unlink(missing_ok=True)
                        self._send_json({"ok": False, "error": f"压缩包校验失败: {exc}"}, status=400)
                        return
                else:
                    tmp_file.unlink(missing_ok=True)
                    self._send_json(
                        {"ok": False, "error": "仅支持上传 Windows .exe 或员工打包 .zip 文件"},
                        status=400,
                    )
                    return

                with store._lock:
                    store.state["app_version"] = ver
                    store.state["app_changelog"] = changelog
                    store.state["app_download_url"] = ""
                    store._save_unlocked()
                self._send_json(
                    {
                        "ok": True,
                        "type": saved_type,
                        "extracted_exe": extracted_exe,
                        "version": ver,
                        "size_mb": round(final_size / (1024 * 1024), 2),
                    }
                )
                return

            body = self._read_json_body()

            if path == "/api/admin/login":
                req_user, req_pwd, secret = self._admin_creds()
                if not req_pwd:
                    token = self._make_admin_token(req_user, "", secret)
                    self._send_json({"ok": True, "token": token, "username": req_user, "no_password": True})
                    return
                in_user = str(body.get("username") or "").strip()
                in_pwd = str(body.get("password") or "").strip()
                if hmac.compare_digest(in_user, req_user) and hmac.compare_digest(in_pwd, req_pwd):
                    token = self._make_admin_token(req_user, req_pwd, secret)
                    self._send_json(
                        {"ok": True, "token": token, "username": req_user},
                        extra_headers={"Set-Cookie": f"vpn_admin_token={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800"},
                    )
                else:
                    self._send_json({"ok": False, "error": "管理员账号或密码错误"}, status=401)
                return

            if path == "/api/admin/logout":
                self._send_json(
                    {"ok": True},
                    extra_headers={"Set-Cookie": "vpn_admin_token=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"},
                )
                return

            if path.startswith("/api/admin/"):
                if not self._check_admin_auth(body):
                    return

            if path == "/api/admin/nodes/import":
                raw_text = str(body.get("raw_text") or "")
                region = str(body.get("region") or "")
                try:
                    count, _items = store.import_nodes(raw_text, explicit_region=region)
                    if count == 0:
                        self._send_json(
                            {
                                "ok": False,
                                "error": "未识别到有效节点，请确认粘贴的是 vless://, vmess://, trojan://, ss://, hy2:// 链接或 Clash YAML",
                            }
                        )
                        return
                    self._send_json({"ok": True, "added": count, "total": len(store.state.get("nodes", []))})
                except Exception as exc:
                    self._send_json({"ok": False, "error": f"导入失败: {exc}"})
                return

            if path == "/api/admin/nodes/delete":
                store.delete_node(str(body.get("id") or ""))
                self._send_json({"ok": True})
                return

            if path == "/api/admin/nodes/update_region":
                ok = store.update_node_region(str(body.get("id") or ""), str(body.get("region") or ""))
                self._send_json({"ok": ok})
                return

            if path == "/api/admin/nodes/update_core":
                ok = store.update_node_core(str(body.get("id") or ""), str(body.get("preferred_core") or "auto"))
                self._send_json({"ok": ok})
                return

            if path == "/api/admin/cores/download":
                try:
                    from app import win_proxy
                    core_dir = mihomo_engine.get_core_dir(store.base_dir)
                    res = core_updater.download_all_cores(core_dir, proxy_url=win_proxy.get_active_proxy_url())
                    self._send_json(res)
                except Exception as exc:
                    self._send_json({"ok": False, "error": f"内核下载失败: {exc}"})
                return

            if path in ("/api/admin/nodes/check_all", "/api/admin/nodes/check"):
                target_id = str(body.get("id") or "").strip() or None
                test_url = str(body.get("test_url") or "http://cp.cloudflare.com/generate_204").strip()
                nodes = store.check_nodes_connectivity(node_id=target_id, test_url=test_url)
                self._send_json({"ok": True, "nodes": nodes})
                return

            if path == "/api/admin/groups/save":
                gid = str(body.get("id") or "").strip()
                name = str(body.get("name") or "").strip()
                if not name:
                    self._send_json({"ok": False, "error": "请填写分组名称"})
                    return
                allowed_regions = body.get("allowed_regions") or []
                if not isinstance(allowed_regions, list):
                    allowed_regions = []
                desc = str(body.get("description") or "").strip()
                grp = store.save_group(name=name, allowed_regions=allowed_regions, group_id=gid, description=desc)
                self._send_json({"ok": True, "group": grp})
                return

            if path == "/api/admin/groups/delete":
                gid = str(body.get("id") or "").strip()
                if gid == "default":
                    self._send_json({"ok": False, "error": "默认分组不可删除"})
                    return
                ok = store.delete_group(gid)
                self._send_json({"ok": ok})
                return

            if path == "/api/admin/codes/create":
                emp_name = str(body.get("employee_name") or "").strip()
                dept = str(body.get("department") or "").strip()
                custom_code = str(body.get("code") or "").strip()
                group_id = str(body.get("group_id") or "default").strip() or "default"
                if not emp_name:
                    self._send_json({"ok": False, "error": "请填写员工姓名或备注"})
                    return
                rec = store.create_auth_code(
                    employee_name=emp_name,
                    department=dept,
                    custom_code=custom_code,
                    group_id=group_id,
                )
                self._send_json({"ok": True, "code": rec})
                return

            if path == "/api/admin/codes/set_group":
                code = str(body.get("code") or "").strip()
                group_id = str(body.get("group_id") or "default").strip() or "default"
                ok = store.set_code_group(code, group_id)
                self._send_json({"ok": ok})
                return

            if path == "/api/admin/codes/toggle_ban":
                ok = store.toggle_ban_code(str(body.get("code") or ""), bool(body.get("ban", True)))
                self._send_json({"ok": ok})
                return

            if path == "/api/admin/codes/delete":
                ok = store.delete_auth_code(str(body.get("code") or ""))
                self._send_json({"ok": ok})
                return

            if path == "/api/admin/sync_release_bundle":
                ok, msg = sync_local_release_bundle(store.base_dir, store.bundle_dat_file)
                self._send_json({"ok": ok, "message": msg})
                return

            if path == "/api/admin/build_exe_status":
                self._send_json({"ok": True, **build_state})
                return

            if path == "/api/admin/build_exe":
                import sys, subprocess
                if sys.platform != "win32":
                    self._send_json({"ok": False, "error": "仅支持在本地 Windows 电脑后台一键编译 .exe"})
                    return
                if not str(store.state.get("feishu_webhook") or "").strip():
                    self._send_json({"ok": False, "error": "请先在上方填写并保存您的个人飞书 Webhook 地址！"})
                    return
                if build_state["running"]:
                    self._send_json({"ok": True, "started": False, "message": "正在编译打包中，请稍候..."})
                    return

                build_state["running"] = True
                build_state["ok"] = None
                build_state["message"] = "正在把飞书绑定写入 EXE 源码并编译..."

                def _run_build() -> None:
                    try:
                        store.write_embedded_secrets_py()
                        proc = subprocess.run(
                            ["powershell", "-ExecutionPolicy", "Bypass", "-File", str(store.base_dir / "build.ps1"), "-SkipTests"],
                            cwd=str(store.base_dir),
                            capture_output=True,
                            text=True,
                            encoding="utf-8",
                            errors="replace",
                            timeout=300,
                        )
                        if proc.returncode == 0:
                            build_state["ok"] = True
                            build_state["message"] = "编译成功！您的个人飞书已彻底植入 release/CompanyVPN/CompanyVPN.exe 与分发压缩包中！"
                        else:
                            tail = (proc.stderr or proc.stdout or "")[-300:]
                            build_state["ok"] = False
                            build_state["message"] = f"编译失败（请先关闭正在运行的 CompanyVPN.exe 窗口后再试）：{tail}"
                    except Exception as exc:
                        build_state["ok"] = False
                        build_state["message"] = f"编译异常: {exc}"
                    finally:
                        build_state["running"] = False

                threading.Thread(target=_run_build, daemon=True).start()
                self._send_json({"ok": True, "started": True, "message": "已开始把飞书彻底编译植入 CompanyVPN.exe，大约需要 15 秒..."})
                return

            if path == "/api/admin/settings":
                new_token = ""
                with store._lock:
                    for field in (
                        "company_name",
                        "notice",
                        "feishu_webhook",
                        "feishu_secret",
                        "hub_public_url",
                        "backup_hub_urls",
                        "discovery_url",
                    ):
                        if field in body:
                            store.state[field] = str(body[field] or "").strip()
                    creds_changed = False
                    if "admin_username" in body and str(body["admin_username"] or "").strip():
                        new_u = str(body["admin_username"]).strip()
                        if new_u != store.state.get("admin_username", "admin"):
                            store.state["admin_username"] = new_u
                            creds_changed = True
                    if body.get("clear_admin_password"):
                        store.state["admin_password"] = ""
                        creds_changed = True
                    elif "admin_password" in body and body["admin_password"] is not None:
                        pwd_val = str(body["admin_password"]).strip()
                        if pwd_val:
                            store.state["admin_password"] = pwd_val
                            creds_changed = True
                    store._save_unlocked()
                    if creds_changed and store.state.get("admin_password"):
                        req_user, req_pwd, secret = self._admin_creds()
                        new_token = self._make_admin_token(req_user, req_pwd, secret)
                sync_local_release_bundle(store.base_dir, store.bundle_dat_file)
                resp_payload: dict[str, Any] = {"ok": True, "message": "设置已保存并已加密写入客户端分发包"}
                extra_hdrs = None
                if new_token:
                    resp_payload["token"] = new_token
                    extra_hdrs = {"Set-Cookie": f"vpn_admin_token={new_token}; Path=/; HttpOnly; SameSite=Lax; Max-Age=604800"}
                self._send_json(resp_payload, extra_headers=extra_hdrs)
                return

            if path == "/api/admin/feishu/test":
                webhook = str(body.get("feishu_webhook") or store.state.get("feishu_webhook") or "").strip()
                secret = str(body.get("feishu_secret") or store.state.get("feishu_secret") or "").strip()
                test_report = {
                    "is_test": True,
                    "employee": "管理员测试 (张三-东南亚运营)",
                    "device": "Windows 11 / 管理员后台",
                    "region": "🇮🇩 印度尼西亚",
                    "node_name": "印尼-雅加达主力01",
                    "protocol": "VLESS",
                    "server_addr": "id-jkt.example.com:443",
                    "reason": "这是一条测试通知：当公司任何员工在 Windows、Android 或 iPhone 连接节点失败时，系统都会通过国内直连网络把具体报错员工、节点和诊断结论推送到这里！",
                    "user_note": "后台点击「发送测试飞书告警」",
                }
                ok, msg = feishu_notifier.send_feishu_alert(webhook, test_report, secret=secret)
                self._send_json({"ok": ok, "message": msg})
                return

            if path == "/api/admin/reports/resolve":
                rep_id = str(body.get("id") or "")
                with store._lock:
                    if rep_id == "__CLEAR_ALL__":
                        store.state["failure_reports"] = []
                    else:
                        for r in store.state.get("failure_reports", []):
                            if r.get("id") == rep_id:
                                r["status"] = "resolved"
                    store._save_unlocked()
                self._send_json({"ok": True})
                return

            if path == "/api/client/bootstrap":
                employee = str(body.get("employee") or "").strip()
                act_code = str(body.get("activation_code") or body.get("code") or "").strip()
                device = str(body.get("device") or "").strip()
                platform_name = str(body.get("platform") or "Windows").strip()
                current_region = str(body.get("current_region") or "").strip()

                allowed, is_banned, err_msg = store.verify_and_track_code(
                    code=act_code,
                    employee_name=employee,
                    device=device,
                    platform_name=platform_name,
                    current_region=current_region,
                    ip_addr=self._get_real_client_ip(),
                )
                if not allowed:
                    self._send_json({"ok": False, "banned": is_banned, "error": err_msg}, status=403)
                    return

                nodes = store.get_nodes_for_code(act_code)
                gid, gname, allowed_regions = store.get_group_for_code(act_code)
                grouped = node_parser.group_nodes_by_region(nodes)
                regions = [{"region": r, "count": len(r_nodes)} for r, r_nodes in grouped.items()]

                raw_payload = {
                    "company_name": store.state.get("company_name", "跑量众创 · 内部专线 VPN"),
                    "notice": store.state.get("notice", ""),
                    "hub_url": store.state.get("hub_public_url", ""),
                    "backup_hub_urls": store.state.get("backup_hub_urls", ""),
                    "discovery_url": store.state.get("discovery_url", ""),
                    "feishu_webhook": store.state.get("feishu_webhook", ""),
                    "feishu_secret": store.state.get("feishu_secret", ""),
                    "group_id": gid,
                    "group_name": gname,
                    "allowed_regions": allowed_regions,
                    "nodes": nodes,
                    "regions": regions,
                }
                # 既返回加密包字符串（供客户端加密缓存落盘），也返回脱敏后的地区列表供手机端 H5 门户渲染
                self._send_json(
                    {
                        "ok": True,
                        "encrypted_bundle": crypto_store.encrypt_json(raw_payload),
                        "company_name": raw_payload["company_name"],
                        "group_id": gid,
                        "group_name": gname,
                        "regions": regions,
                    }
                )
                return

            if path == "/api/client/report":
                rep = store.add_failure_report(body, push_feishu=True)
                self._send_json(
                    {
                        "ok": True,
                        "report": rep,
                        "message": "故障已反馈给管理员" + ("（已实时推送至管理员飞书）" if rep.get("feishu_pushed") else ""),
                    }
                )
                return

            self._send_json({"ok": False, "error": "Unknown endpoint"}, status=404)

    return HubRequestHandler


class HubServerThread:
    def __init__(self, base_dir: Path, host: str = "0.0.0.0", port: int = 18800) -> None:
        self.base_dir = base_dir
        self.host = host
        self.port = port
        self.store = HubStore(base_dir / "data", base_dir=base_dir)
        import sys
        meipass = getattr(sys, "_MEIPASS", None)
        candidate_static = (Path(meipass) if meipass else base_dir) / "app" / "static"
        if not candidate_static.is_dir():
            candidate_static = Path(__file__).resolve().parent / "static"
        self.static_dir = candidate_static
        self._httpd: http.server.ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    def start(self) -> int:
        handler_cls = create_hub_handler(self.store, self.static_dir)
        self._httpd = http.server.ThreadingHTTPServer((self.host, self.port), handler_cls)
        self.port = self._httpd.server_address[1]
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()
        return self.port

    def stop(self) -> None:
        if self._httpd:
            self._httpd.shutdown()
            self._httpd.server_close()
            self._httpd = None
