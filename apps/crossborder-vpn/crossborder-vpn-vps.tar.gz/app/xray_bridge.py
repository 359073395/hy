"""Xray-core 与 sing-box 双桥接模块（借鉴并扩展自 Warp Relay Panel）：
- 为 mKCP / QUIC / VLESS 加密 / XHTTP(extra) / Reality 等 Xray 专属或优选节点提供 Xray-core 本地 SOCKS5 桥接
- 为指定使用 sing-box 内核的节点提供 sing-box 本地 SOCKS5 桥接
- 由 Mihomo 统一接管顶层地区 url-test 自动容灾分组、分流规则与 TUN/系统代理
"""

from __future__ import annotations

import copy
import json
import socket
import subprocess
import sys
import tempfile
import time
import uuid
from pathlib import Path
from typing import Any, Callable

from app import core_updater, node_parser


def _build_stream_settings(node: dict[str, Any]) -> dict[str, Any]:
    net = str(node.get("network") or "tcp").lower()
    stream: dict[str, Any] = {}

    if net == "ws":
        wopts = node.get("ws-opts") or {}
        if wopts.get("v2ray-http-upgrade"):
            stream["network"] = "httpupgrade"
            hu: dict[str, Any] = {"path": str(wopts.get("path") or "/")}
            host = (wopts.get("headers") or {}).get("Host")
            if host:
                hu["host"] = str(host)
            stream["httpupgradeSettings"] = hu
        else:
            stream["network"] = "ws"
            ws: dict[str, Any] = {"path": str(wopts.get("path") or "/")}
            headers = wopts.get("headers") or {}
            if headers:
                ws["headers"] = dict(headers)
            stream["wsSettings"] = ws
    elif net == "xhttp":
        xopts = node.get("xhttp-opts") or {}
        stream["network"] = "xhttp"
        xs: dict[str, Any] = {"path": str(xopts.get("path") or "/")}
        if xopts.get("host"):
            xs["host"] = str(xopts["host"])
        if xopts.get("mode"):
            xs["mode"] = str(xopts["mode"])
        if xopts.get("extra"):
            xs["extra"] = xopts["extra"]
        stream["xhttpSettings"] = xs
    elif net == "kcp":
        kopts = node.get("kcp-opts") or {}
        stream["network"] = "kcp"
        ks: dict[str, Any] = {
            "header": {"type": str(kopts.get("header-type") or "none")},
        }
        if kopts.get("seed"):
            ks["seed"] = str(kopts["seed"])
        stream["kcpSettings"] = ks
    elif net == "quic":
        qopts = node.get("quic-opts") or {}
        stream["network"] = "quic"
        stream["quicSettings"] = {
            "security": str(qopts.get("security") or "none"),
            "key": str(qopts.get("key") or ""),
            "header": {"type": str(qopts.get("header-type") or "none")},
        }
    elif net == "grpc":
        gopts = node.get("grpc-opts") or {}
        stream["network"] = "grpc"
        stream["grpcSettings"] = {
            "serviceName": str(gopts.get("grpc-service-name") or ""),
        }
    elif net == "h2":
        hopts = node.get("h2-opts") or {}
        stream["network"] = "h2"
        stream["httpSettings"] = {
            "path": str(hopts.get("path") or "/"),
            "host": list(hopts.get("host") or []),
        }
    elif net == "http":
        hopts = node.get("http-opts") or {}
        stream["network"] = "tcp"
        paths = hopts.get("path") or ["/"]
        headers = hopts.get("headers") or {}
        stream["tcpSettings"] = {
            "header": {
                "type": "http",
                "request": {
                    "path": paths if isinstance(paths, list) else [str(paths)],
                    "headers": headers,
                },
            }
        }
    else:
        stream["network"] = "tcp"

    ropts = node.get("reality-opts")
    if isinstance(ropts, dict) and ropts.get("public-key"):
        stream["security"] = "reality"
        stream["realitySettings"] = {
            "publicKey": str(ropts["public-key"]),
            "shortId": str(ropts.get("short-id") or ""),
            "serverName": str(node.get("servername") or node.get("sni") or ""),
            "fingerprint": str(node.get("client-fingerprint") or "chrome"),
            "spiderX": str(ropts.get("spider-x") or ""),
        }
    elif node.get("tls") or node.get("type") == "trojan":
        stream["security"] = "tls"
        tls_cfg: dict[str, Any] = {}
        sni = node.get("servername") or node.get("sni")
        if sni:
            tls_cfg["serverName"] = str(sni)
        if node.get("skip-cert-verify"):
            tls_cfg["allowInsecure"] = True
        if node.get("client-fingerprint"):
            tls_cfg["fingerprint"] = str(node["client-fingerprint"])
        if node.get("alpn"):
            tls_cfg["alpn"] = list(node["alpn"])
        stream["tlsSettings"] = tls_cfg
    else:
        stream["security"] = "none"

    return stream


def build_xray_outbound(node: dict[str, Any], tag: str) -> dict[str, Any]:
    ptype = str(node.get("type") or "").lower()
    server = str(node.get("server") or "")
    port = int(node.get("port") or 0)
    stream = _build_stream_settings(node)

    if ptype == "vless":
        user: dict[str, Any] = {
            "id": str(node.get("uuid") or ""),
            "encryption": str(node.get("encryption") or "none"),
        }
        if node.get("flow"):
            user["flow"] = str(node["flow"])
        return {
            "tag": tag,
            "protocol": "vless",
            "settings": {"vnext": [{"address": server, "port": port, "users": [user]}]},
            "streamSettings": stream,
        }

    if ptype == "vmess":
        return {
            "tag": tag,
            "protocol": "vmess",
            "settings": {
                "vnext": [
                    {
                        "address": server,
                        "port": port,
                        "users": [
                            {
                                "id": str(node.get("uuid") or ""),
                                "alterId": int(node.get("alterId") or 0),
                                "security": str(node.get("cipher") or "auto"),
                            }
                        ],
                    }
                ]
            },
            "streamSettings": stream,
        }

    if ptype == "trojan":
        return {
            "tag": tag,
            "protocol": "trojan",
            "settings": {
                "servers": [
                    {
                        "address": server,
                        "port": port,
                        "password": str(node.get("password") or ""),
                    }
                ]
            },
            "streamSettings": stream,
        }

    if ptype == "ss":
        return {
            "tag": tag,
            "protocol": "shadowsocks",
            "settings": {
                "servers": [
                    {
                        "address": server,
                        "port": port,
                        "method": str(node.get("cipher") or ""),
                        "password": str(node.get("password") or ""),
                    }
                ]
            },
            "streamSettings": stream,
        }

    raise ValueError(f"Xray 桥接暂不支持协议类型: {ptype}")


def build_xray_bridge_config(entries: list[tuple[str, int, dict[str, Any]]]) -> dict[str, Any]:
    inbounds: list[dict[str, Any]] = []
    outbounds: list[dict[str, Any]] = []
    rules: list[dict[str, Any]] = []

    for idx, (tag, port, node) in enumerate(entries):
        in_tag = f"in_{idx}"
        inbounds.append(
            {
                "tag": in_tag,
                "listen": "127.0.0.1",
                "port": port,
                "protocol": "socks",
                "settings": {"auth": "noauth", "udp": True},
            }
        )
        outbounds.append(build_xray_outbound(node, tag))
        rules.append(
            {
                "type": "field",
                "inboundTag": [in_tag],
                "outboundTag": tag,
            }
        )

    return {
        "log": {"loglevel": "warning"},
        "inbounds": inbounds,
        "outbounds": outbounds,
        "routing": {"domainStrategy": "AsIs", "rules": rules},
    }


def build_singbox_bridge_config(entries: list[tuple[str, int, dict[str, Any]]]) -> dict[str, Any]:
    inbounds: list[dict[str, Any]] = []
    outbounds: list[dict[str, Any]] = []
    rules: list[dict[str, Any]] = []

    for idx, (tag, port, node) in enumerate(entries):
        in_tag = f"sb_in_{idx}"
        inbounds.append(
            {
                "type": "socks",
                "tag": in_tag,
                "listen": "127.0.0.1",
                "listen_port": port,
            }
        )
        outbounds.append(node_parser.convert_node_to_singbox_outbound(node, tag_override=tag))
        rules.append(
            {
                "inbound": [in_tag],
                "outbound": tag,
            }
        )

    outbounds.append({"type": "direct", "tag": "direct"})
    return {
        "log": {"level": "warn"},
        "inbounds": inbounds,
        "outbounds": outbounds,
        "route": {"rules": rules, "final": "direct"},
    }


class MultiCoreBridgeProcess:
    """同时管理 Xray-core 与 sing-box 本地 SOCKS5 桥接子进程。"""

    def __init__(
        self,
        core_dir: Path,
        xray_entries: list[tuple[str, int, dict[str, Any]]],
        singbox_entries: list[tuple[str, int, dict[str, Any]]],
    ) -> None:
        self.core_dir = core_dir
        self.xray_entries = xray_entries
        self.singbox_entries = singbox_entries
        self._procs: list[subprocess.Popen[Any]] = []
        self._temp_files: list[Path] = []
        self._log_fps: list[Any] = []

    def start(self, proxy_url: str | None = None) -> None:
        core_abs = self.core_dir.resolve()
        tmp_abs = Path(tempfile.gettempdir())
        uid = uuid.uuid4().hex[:8]
        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        expected_ports: list[int] = []
        created_logs: list[Path] = []

        try:
            if self.xray_entries:
                xray_exe = core_updater.ensure_xray_exe(core_abs, proxy_url=proxy_url).resolve()
                x_cfg = build_xray_bridge_config(self.xray_entries)
                x_cfg_file = tmp_abs / f"xray_bridge_{uid}.json"
                x_log_file = tmp_abs / f"xray_bridge_{uid}.log"
                x_cfg_file.write_text(json.dumps(x_cfg, ensure_ascii=False, indent=2), encoding="utf-8")
                self._temp_files.extend([x_cfg_file, x_log_file])
                created_logs.append(x_log_file)

                x_fp = open(x_log_file, "w", encoding="utf-8", errors="replace")
                self._log_fps.append(x_fp)
                p_xray = subprocess.Popen(
                    [str(xray_exe), "run", "-c", str(x_cfg_file)],
                    cwd=str(core_abs),
                    stdout=x_fp,
                    stderr=subprocess.STDOUT,
                    creationflags=creation_flags,
                )
                self._procs.append(p_xray)
                expected_ports.extend(port for _, port, _ in self.xray_entries)

            if self.singbox_entries:
                sb_exe = core_updater.ensure_singbox_exe(core_abs, proxy_url=proxy_url).resolve()
                sb_cfg = build_singbox_bridge_config(self.singbox_entries)
                sb_cfg_file = tmp_abs / f"singbox_bridge_{uid}.json"
                sb_log_file = tmp_abs / f"singbox_bridge_{uid}.log"
                sb_cfg_file.write_text(json.dumps(sb_cfg, ensure_ascii=False, indent=2), encoding="utf-8")
                self._temp_files.extend([sb_cfg_file, sb_log_file])
                created_logs.append(sb_log_file)

                sb_fp = open(sb_log_file, "w", encoding="utf-8", errors="replace")
                self._log_fps.append(sb_fp)
                p_sb = subprocess.Popen(
                    [str(sb_exe), "run", "-c", str(sb_cfg_file)],
                    cwd=str(core_abs),
                    stdout=sb_fp,
                    stderr=subprocess.STDOUT,
                    creationflags=creation_flags,
                )
                self._procs.append(p_sb)
                expected_ports.extend(port for _, port, _ in self.singbox_entries)

            def _read_err_tail() -> str:
                chunks: list[str] = []
                for lf in created_logs:
                    try:
                        txt = lf.read_text(encoding="utf-8", errors="ignore").strip()
                        if txt:
                            chunks.append(txt.splitlines()[-1][:140])
                    except Exception:
                        pass
                return " | ".join(chunks)

            deadline = time.time() + 8.0
            while time.time() < deadline:
                for p in self._procs:
                    if p.poll() is not None:
                        err_detail = _read_err_tail()
                        self.stop()
                        raise RuntimeError(f"多核桥接子进程退出: {err_detail}" if err_detail else "多核桥接子进程 (Xray / sing-box) 启动异常退出")
                all_up = True
                for port in expected_ports:
                    try:
                        with socket.create_connection(("127.0.0.1", port), timeout=0.25):
                            pass
                    except OSError:
                        all_up = False
                        break
                if all_up:
                    return
                time.sleep(0.12)

            err_detail = _read_err_tail()
            self.stop()
            raise RuntimeError(f"多核桥接端口启动超时: {err_detail}" if err_detail else "多核桥接端口启动超时")
        except Exception:
            self.stop()
            raise

    def stop(self) -> None:
        while self._procs:
            p = self._procs.pop()
            try:
                p.terminate()
                p.wait(timeout=3)
            except Exception:
                try:
                    p.kill()
                except Exception:
                    pass
        while self._log_fps:
            fp = self._log_fps.pop()
            try:
                fp.close()
            except Exception:
                pass
        while self._temp_files:
            f = self._temp_files.pop()
            try:
                f.unlink(missing_ok=True)
            except Exception:
                pass


def prepare_proxies_with_multicore(
    core_dir: Path,
    proxies: list[dict[str, Any]],
    pick_port_fn: Callable[[int], int],
    base_port: int = 18200,
    force_core: str | None = None,
) -> tuple[list[dict[str, Any]], MultiCoreBridgeProcess | None, dict[str, str]]:
    """根据每个节点的协议特征或指定的 preferred_core，将需要 Xray-core 或 sing-box 拨号的节点
    自动转换为本地 SOCKS5 桥接节点，并返回:
      (转换后的 Mihomo proxies 列表, MultiCoreBridgeProcess 实例, {node_name: 实际使用的内核名})
    """
    status = core_updater.get_core_status(core_dir)
    has_xray = status["has_xray"]
    has_singbox = status["has_singbox"]

    xray_entries: list[tuple[str, int, dict[str, Any]]] = []
    singbox_entries: list[tuple[str, int, dict[str, Any]]] = []
    out_proxies: list[dict[str, Any]] = []
    core_map: dict[str, str] = {}
    used_ports: set[int] = set()
    next_port = base_port

    def _alloc_port() -> int:
        nonlocal next_port
        p = pick_port_fn(next_port)
        while p in used_ports:
            next_port = p + 1
            p = pick_port_fn(next_port)
        used_ports.add(p)
        next_port = p + 1
        return p

    for idx, raw_p in enumerate(proxies):
        p = copy.deepcopy(raw_p)
        pname = str(p.get("name") or f"node_{idx}")
        if force_core:
            p["preferred_core"] = force_core

        chosen_core = node_parser.resolve_effective_core(p, has_xray=has_xray, has_singbox=has_singbox)
        core_map[pname] = chosen_core

        if chosen_core == "xray" and node_parser.is_xray_supported_protocol(p) and has_xray:
            port = _alloc_port()
            tag = f"xr_{idx}"
            xray_entries.append((tag, port, p))
            out_proxies.append(
                {
                    "name": pname,
                    "type": "socks5",
                    "server": "127.0.0.1",
                    "port": port,
                    "udp": True,
                }
            )
        elif chosen_core == "sing-box" and node_parser.is_singbox_supported_protocol(p) and has_singbox:
            port = _alloc_port()
            tag = f"sb_{idx}"
            singbox_entries.append((tag, port, p))
            out_proxies.append(
                {
                    "name": pname,
                    "type": "socks5",
                    "server": "127.0.0.1",
                    "port": port,
                    "udp": True,
                }
            )
        else:
            core_map[pname] = "mihomo"
            out_proxies.append(node_parser._strip_internal_fields(p))

    if not xray_entries and not singbox_entries:
        return out_proxies, None, core_map
    return out_proxies, MultiCoreBridgeProcess(core_dir, xray_entries, singbox_entries), core_map
