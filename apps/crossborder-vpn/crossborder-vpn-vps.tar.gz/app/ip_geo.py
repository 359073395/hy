"""IP 归属地轻量级解析与缓存模块（用于识别员工激活码是否存在异地/跨省/海外异常使用）。"""

from __future__ import annotations

import ipaddress
import json
import threading
import urllib.request

_CACHE: dict[str, tuple[str, str]] = {}
_LOCK = threading.Lock()


def is_private_or_local_ip(ip: str) -> bool:
    try:
        addr = ipaddress.ip_address(ip.strip())
        return addr.is_private or addr.is_loopback or addr.is_link_local
    except Exception:
        return True


def lookup_ip_geo(ip: str) -> tuple[str, str]:
    """返回 (省/地区短标签如 '广东' 或 '内网', 完整归属地描述如 '中国 广东 深圳')。
    带内存缓存与 1.5s 超时保护，绝不阻塞主业务流程。
    """
    clean_ip = (ip or "").strip()
    if not clean_ip or is_private_or_local_ip(clean_ip):
        return "内网/本机", "公司局域网 / 本机"

    with _LOCK:
        if clean_ip in _CACHE:
            return _CACHE[clean_ip]

    region_key = "未知地区"
    full_label = clean_ip
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

    try:
        url = f"http://ip-api.com/json/{clean_ip}?fields=status,country,regionName,city,isp&lang=zh-CN"
        req = urllib.request.Request(url, headers={"User-Agent": "CrossBorderVPN/2.0"})
        with opener.open(req, timeout=1.5) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="ignore"))
        if data.get("status") == "success":
            country = str(data.get("country") or "").strip()
            prov = str(data.get("regionName") or "").strip()
            city = str(data.get("city") or "").strip()
            isp = str(data.get("isp") or "").strip()
            region_key = f"{country}-{prov}" if prov else (country or "未知")
            parts = [p for p in (country, prov, city) if p]
            full_label = " ".join(parts) + (f" ({isp})" if isp else "")
    except Exception:
        pass

    with _LOCK:
        _CACHE[clean_ip] = (region_key, full_label)
    return region_key, full_label
