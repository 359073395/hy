"""个人飞书自定义机器人告警模块 & 故障原因自动诊断器。
核心设计：所有上报请求强制使用 ProxyHandler({}) 绕过系统代理直连发送，
确保即使员工代理连接失败或系统代理异常，故障报告依然能 100% 送达管理员个人飞书。
"""

from __future__ import annotations

import base64
import datetime
import hashlib
import hmac
import json
import platform
import socket
import time
import urllib.error
import urllib.request
from typing import Any


def _make_feishu_sign(timestamp: int, secret: str) -> str:
    """生成飞书自定义机器人签名校验串（当用户开启签名校验时使用）。"""
    string_to_sign = f"{timestamp}\n{secret}"
    hmac_code = hmac.new(string_to_sign.encode("utf-8"), digestmod=hashlib.sha256).digest()
    return base64.b64encode(hmac_code).decode("utf-8")


def diagnose_node_failure(server: str, port: int, protocol: str = "vless", timeout: float = 3.0) -> dict[str, Any]:
    """当节点连接失败时，自动在本地进行直连网络与节点端口诊断，定位具体原因。"""
    # 1. 检查本地国内基础网络是否正常（连接阿里 DNS 223.5.5.5:53）
    local_net_ok = False
    try:
        with socket.create_connection(("223.5.5.5", 53), timeout=2.0):
            local_net_ok = True
    except Exception:
        local_net_ok = False

    if not local_net_ok:
        return {
            "local_net_ok": False,
            "dns_ok": False,
            "tcp_reachable": False,
            "tcp_ms": -1,
            "summary": "员工本地电脑/手机已断网（无法访问国内基础网络，请检查 Wi-Fi 或网线）",
        }

    # 2. 检查节点域名 DNS 解析
    resolved_ip = ""
    try:
        resolved_ip = socket.gethostbyname(server)
    except Exception as exc:
        return {
            "local_net_ok": True,
            "dns_ok": False,
            "tcp_reachable": False,
            "tcp_ms": -1,
            "summary": f"节点域名无法解析 ({server}: {exc})",
        }

    # 3. 如果是 Hysteria2（基于 UDP/QUIC），额外检测 TCP 或提示 UDP 阻断可能
    proto_lower = (protocol or "").lower()
    t0 = time.perf_counter()
    try:
        with socket.create_connection((resolved_ip, int(port)), timeout=timeout):
            tcp_ms = int((time.perf_counter() - t0) * 1000)
            return {
                "local_net_ok": True,
                "dns_ok": True,
                "resolved_ip": resolved_ip,
                "tcp_reachable": True,
                "tcp_ms": tcp_ms,
                "summary": f"节点端口({resolved_ip}:{port}) TCP可达({tcp_ms}ms)，但代理握手失败（可能是 UUID/密码/Reality密钥不匹配、TLS证书过期或时间未同步）",
            }
    except socket.timeout:
        if proto_lower in ("hysteria2", "hy2"):
            reason = f"Hysteria2 节点({resolved_ip}:{port}) 连接超时（可能是运营商阻断了 UDP/QUIC 流量或服务器防火墙未放行 UDP {port} 端口）"
        else:
            reason = f"节点服务器({resolved_ip}:{port}) TCP 握手超时（可能是节点 IP/端口被防火墙阻断，或服务器宕机）"
        return {
            "local_net_ok": True,
            "dns_ok": True,
            "resolved_ip": resolved_ip,
            "tcp_reachable": False,
            "tcp_ms": -1,
            "summary": reason,
        }
    except ConnectionRefusedError:
        return {
            "local_net_ok": True,
            "dns_ok": True,
            "resolved_ip": resolved_ip,
            "tcp_reachable": False,
            "tcp_ms": -1,
            "summary": f"节点服务器({resolved_ip}:{port}) 拒绝连接（服务器在线，但代理服务端程序未运行或端口填写错误）",
        }
    except Exception as exc:
        return {
            "local_net_ok": True,
            "dns_ok": True,
            "resolved_ip": resolved_ip,
            "tcp_reachable": False,
            "tcp_ms": -1,
            "summary": f"连接异常 ({resolved_ip}:{port} -> {exc})",
        }


def send_feishu_alert(
    webhook_url: str,
    report: dict[str, Any],
    secret: str = "",
    timeout: float = 8.0,
) -> tuple[bool, str]:
    """直接向个人飞书自定义机器人 Webhook 发送富文本交互卡片告警（强制绕过代理直连）。"""
    url = (webhook_url or "").strip()
    if not url:
        return False, "未配置飞书 Webhook 地址"
    if not url.startswith(("https://open.feishu.cn/", "https://open.larksuite.com/", "http://127.0.0.1", "http://localhost")):
        return False, "飞书 Webhook 地址格式不正确（应以 https://open.feishu.cn/open-apis/bot/v2/hook/ 开头）"

    now_str = report.get("created_at") or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    employee = report.get("employee") or "未知员工"
    device = report.get("device") or f"{platform.system()} ({platform.node()})"
    region = report.get("region") or "未指定地区"
    node_name = report.get("node_name") or "未指定节点"
    protocol = str(report.get("protocol") or "unknown").upper()
    server_addr = report.get("server_addr") or "-"
    reason = report.get("reason") or "连接超时或代理握手失败"
    user_note = report.get("user_note") or "自动监测触发上报"
    is_test = bool(report.get("is_test", False))

    title = "✅ 跨境公司VPN · 飞书告警通道测试成功" if is_test else f"🚨 跨境公司VPN · 员工连接失败告警 ({employee})"
    template_color = "green" if is_test else "red"

    card_payload: dict[str, Any] = {
        "msg_type": "interactive",
        "card": {
            "config": {"wide_screen_mode": True},
            "header": {
                "template": template_color,
                "title": {"tag": "plain_text", "content": title},
            },
            "elements": [
                {
                    "tag": "div",
                    "fields": [
                        {"is_short": True, "text": {"tag": "lark_md", "content": f"**👤 报错员工：**\n{employee}"}},
                        {"is_short": True, "text": {"tag": "lark_md", "content": f"**💻 终端设备：**\n{device}"}},
                        {"is_short": True, "text": {"tag": "lark_md", "content": f"**🌍 目标地区：**\n{region}"}},
                        {"is_short": True, "text": {"tag": "lark_md", "content": f"**🔌 节点协议：**\n{protocol}"}},
                    ],
                },
                {
                    "tag": "div",
                    "text": {
                        "tag": "lark_md",
                        "content": (
                            f"**📡 故障节点：** `{node_name}` (`{server_addr}`)\n"
                            f"**🔍 自动诊断结论：**\n{reason}\n"
                            f"**💬 触发方式/备注：** {user_note}\n"
                            f"**🕒 上报时间：** {now_str}"
                        ),
                    },
                },
            ],
        },
    }

    return _post_feishu_card(url, card_payload, secret=secret, timeout=timeout, ok_label="已成功推送至个人飞书")


def _post_feishu_card(
    url: str,
    card_payload: dict[str, Any],
    secret: str = "",
    timeout: float = 8.0,
    ok_label: str = "已发送至飞书",
) -> tuple[bool, str]:
    payload = dict(card_payload)
    if secret and secret.strip():
        ts = int(time.time())
        payload["timestamp"] = str(ts)
        payload["sign"] = _make_feishu_sign(ts, secret.strip())

    req = urllib.request.Request(
        url,
        data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
        headers={"Content-Type": "application/json; charset=utf-8"},
        method="POST",
    )
    direct_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
    try:
        with direct_opener.open(req, timeout=timeout) as resp:
            resp_text = resp.read().decode("utf-8", errors="ignore")
            try:
                resp_json = json.loads(resp_text)
                if resp_json.get("code", 0) == 0 and resp_json.get("StatusCode", 0) == 0:
                    return True, ok_label
                return False, f"飞书接口返回错误: {resp_json.get('msg') or resp_text}"
            except Exception:
                return True, ok_label
    except Exception as exc:
        return False, f"飞书推送网络请求失败: {exc}"


def send_feishu_connect_notice(
    webhook_url: str,
    event: dict[str, Any],
    secret: str = "",
    timeout: float = 6.0,
) -> tuple[bool, str]:
    """当员工客户端发起连接时，向管理员飞书推送上线连接汇报卡片。"""
    url = (webhook_url or "").strip()
    if not url:
        return False, "未配置飞书 Webhook"
    now_str = event.get("created_at") or datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    employee = event.get("employee") or "未命名员工"
    code = event.get("code") or "-"
    device = event.get("device") or "Windows"
    region = event.get("region") or "⚡ 自动最快地区"
    active_node = event.get("active_node") or "自动分配"
    ip_addr = event.get("ip_addr") or "-"
    ip_loc = event.get("ip_location") or "未知归属地"
    mode_lbl = "全局模式" if event.get("routing_mode") == "global" else "智能分流"
    tun_lbl = "TUN虚拟网卡" if event.get("tun_enabled") else "系统代理"
    app_ver = event.get("app_version") or ""
    ver_tag = f"v{app_ver}" if app_ver else ""

    card_payload: dict[str, Any] = {
        "msg_type": "interactive",
        "card": {
            "config": {"wide_screen_mode": True},
            "header": {
                "template": "blue",
                "title": {"tag": "plain_text", "content": f"🟢 员工端连接上线汇报 ({employee})"},
            },
            "elements": [
                {
                    "tag": "div",
                    "fields": [
                        {"is_short": True, "text": {"tag": "lark_md", "content": f"**👤 员工 / 激活码：**\n{employee} (`{code}`)"}},
                        {"is_short": True, "text": {"tag": "lark_md", "content": f"**🌍 来访 IP / 归属：**\n{ip_loc} (`{ip_addr}`)"}},
                        {"is_short": True, "text": {"tag": "lark_md", "content": f"**📡 目标地区 / 节点：**\n{region} · `{active_node}`"}},
                        {"is_short": True, "text": {"tag": "lark_md", "content": f"**⚙️ 模式 / 版本：**\n{mode_lbl} · {tun_lbl} {ver_tag}"}},
                    ],
                },
                {
                    "tag": "div",
                    "text": {"tag": "lark_md", "content": f"**💻 终端设备：** {device}\n**🕒 连接时间：** {now_str}"},
                },
            ],
        },
    }
    return _post_feishu_card(url, card_payload, secret=secret, timeout=timeout, ok_label="已推送连接汇报至飞书")


def send_feishu_security_alert(
    webhook_url: str,
    title: str,
    details_md: str,
    secret: str = "",
    timeout: float = 8.0,
) -> tuple[bool, str]:
    """向管理员个人飞书推送账号异常使用/疑似外泄安全告警。"""
    url = (webhook_url or "").strip()
    if not url:
        return False, "未配置飞书 Webhook"
    now_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    card_payload: dict[str, Any] = {
        "msg_type": "interactive",
        "card": {
            "config": {"wide_screen_mode": True},
            "header": {
                "template": "orange",
                "title": {"tag": "plain_text", "content": title},
            },
            "elements": [
                {
                    "tag": "div",
                    "text": {"tag": "lark_md", "content": f"{details_md}\n**🕒 检测时间：** {now_str}"},
                }
            ],
        },
    }
    return _post_feishu_card(url, card_payload, secret=secret, timeout=timeout, ok_label="已推送安全告警至飞书")
