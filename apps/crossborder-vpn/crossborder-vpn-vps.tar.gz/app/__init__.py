"""CrossBorder Company One-Click VPN System."""
__version__ = "1.2.0"
