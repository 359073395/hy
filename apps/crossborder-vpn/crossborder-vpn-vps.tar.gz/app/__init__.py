"""CrossBorder Company One-Click VPN System."""
__version__ = "1.1.4"
