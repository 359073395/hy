"""多内核 (Mihomo + Xray-core + sing-box) 与 GeoIP/GeoSite 规则库检测及一键下载模块。
借鉴 Warp Relay Panel 多核协同架构，支持 Windows (.exe) 与 Linux VPS 自动拉取补齐三核。
"""

from __future__ import annotations

import gzip
import io
import json
import platform
import stat
import sys
import tarfile
import urllib.request
import zipfile
from pathlib import Path
from typing import Any, Callable

MIHOMO_LATEST_API = "https://api.github.com/repos/MetaCubeX/mihomo/releases/latest"
XRAY_LATEST_API = "https://api.github.com/repos/XTLS/Xray-core/releases/latest"
SINGBOX_LATEST_API = "https://api.github.com/repos/SagerNet/sing-box/releases/latest"
GEO_BASE_URL = "https://github.com/MetaCubeX/meta-rules-dat/releases/latest/download"
GH_MIRRORS = ["", "https://gh-proxy.com/", "https://mirror.ghproxy.com/"]

GEO_FILES = ("geosite.dat", "geoip.dat", "geoip.metadb")


def _bin_name(base: str) -> str:
    return f"{base}.exe" if sys.platform == "win32" else base


def _chmod_x(path: Path) -> None:
    if sys.platform != "win32" and path.exists():
        try:
            st = path.stat().st_mode
            path.chmod(st | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        except Exception:
            pass


def get_core_status(core_dir: Path) -> dict[str, Any]:
    """检查 Mihomo / Xray-core / sing-box 三大内核与 Geo 规则库是否就绪。"""
    m_name = _bin_name("mihomo")
    x_name = _bin_name("xray")
    s_name = _bin_name("sing-box")

    files: dict[str, dict[str, Any]] = {}
    for name in (m_name, x_name, s_name, *GEO_FILES):
        p = core_dir / name
        exists = p.is_file() and p.stat().st_size > 0
        files[name] = {
            "exists": exists,
            "size_mb": round(p.stat().st_size / (1024 * 1024), 2) if exists else 0.0,
        }
    has_mihomo = files[m_name]["exists"]
    has_xray = files[x_name]["exists"]
    has_singbox = files[s_name]["exists"]
    has_geo = all(files[n]["exists"] for n in GEO_FILES)
    return {
        "ready": has_mihomo,
        "has_mihomo": has_mihomo,
        "has_xray": has_xray,
        "has_singbox": has_singbox,
        "has_geo": has_geo,
        "mihomo_path": str(core_dir / m_name),
        "xray_path": str(core_dir / x_name),
        "singbox_path": str(core_dir / s_name),
        "files": files,
    }


def _open_url(url: str, proxy_url: str | None = None, timeout: float = 30.0) -> bytes:
    req = urllib.request.Request(url, headers={"User-Agent": "CrossBorderVPN/2.0"})
    handler = urllib.request.ProxyHandler({"http": proxy_url, "https": proxy_url} if proxy_url else {})
    opener = urllib.request.build_opener(handler)
    with opener.open(req, timeout=timeout) as resp:
        return resp.read()


def _download_with_mirrors(
    url: str,
    proxy_url: str | None = None,
    timeout: float = 45.0,
) -> bytes:
    proxies_to_try = [proxy_url, None] if proxy_url else [None]
    last_err: Exception | None = None
    for mirror in GH_MIRRORS:
        target = f"{mirror}{url}" if mirror else url
        for px in proxies_to_try:
            try:
                return _open_url(target, proxy_url=px, timeout=timeout)
            except Exception as exc:
                last_err = exc
    raise RuntimeError(f"下载失败 ({url}): {last_err}")


def _fetch_release_json(api_url: str, proxy_url: str | None = None) -> dict[str, Any]:
    proxies_to_try = [proxy_url, None] if proxy_url else [None]
    last_err: Exception | None = None
    for px in proxies_to_try:
        try:
            raw = _open_url(api_url, proxy_url=px, timeout=15.0)
            return json.loads(raw.decode("utf-8", errors="ignore"))
        except Exception as exc:
            last_err = exc
    raise RuntimeError(f"获取 Release 版本信息失败 ({api_url}): {last_err}")


def _arch_tag() -> str:
    m = platform.machine().lower()
    if m in ("aarch64", "arm64"):
        return "arm64"
    return "amd64"


def ensure_mihomo_exe(core_dir: Path, proxy_url: str | None = None, force: bool = False) -> Path:
    core_dir.mkdir(parents=True, exist_ok=True)
    target = core_dir / _bin_name("mihomo")
    if not force and target.is_file() and target.stat().st_size > 0:
        _chmod_x(target)
        return target

    release = _fetch_release_json(MIHOMO_LATEST_API, proxy_url=proxy_url)
    assets = release.get("assets") or []
    arch = _arch_tag()

    if sys.platform == "win32":
        prefixes = (f"mihomo-windows-{arch}-compatible-", f"mihomo-windows-{arch}-v1-", f"mihomo-windows-{arch}-")
        for prefix in prefixes:
            for asset in assets:
                name = str(asset.get("name") or "")
                if name.startswith(prefix) and name.endswith(".zip") and "alpha" not in name.lower():
                    zip_bytes = _download_with_mirrors(str(asset["browser_download_url"]), proxy_url=proxy_url, timeout=90.0)
                    with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                        for info in zf.infolist():
                            bname = Path(info.filename).name.lower()
                            if bname.startswith("mihomo") and bname.endswith(".exe"):
                                with zf.open(info, "r") as src:
                                    target.write_bytes(src.read())
                                return target
    else:
        prefixes = (f"mihomo-linux-{arch}-compatible-", f"mihomo-linux-{arch}-v1-", f"mihomo-linux-{arch}-")
        for prefix in prefixes:
            for asset in assets:
                name = str(asset.get("name") or "")
                if name.startswith(prefix) and name.endswith(".gz") and "alpha" not in name.lower():
                    gz_bytes = _download_with_mirrors(str(asset["browser_download_url"]), proxy_url=proxy_url, timeout=90.0)
                    target.write_bytes(gzip.decompress(gz_bytes))
                    _chmod_x(target)
                    return target
    raise RuntimeError("未找到匹配的 Mihomo 发行版包")


def ensure_xray_exe(core_dir: Path, proxy_url: str | None = None, force: bool = False) -> Path:
    """确保 core/xray.exe (或 Linux core/xray) 存在。"""
    core_dir.mkdir(parents=True, exist_ok=True)
    target = core_dir / _bin_name("xray")
    if not force and target.is_file() and target.stat().st_size > 0:
        _chmod_x(target)
        return target

    release = _fetch_release_json(XRAY_LATEST_API, proxy_url=proxy_url)
    arch = "arm64-v8a" if _arch_tag() == "arm64" else "64"
    expected_prefix = f"Xray-windows-{arch}" if sys.platform == "win32" else f"Xray-linux-{arch}"
    bin_lower = _bin_name("xray").lower()

    for asset in release.get("assets") or []:
        name = str(asset.get("name") or "")
        if name.startswith(expected_prefix) and name.endswith(".zip"):
            zip_bytes = _download_with_mirrors(str(asset["browser_download_url"]), proxy_url=proxy_url, timeout=90.0)
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                for info in zf.infolist():
                    if Path(info.filename).name.lower() == bin_lower:
                        with zf.open(info, "r") as src:
                            target.write_bytes(src.read())
                        _chmod_x(target)
                        return target
    raise RuntimeError(f"未在 Xray-core Release 中找到 {expected_prefix}.zip")


def ensure_singbox_exe(core_dir: Path, proxy_url: str | None = None, force: bool = False) -> Path:
    """确保 core/sing-box.exe (或 Linux core/sing-box) 存在。"""
    core_dir.mkdir(parents=True, exist_ok=True)
    target = core_dir / _bin_name("sing-box")
    if not force and target.is_file() and target.stat().st_size > 0:
        _chmod_x(target)
        return target

    release = _fetch_release_json(SINGBOX_LATEST_API, proxy_url=proxy_url)
    arch = _arch_tag()
    bin_lower = _bin_name("sing-box").lower()

    for asset in release.get("assets") or []:
        name = str(asset.get("name") or "")
        if sys.platform == "win32" and f"-windows-{arch}.zip" in name:
            zip_bytes = _download_with_mirrors(str(asset["browser_download_url"]), proxy_url=proxy_url, timeout=90.0)
            with zipfile.ZipFile(io.BytesIO(zip_bytes)) as zf:
                for info in zf.infolist():
                    if Path(info.filename).name.lower() == bin_lower:
                        with zf.open(info, "r") as src:
                            target.write_bytes(src.read())
                        return target
        elif sys.platform != "win32" and f"-linux-{arch}.tar.gz" in name:
            tar_bytes = _download_with_mirrors(str(asset["browser_download_url"]), proxy_url=proxy_url, timeout=90.0)
            with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode="r:gz") as tf:
                for member in tf.getmembers():
                    if Path(member.name).name.lower() == bin_lower:
                        extracted = tf.extractfile(member)
                        if extracted:
                            target.write_bytes(extracted.read())
                            _chmod_x(target)
                            return target
    raise RuntimeError("未在 sing-box Release 中找到对应平台的压缩包")


def download_all_cores(
    core_dir: Path,
    proxy_url: str | None = None,
    force: bool = False,
) -> dict[str, Any]:
    """一键检测并补齐 Mihomo + Xray-core + sing-box 三大内核与 Geo 规则库。"""
    core_dir.mkdir(parents=True, exist_ok=True)
    downloaded: list[str] = []

    st = get_core_status(core_dir)
    if force or not st["has_mihomo"]:
        ensure_mihomo_exe(core_dir, proxy_url=proxy_url, force=force)
        downloaded.append(_bin_name("mihomo"))
    if force or not st["has_xray"]:
        ensure_xray_exe(core_dir, proxy_url=proxy_url, force=force)
        downloaded.append(_bin_name("xray"))
    if force or not st["has_singbox"]:
        ensure_singbox_exe(core_dir, proxy_url=proxy_url, force=force)
        downloaded.append(_bin_name("sing-box"))

    for name in GEO_FILES:
        if force or not st["files"][name]["exists"]:
            data = _download_with_mirrors(f"{GEO_BASE_URL}/{name}", proxy_url=proxy_url, timeout=60.0)
            if len(data) >= 1024:
                (core_dir / name).write_bytes(data)
                downloaded.append(name)

    return {
        "ok": True,
        "downloaded": downloaded,
        "status": get_core_status(core_dir),
    }
