"""全协议 & 多内核节点解析与配置生成器（借鉴 Warp Relay Panel 最新多核架构）：
- 支持协议：VLESS / VMess / Trojan / Shadowsocks (SS) / Hysteria2 (hy2) / TUIC / AnyTLS / WireGuard / SOCKS5 / HTTP
- 支持传输层：TCP / WS / HTTPUpgrade / XHTTP(SplitHTTP+extra) / mKCP / QUIC / gRPC / H2 / Reality(pbk+sid+spx)
- 支持三大内核协同：Mihomo (Clash.Meta) + Xray-core + sing-box
"""

from __future__ import annotations

import base64
import hashlib
import ipaddress
import json
import re
import socket
import urllib.parse
from typing import Any

import yaml


REGION_RULES: list[tuple[str, str, list[str]]] = [
    ("US", "🇺🇸 美国", ["美国", "美西", "美东", "洛杉矶", "硅谷", "圣何塞", "西雅图", "纽约", "达拉斯", "芝加哥", "凤凰城", "波特兰", "us", "usa", "united states", "lax", "sjc", "sea", "nyc", "dfw", "ord"]),
    ("ID", "🇮🇩 印度尼西亚", ["印度尼西亚", "印尼", "雅加达", "泗水", "巴厘", "id", "idn", "indonesia", "jakarta", "cgk", "jkt"]),
    ("PH", "🇵🇭 菲律宾", ["菲律宾", "马尼拉", "宿务", "ph", "phl", "philippines", "manila", "mnl"]),
    ("VN", "🇻🇳 越南", ["越南", "胡志明", "河内", "岘港", "vn", "vnm", "vietnam", "hanoi", "sgn", "han"]),
    ("TH", "🇹🇭 泰国", ["泰国", "曼谷", "清迈", "th", "tha", "thailand", "bangkok", "bkk"]),
    ("MY", "🇲🇾 马来西亚", ["马来西亚", "大马", "吉隆坡", "新山", "my", "mys", "malaysia", "kuala lumpur", "kul"]),
    ("SG", "🇸🇬 新加坡", ["新加坡", "狮城", "sg", "sgp", "singapore", "sin"]),
    ("JP", "🇯🇵 日本", ["日本", "东京", "大阪", "名古屋", "埼玉", "jp", "jpn", "japan", "tokyo", "osaka", "nrt", "kix", "tyo"]),
    ("KR", "🇰🇷 韩国", ["韩国", "首尔", "仁川", "釜山", "kr", "kor", "korea", "seoul", "icn"]),
    ("HK", "🇭🇰 香港", ["香港", "hk", "hkg", "hong kong", "hongkong"]),
    ("TW", "🇹🇼 台湾", ["台湾", "台北", "新北", "彰化", "高雄", "tw", "twn", "taiwan", "taipei", "tpe"]),
    ("GB", "🇬🇧 英国", ["英国", "伦敦", "曼彻斯特", "uk", "gb", "gbr", "united kingdom", "london", "lhr"]),
    ("DE", "🇩🇪 德国", ["德国", "法兰克福", "慕尼黑", "柏林", "de", "deu", "germany", "frankfurt", "fra"]),
    ("FR", "🇫🇷 法国", ["法国", "巴黎", "马赛", "fr", "fra", "france", "paris", "cdg"]),
    ("CA", "🇨🇦 加拿大", ["加拿大", "多伦多", "温哥华", "蒙特利尔", "ca", "can", "canada", "toronto", "vancouver", "yyz", "yvr"]),
    ("AU", "🇦🇺 澳大利亚", ["澳大利亚", "澳洲", "悉尼", "墨尔本", "au", "aus", "australia", "sydney", "syd", "mel"]),
    ("BR", "🇧🇷 巴西", ["巴西", "圣保罗", "br", "bra", "brazil", "sao paulo", "gru"]),
    ("MX", "🇲🇽 墨西哥", ["墨西哥", "mx", "mex", "mexico"]),
    ("AE", "🇦🇪 阿联酋", ["阿联酋", "迪拜", "阿布扎比", "ae", "uae", "dubai", "dxb"]),
    ("IN", "🇮🇳 印度", ["印度", "孟买", "新德里", "in", "ind", "india", "mumbai", "bom"]),
]


def get_supported_regions() -> list[str]:
    return [label for _code, label, _kw in REGION_RULES] + ["🌐 综合外网"]


def detect_region(name: str, server: str = "", explicit_region: str = "") -> str:
    if explicit_region and explicit_region.strip() and explicit_region.strip() != "自动识别":
        exp = explicit_region.strip()
        for code, label, keywords in REGION_RULES:
            if (
                exp.upper() == code
                or exp == label
                or any(k == exp.lower() or (not k.isascii() and k in exp) for k in keywords)
            ):
                return label
        return exp

    text = f"{name} {server}".lower()
    for _code, label, keywords in REGION_RULES:
        for kw in keywords:
            if kw.isascii() and len(kw) <= 3:
                if re.search(rf"(?:^|[^a-z0-9]){re.escape(kw)}(?:$|[^a-z0-9])", text):
                    return label
            else:
                if kw in text:
                    return label
    return "🌐 综合外网"


def _b64_decode_str(s: str) -> str:
    s = s.strip().replace("-", "+").replace("_", "/")
    s += "=" * (-len(s) % 4)
    return base64.b64decode(s).decode("utf-8", errors="ignore")


def _parse_int(val: Any, default: int = 0) -> int:
    try:
        return int(val)
    except (TypeError, ValueError):
        return default


def _is_truthy(val: Any) -> bool:
    return str(val or "").strip().lower() in ("1", "true", "yes", "on")


def make_node_id(protocol: str, server: str, port: int, name: str) -> str:
    raw = f"{protocol}://{server}:{port}#{name}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:12]


def is_xray_only_node(node: dict[str, Any]) -> bool:
    """判断节点是否依赖 Xray-core 专属传输或加密（Mihomo 不支持或兼容性弱）。"""
    if not isinstance(node, dict):
        return False
    net = str(node.get("network") or "").lower()
    if net in ("kcp", "quic", "xhttp"):
        return True
    if node.get("type") == "vless" and str(node.get("encryption") or "").lower() not in ("", "none"):
        return True
    return False


def is_xray_supported_protocol(node: dict[str, Any]) -> bool:
    return str(node.get("type") or "").lower() in ("vless", "vmess", "trojan", "ss")


def is_singbox_supported_protocol(node: dict[str, Any]) -> bool:
    ptype = str(node.get("type") or "").lower()
    net = str(node.get("network") or "tcp").lower()
    if net in ("kcp", "quic", "xhttp"):
        return False
    return ptype in ("vless", "vmess", "trojan", "ss", "hysteria2", "tuic", "socks5", "http")


def resolve_effective_core(node: dict[str, Any], has_xray: bool = True, has_singbox: bool = False) -> str:
    """根据节点的 preferred_core、历史实测最佳内核 resolved_core 与协议特性决定实际拨号内核:
    返回 'xray' | 'sing-box' | 'mihomo'
    """
    pref = str(node.get("preferred_core") or "auto").lower()
    if pref == "xray" and is_xray_supported_protocol(node) and has_xray:
        return "xray"
    if pref == "sing-box" and is_singbox_supported_protocol(node) and has_singbox:
        return "sing-box"
    if pref == "mihomo" and not is_xray_only_node(node):
        return "mihomo"

    if is_xray_only_node(node) and has_xray:
        return "xray"

    resolved = str(node.get("resolved_core") or "").lower()
    if resolved == "xray" and is_xray_supported_protocol(node) and has_xray:
        return "xray"
    if resolved == "sing-box" and is_singbox_supported_protocol(node) and has_singbox:
        return "sing-box"
    if resolved == "mihomo":
        return "mihomo"

    return "mihomo"


def _apply_transport_opts(
    node: dict[str, Any],
    net: str,
    path: str = "/",
    host: str = "",
    service_name: str = "",
    header_type: str = "",
    mode: str = "",
    seed: str = "",
    quic_security: str = "",
    quic_key: str = "",
    extra_json: str = "",
) -> None:
    net = (net or "tcp").lower()
    if net in ("raw", "tcp", "none", ""):
        if header_type.lower() == "http":
            node["network"] = "http"
            http_opts: dict[str, Any] = {"path": [path or "/"]}
            if host:
                http_opts["headers"] = {"Host": [h.strip() for h in host.split(",") if h.strip()]}
            node["http-opts"] = http_opts
        else:
            node["network"] = "tcp"
        return

    if net == "ws":
        node["network"] = "ws"
        ws_opts: dict[str, Any] = {"path": path or "/"}
        if host:
            ws_opts["headers"] = {"Host": host}
        node["ws-opts"] = ws_opts
    elif net == "httpupgrade":
        node["network"] = "ws"
        ws_opts = {"path": path or "/", "v2ray-http-upgrade": True}
        if host:
            ws_opts["headers"] = {"Host": host}
        node["ws-opts"] = ws_opts
    elif net in ("xhttp", "splithttp"):
        node["network"] = "xhttp"
        xhttp_opts: dict[str, Any] = {"path": path or "/"}
        if host:
            xhttp_opts["host"] = host
        if mode:
            xhttp_opts["mode"] = mode
        if extra_json:
            try:
                xhttp_opts["extra"] = json.loads(extra_json)
            except Exception:
                xhttp_opts["extra"] = extra_json
        node["xhttp-opts"] = xhttp_opts
    elif net == "kcp":
        node["network"] = "kcp"
        kcp_opts: dict[str, Any] = {"header-type": header_type or "none"}
        if seed:
            kcp_opts["seed"] = seed
        node["kcp-opts"] = kcp_opts
    elif net == "quic":
        node["network"] = "quic"
        node["quic-opts"] = {
            "security": quic_security or "none",
            "key": quic_key or "",
            "header-type": header_type or "none",
        }
    elif net == "h2":
        node["network"] = "h2"
        h2_opts: dict[str, Any] = {"path": path or "/"}
        if host:
            h2_opts["host"] = [h.strip() for h in host.split(",") if h.strip()]
        node["h2-opts"] = h2_opts
    elif net == "grpc":
        node["network"] = "grpc"
        if service_name or path:
            node["grpc-opts"] = {"grpc-service-name": service_name or path}
    else:
        node["network"] = net


def parse_proxy_uri(uri: str, explicit_region: str = "") -> dict[str, Any] | None:
    uri = uri.strip()
    if not uri or uri.startswith("#"):
        return None

    lower = uri.lower()
    parsed: dict[str, Any] | None = None
    try:
        if lower.startswith("vless://"):
            parsed = _parse_vless(uri)
        elif lower.startswith("vmess://"):
            parsed = _parse_vmess(uri)
        elif lower.startswith("trojan://"):
            parsed = _parse_trojan(uri)
        elif lower.startswith("ss://"):
            parsed = _parse_ss(uri)
        elif lower.startswith(("hysteria2://", "hy2://")):
            parsed = _parse_hy2(uri)
        elif lower.startswith("tuic://"):
            parsed = _parse_tuic(uri)
        elif lower.startswith("anytls://"):
            parsed = _parse_anytls(uri)
        elif lower.startswith(("wireguard://", "wg://")):
            parsed = _parse_wireguard(uri)
        elif lower.startswith(("socks5://", "socks://", "http://", "https://")):
            parsed = _parse_socks_http(uri)
    except Exception:
        return None

    if not parsed:
        return None

    parsed["raw_uri"] = uri
    parsed["region"] = detect_region(parsed.get("name", ""), str(parsed.get("server", "")), explicit_region)
    parsed["preferred_core"] = parsed.get("preferred_core") or "auto"
    parsed["id"] = make_node_id(
        parsed.get("type", ""),
        str(parsed.get("server", "")),
        int(parsed.get("port", 0)),
        parsed.get("name", ""),
    )
    return parsed


def _parse_vmess(uri: str) -> dict[str, Any] | None:
    payload = uri[8:].split("#", 1)[0].strip()
    frag_name = urllib.parse.unquote(uri.split("#", 1)[1]).strip() if "#" in uri else ""
    try:
        data = json.loads(_b64_decode_str(payload))
    except Exception:
        return None
    server = str(data.get("add", "")).strip()
    port = _parse_int(data.get("port"))
    uuid = str(data.get("id", "")).strip()
    if not server or not (1 <= port <= 65535) or not uuid:
        return None

    net = str(data.get("net", "tcp")).lower() or "tcp"
    tls_val = str(data.get("tls", "")).lower() in ("tls", "true", "1")
    host = str(data.get("host") or "").strip()
    path = str(data.get("path") or "/").strip()
    name = str(data.get("ps") or frag_name or f"VMess-{server}:{port}").strip()

    node: dict[str, Any] = {
        "name": name,
        "type": "vmess",
        "server": server,
        "port": port,
        "uuid": uuid,
        "alterId": _parse_int(data.get("aid"), 0),
        "cipher": str(data.get("scy") or "auto"),
        "udp": True,
    }
    if tls_val:
        node["tls"] = True
        sni = str(data.get("sni") or host).strip()
        if sni:
            node["servername"] = sni
        if _is_truthy(data.get("allowInsecure")) or _is_truthy(data.get("insecure")) or str(data.get("verify_cert", "true")).lower() in ("false", "0"):
            node["skip-cert-verify"] = True
        if data.get("fp"):
            node["client-fingerprint"] = str(data["fp"]).strip()
        if data.get("alpn"):
            node["alpn"] = [x.strip() for x in str(data["alpn"]).split(",") if x.strip()]

    _apply_transport_opts(
        node,
        net=net,
        path=path,
        host=host,
        service_name=path if net == "grpc" else "",
        header_type=str(data.get("type") or ""),
        seed=str(data.get("path") or "") if net == "kcp" else "",
        quic_security=host if net == "quic" else "",
        quic_key=path if net == "quic" else "",
    )
    return node


def _parse_vless(uri: str) -> dict[str, Any] | None:
    u = urllib.parse.urlparse(uri)
    if not u.hostname or not u.port or not u.username:
        return None
    qs = urllib.parse.parse_qs(u.query)
    q = lambda k, d="": (qs.get(k) or [d])[0]

    name = urllib.parse.unquote(u.fragment).strip() or f"VLESS-{u.hostname}:{u.port}"
    sec = q("security", "none").lower()
    net = q("type", "tcp").lower()

    node: dict[str, Any] = {
        "name": name,
        "type": "vless",
        "server": u.hostname,
        "port": int(u.port),
        "uuid": urllib.parse.unquote(u.username),
        "udp": True,
    }
    if q("flow"):
        node["flow"] = q("flow")
    if q("encryption") and q("encryption").lower() != "none":
        node["encryption"] = q("encryption")
    if q("packetEncoding"):
        node["packet-encoding"] = q("packetEncoding")

    if sec in ("tls", "reality"):
        node["tls"] = True
        sni = q("sni") or q("host")
        if sni:
            node["servername"] = sni
        fp = q("fp") or ("chrome" if sec == "reality" else "")
        if fp:
            node["client-fingerprint"] = fp
        if _is_truthy(q("allowInsecure")) or _is_truthy(q("insecure")):
            node["skip-cert-verify"] = True
        if q("alpn"):
            node["alpn"] = [x.strip() for x in q("alpn").split(",") if x.strip()]

    if sec == "reality":
        ropts: dict[str, Any] = {}
        if q("pbk"):
            ropts["public-key"] = q("pbk")
        if q("sid"):
            ropts["short-id"] = q("sid")
        if q("spx"):
            ropts["spider-x"] = q("spx")
        if ropts:
            node["reality-opts"] = ropts

    _apply_transport_opts(
        node,
        net=net,
        path=q("path", "/"),
        host=q("host"),
        service_name=q("serviceName"),
        header_type=q("headerType"),
        mode=q("mode"),
        seed=q("seed"),
        quic_security=q("quicSecurity"),
        quic_key=q("key"),
        extra_json=q("extra"),
    )
    return node


def _parse_trojan(uri: str) -> dict[str, Any] | None:
    u = urllib.parse.urlparse(uri)
    if not u.hostname or not u.port or not u.username:
        return None
    qs = urllib.parse.parse_qs(u.query)
    q = lambda k, d="": (qs.get(k) or [d])[0]

    name = urllib.parse.unquote(u.fragment).strip() or f"Trojan-{u.hostname}:{u.port}"
    sec = q("security", "tls").lower()
    node: dict[str, Any] = {
        "name": name,
        "type": "trojan",
        "server": u.hostname,
        "port": int(u.port),
        "password": urllib.parse.unquote(u.username),
        "udp": True,
    }
    sni = q("sni") or q("peer") or q("host")
    if sni:
        node["sni"] = sni
    if _is_truthy(q("allowInsecure")) or _is_truthy(q("insecure")):
        node["skip-cert-verify"] = True
    fp = q("fp") or ("chrome" if sec == "reality" else "")
    if fp:
        node["client-fingerprint"] = fp
    if q("alpn"):
        node["alpn"] = [x.strip() for x in q("alpn").split(",") if x.strip()]
    if sec == "reality":
        ropts: dict[str, Any] = {}
        if q("pbk"):
            ropts["public-key"] = q("pbk")
        if q("sid"):
            ropts["short-id"] = q("sid")
        if ropts:
            node["reality-opts"] = ropts

    net = q("type", "tcp").lower()
    if net != "tcp" or q("headerType"):
        _apply_transport_opts(
            node,
            net=net,
            path=q("path", "/"),
            host=q("host"),
            service_name=q("serviceName"),
            header_type=q("headerType"),
            mode=q("mode"),
        )
    return node


def _apply_ss_plugin(node: dict[str, Any], plugin_str: str) -> None:
    if not plugin_str:
        return
    parts = [p.strip() for p in plugin_str.split(";") if p.strip()]
    if not parts:
        return
    raw_name = parts[0].lower()
    opts: dict[str, Any] = {}
    for kv in parts[1:]:
        if "=" in kv:
            k, v = kv.split("=", 1)
            opts[k.strip()] = v.strip()
        else:
            opts[kv] = True

    if raw_name in ("obfs-local", "simple-obfs", "obfs"):
        node["plugin"] = "obfs"
        p_opts: dict[str, Any] = {}
        if opts.get("obfs"):
            p_opts["mode"] = opts["obfs"]
        if opts.get("obfs-host"):
            p_opts["host"] = opts["obfs-host"]
        if p_opts:
            node["plugin-opts"] = p_opts
    elif raw_name == "v2ray-plugin":
        node["plugin"] = "v2ray-plugin"
        p_opts = {"mode": opts.get("mode", "websocket")}
        if opts.get("host"):
            p_opts["host"] = opts["host"]
        if opts.get("path"):
            p_opts["path"] = opts["path"]
        if "tls" in opts:
            p_opts["tls"] = True
        node["plugin-opts"] = p_opts


def _parse_ss(uri: str) -> dict[str, Any] | None:
    u = urllib.parse.urlparse(uri)
    qs = urllib.parse.parse_qs(u.query)
    plugin_str = (qs.get("plugin") or [""])[0]
    name = urllib.parse.unquote(u.fragment).strip()
    if u.hostname and u.port and u.username:
        if u.password is not None:
            cipher = urllib.parse.unquote(u.username)
            password = urllib.parse.unquote(u.password)
        else:
            user_info = urllib.parse.unquote(u.username)
            if ":" not in user_info:
                user_info = _b64_decode_str(user_info)
            if ":" not in user_info:
                return None
            cipher, password = user_info.split(":", 1)
        node: dict[str, Any] = {
            "name": name or f"SS-{u.hostname}:{u.port}",
            "type": "ss",
            "server": u.hostname,
            "port": int(u.port),
            "cipher": cipher,
            "password": password,
            "udp": True,
        }
        _apply_ss_plugin(node, plugin_str)
        return node

    body = uri[5:].split("#", 1)[0].split("?", 1)[0].strip()
    try:
        decoded = _b64_decode_str(body)
        if "@" in decoded:
            cred, addr = decoded.rsplit("@", 1)
            cipher, password = cred.split(":", 1)
            host, port_s = addr.rsplit(":", 1)
            node = {
                "name": name or f"SS-{host}:{port_s}",
                "type": "ss",
                "server": host,
                "port": int(port_s),
                "cipher": cipher,
                "password": password,
                "udp": True,
            }
            _apply_ss_plugin(node, plugin_str)
            return node
    except Exception:
        return None
    return None


def _parse_hy2(uri: str) -> dict[str, Any] | None:
    norm = "hysteria2://" + uri.split("://", 1)[1]
    u = urllib.parse.urlparse(norm)
    if not u.hostname or not u.port:
        return None
    qs = urllib.parse.parse_qs(u.query)
    q = lambda k, d="": (qs.get(k) or [d])[0]

    password = urllib.parse.unquote(u.username or "")
    if u.password:
        password = f"{password}:{urllib.parse.unquote(u.password)}"
    if not password and q("auth"):
        password = q("auth")

    node: dict[str, Any] = {
        "name": urllib.parse.unquote(u.fragment).strip() or f"Hy2-{u.hostname}:{u.port}",
        "type": "hysteria2",
        "server": u.hostname,
        "port": int(u.port),
        "password": password,
        "udp": True,
    }
    if q("sni"):
        node["sni"] = q("sni")
    if _is_truthy(q("insecure")) or _is_truthy(q("allowInsecure")):
        node["skip-cert-verify"] = True
    if q("alpn"):
        node["alpn"] = [x.strip() for x in q("alpn").split(",") if x.strip()]
    if q("mport"):
        node["ports"] = q("mport")
    if q("pinSHA256"):
        node["fingerprint"] = q("pinSHA256")
    if q("obfs") and q("obfs") != "none":
        node["obfs"] = q("obfs")
        if q("obfs-password"):
            node["obfs-password"] = q("obfs-password")
    if q("up"):
        node["up"] = q("up")
    if q("down"):
        node["down"] = q("down")
    return node


def _parse_tuic(uri: str) -> dict[str, Any] | None:
    u = urllib.parse.urlparse(uri)
    if not u.hostname or not u.port or not u.username:
        return None
    qs = urllib.parse.parse_qs(u.query)
    q = lambda k, d="": (qs.get(k) or [d])[0]
    node: dict[str, Any] = {
        "name": urllib.parse.unquote(u.fragment).strip() or f"tuic-{u.hostname}",
        "type": "tuic",
        "server": u.hostname,
        "port": int(u.port),
        "uuid": urllib.parse.unquote(u.username),
        "password": urllib.parse.unquote(u.password or ""),
        "congestion-controller": q("congestion_control", "bbr"),
        "udp-relay-mode": q("udp_relay_mode", "native"),
        "reduce-rtt": True,
    }
    if q("sni"):
        node["sni"] = q("sni")
    if q("alpn"):
        node["alpn"] = [x.strip() for x in q("alpn").split(",") if x.strip()]
    if _is_truthy(q("allow_insecure")) or _is_truthy(q("allowInsecure")) or _is_truthy(q("insecure")):
        node["skip-cert-verify"] = True
    return node


def _parse_anytls(uri: str) -> dict[str, Any] | None:
    u = urllib.parse.urlparse(uri)
    if not u.hostname or not u.port:
        return None
    qs = urllib.parse.parse_qs(u.query)
    q = lambda k, d="": (qs.get(k) or [d])[0]
    password = urllib.parse.unquote(u.username or "")
    if u.password:
        password = f"{password}:{urllib.parse.unquote(u.password)}"
    node: dict[str, Any] = {
        "name": urllib.parse.unquote(u.fragment).strip() or f"anytls-{u.hostname}",
        "type": "anytls",
        "server": u.hostname,
        "port": int(u.port),
        "password": password,
        "udp": True,
    }
    if q("sni"):
        node["sni"] = q("sni")
    if _is_truthy(q("insecure")) or _is_truthy(q("allowInsecure")):
        node["skip-cert-verify"] = True
    if q("fp"):
        node["client-fingerprint"] = q("fp")
    if q("alpn"):
        node["alpn"] = [x.strip() for x in q("alpn").split(",") if x.strip()]
    return node


def _parse_wireguard(uri: str) -> dict[str, Any] | None:
    norm = "wireguard://" + uri.split("://", 1)[1]
    u = urllib.parse.urlparse(norm)
    if not u.hostname or not u.port or not u.username:
        return None
    qs = urllib.parse.parse_qs(u.query)
    q = lambda k, d="": (qs.get(k) or [d])[0]
    addr_raw = q("address", "172.16.0.2/32")
    ip_v4 = addr_raw.split(",")[0].split("/")[0].strip()
    peer: dict[str, Any] = {
        "server": u.hostname,
        "port": int(u.port),
        "public-key": urllib.parse.unquote(q("publickey") or q("pbk")),
        "allowed-ips": ["0.0.0.0/0"],
    }
    if q("presharedkey") or q("psk"):
        peer["pre-shared-key"] = urllib.parse.unquote(q("presharedkey") or q("psk"))
    if q("reserved"):
        parts = [int(x.strip()) for x in q("reserved").split(",") if x.strip().isdigit()]
        if parts:
            peer["reserved"] = parts
    return {
        "name": urllib.parse.unquote(u.fragment).strip() or f"wg-{u.hostname}",
        "type": "wireguard",
        "server": u.hostname,
        "port": int(u.port),
        "private-key": urllib.parse.unquote(u.username),
        "ip": ip_v4,
        "peers": [peer],
        "mtu": int(q("mtu") or 1280),
        "udp": True,
    }


def _parse_socks_http(uri: str) -> dict[str, Any] | None:
    u = urllib.parse.urlparse(uri)
    if not u.hostname or not u.port:
        return None
    scheme = u.scheme.lower()
    ptype = "socks5" if scheme in ("socks5", "socks") else "http"
    node: dict[str, Any] = {
        "name": urllib.parse.unquote(u.fragment).strip() or f"{ptype}-{u.hostname}",
        "type": ptype,
        "server": u.hostname,
        "port": int(u.port),
        "udp": True,
    }
    if scheme == "https":
        node["tls"] = True
    if u.username is not None:
        node["username"] = urllib.parse.unquote(u.username)
    if u.password is not None:
        node["password"] = urllib.parse.unquote(u.password)
    return node


def parse_batch_nodes(text: str, explicit_region: str = "") -> list[dict[str, Any]]:
    """批量解析多行 URI、Base64 订阅内容或 Clash YAML proxies 列表。"""
    raw = text.strip()
    if not raw:
        return []

    if "proxies:" in raw or raw.lstrip().startswith("- name:"):
        try:
            doc = yaml.safe_load(raw)
            raw_list = doc.get("proxies") if isinstance(doc, dict) else (doc if isinstance(doc, list) else [])
            if isinstance(raw_list, list):
                results: list[dict[str, Any]] = []
                for item in raw_list:
                    if not isinstance(item, dict) or not item.get("server") or not item.get("type"):
                        continue
                    ptype = str(item.get("type")).lower()
                    node = dict(item)
                    node["type"] = ptype
                    node["port"] = _parse_int(node.get("port"))
                    if not (1 <= node["port"] <= 65535):
                        continue
                    node["name"] = str(node.get("name") or f"{ptype}-{node['server']}").strip()
                    node["region"] = detect_region(node["name"], str(node["server"]), explicit_region)
                    node["preferred_core"] = node.get("preferred_core") or "auto"
                    node["id"] = make_node_id(ptype, str(node["server"]), node["port"], node["name"])
                    results.append(node)
                if results:
                    return results
        except Exception:
            pass

    lines = [ln.strip() for ln in raw.splitlines() if ln.strip() and not ln.strip().startswith("#")]
    uri_lines = [ln for ln in lines if "://" in ln]
    if not uri_lines:
        try:
            decoded = _b64_decode_str(raw)
            uri_lines = [ln.strip() for ln in decoded.splitlines() if "://" in ln]
        except Exception:
            uri_lines = []

    nodes: list[dict[str, Any]] = []
    for ln in uri_lines:
        parsed = parse_proxy_uri(ln, explicit_region=explicit_region)
        if parsed:
            nodes.append(parsed)
    return nodes


def deduplicate_node_names(nodes: list[dict[str, Any]]) -> list[dict[str, Any]]:
    seen: dict[str, int] = {}
    out: list[dict[str, Any]] = []
    for n in nodes:
        item = dict(n)
        base = str(item.get("name") or f"{item.get('type')}-{item.get('server')}").strip()
        if base in seen:
            seen[base] += 1
            item["name"] = f"{base}-{seen[base]}"
        else:
            seen[base] = 1
            item["name"] = base
        out.append(item)
    return out


def group_nodes_by_region(nodes: list[dict[str, Any]]) -> dict[str, list[dict[str, Any]]]:
    clean_nodes = deduplicate_node_names(nodes)
    buckets: dict[str, list[dict[str, Any]]] = {}
    for n in clean_nodes:
        reg = detect_region(
            str(n.get("name", "")),
            str(n.get("server", "")),
            explicit_region=str(n.get("region") or ""),
        )
        buckets.setdefault(reg, []).append(n)

    order_map = {label: idx for idx, (_c, label, _k) in enumerate(REGION_RULES)}
    sorted_keys = sorted(buckets.keys(), key=lambda r: (order_map.get(r, 999), r))
    return {k: buckets[k] for k in sorted_keys}


def _strip_internal_fields(node: dict[str, Any]) -> dict[str, Any]:
    internal_keys = {
        "id",
        "region",
        "raw_uri",
        "preferred_core",
        "resolved_core",
        "active_core",
        "last_delay",
        "last_status",
        "tcp_delay",
        "tcp_status",
        "real_delay",
        "real_status",
        "last_check",
        "enabled",
        "created_at",
    }
    return {k: v for k, v in node.items() if k not in internal_keys}


def build_mihomo_config(
    nodes: list[dict[str, Any]],
    mixed_port: int = 17890,
    controller_port: int = 19090,
    routing_mode: str = "smart",
    tun_enabled: bool = False,
    allow_lan: bool = False,
    has_geosite: bool = True,
    for_verify: bool = False,
) -> dict[str, Any]:
    """生成 Mihomo (Clash.Meta) 高速配置字典（Fake-IP + GEOSITE/GEOIP 直连分流 + 零进程扫描开销）。"""
    grouped = group_nodes_by_region(nodes)
    proxies: list[dict[str, Any]] = []
    region_groups: list[dict[str, Any]] = []
    region_names: list[str] = []
    all_node_names: list[str] = []

    for region_label, r_nodes in grouped.items():
        r_proxy_names: list[str] = []
        for n in r_nodes:
            clean_p = _strip_internal_fields(n)
            proxies.append(clean_p)
            r_proxy_names.append(clean_p["name"])
            all_node_names.append(clean_p["name"])
        if r_proxy_names:
            region_names.append(region_label)
            region_groups.append(
                {
                    "name": region_label,
                    "type": "select",
                    "proxies": r_proxy_names,
                }
            )

    if not proxies:
        proxy_groups = [{"name": "PROXY", "type": "select", "proxies": ["DIRECT"]}]
    else:
        auto_group = {
            "name": "⚡ 自动最快地区",
            "type": "select",
            "proxies": all_node_names,
        }
        master_group = {
            "name": "PROXY",
            "type": "select",
            "proxies": ["⚡ 自动最快地区", *region_names, *all_node_names, "DIRECT"],
        }
        proxy_groups = [master_group, auto_group, *region_groups]

    base_direct_rules = [
        "DOMAIN-SUFFIX,feishu.cn,DIRECT",
        "DOMAIN-SUFFIX,feishucdn.com,DIRECT",
        "DOMAIN-SUFFIX,larksuite.com,DIRECT",
        "DOMAIN-SUFFIX,dingtalk.com,DIRECT",
        "DOMAIN-SUFFIX,weixin.qq.com,DIRECT",
        "DOMAIN-SUFFIX,qq.com,DIRECT",
        "DOMAIN-SUFFIX,aliyun.com,DIRECT",
        "DOMAIN-SUFFIX,taobao.com,DIRECT",
        "DOMAIN-SUFFIX,jd.com,DIRECT",
        "DOMAIN-SUFFIX,1688.com,DIRECT",
        "DOMAIN-SUFFIX,baidu.com,DIRECT",
        "IP-CIDR,127.0.0.0/8,DIRECT,no-resolve",
        "IP-CIDR,10.0.0.0/8,DIRECT,no-resolve",
        "IP-CIDR,172.16.0.0/12,DIRECT,no-resolve",
        "IP-CIDR,192.168.0.0/16,DIRECT,no-resolve",
    ]

    node_bypass_rules: list[str] = []
    tun_exclude_cidrs: list[str] = []
    seen_bypass: set[str] = set()
    seen_cidrs: set[str] = set()
    for n in nodes:
        srv = str(n.get("server") or "").strip()
        if not srv or srv in ("127.0.0.1", "localhost", "::1"):
            continue
        try:
            ip_obj = ipaddress.ip_address(srv)
            if ip_obj.version == 4:
                cidr = f"{srv}/32"
                rule = f"IP-CIDR,{cidr},DIRECT,no-resolve"
                if rule not in seen_bypass:
                    node_bypass_rules.append(rule)
                    seen_bypass.add(rule)
                if cidr not in seen_cidrs:
                    tun_exclude_cidrs.append(cidr)
                    seen_cidrs.add(cidr)
        except ValueError:
            rule = f"DOMAIN,{srv},DIRECT"
            if rule not in seen_bypass:
                node_bypass_rules.append(rule)
                seen_bypass.add(rule)
            if tun_enabled:
                try:
                    for info in socket.getaddrinfo(srv, None, socket.AF_INET):
                        r_ip = str(info[4][0])
                        cidr = f"{r_ip}/32"
                        if cidr not in seen_cidrs:
                            tun_exclude_cidrs.append(cidr)
                            seen_cidrs.add(cidr)
                        ip_rule = f"IP-CIDR,{cidr},DIRECT,no-resolve"
                        if ip_rule not in seen_bypass:
                            node_bypass_rules.append(ip_rule)
                            seen_bypass.add(ip_rule)
                except Exception:
                    pass

    tun_process_rules = (
        [
            "PROCESS-NAME,mihomo.exe,DIRECT",
            "PROCESS-NAME,xray.exe,DIRECT",
            "PROCESS-NAME,sing-box.exe,DIRECT",
        ]
        if tun_enabled
        else []
    )

    if routing_mode == "global":
        rules = [
            *tun_process_rules,
            *node_bypass_rules,
            "DOMAIN-SUFFIX,feishu.cn,DIRECT",
            "DOMAIN-SUFFIX,feishucdn.com,DIRECT",
            "DOMAIN-SUFFIX,larksuite.com,DIRECT",
            "IP-CIDR,127.0.0.0/8,DIRECT,no-resolve",
            "IP-CIDR,10.0.0.0/8,DIRECT,no-resolve",
            "IP-CIDR,172.16.0.0/12,DIRECT,no-resolve",
            "IP-CIDR,192.168.0.0/16,DIRECT,no-resolve",
            "MATCH,PROXY",
        ]
    else:
        cn_rules = ["GEOSITE,cn,DIRECT", "GEOIP,CN,DIRECT,no-resolve"] if has_geosite else ["GEOIP,CN,DIRECT,no-resolve"]
        rules = [
            *tun_process_rules,
            *node_bypass_rules,
            *base_direct_rules,
            *cn_rules,
            "MATCH,PROXY",
        ]

    dns_servers = (
        ["system", "223.5.5.5", "1.1.1.1", "8.8.8.8"]
        if for_verify
        else ["223.5.5.5", "119.29.29.29", "114.114.114.114"]
    )
    cfg: dict[str, Any] = {
        "mixed-port": mixed_port,
        "allow-lan": allow_lan,
        "mode": "rule",
        "log-level": "warning",
        "ipv6": False,
        "external-controller": f"127.0.0.1:{controller_port}",
        "unified-delay": True,
        "tcp-concurrent": True,
        "geodata-mode": False if for_verify else True,
        "geo-auto-update": False,
        "find-process-mode": "strict" if tun_enabled else "off",
        "profile": {
            "store-selected": False,
            "store-fake-ip": False,
        },
        "dns": {
            "enable": True,
            "ipv6": False,
            "enhanced-mode": "fake-ip" if tun_enabled else "redir-host",
            "fake-ip-range": "198.18.0.1/16",
            "fake-ip-filter": [
                "*.lan",
                "*.local",
                "localhost.ptlogin2.qq.com",
                "+.msftconnecttest.com",
                "+.msftncsi.com",
                "*.feishu.cn",
                "*.larksuite.com",
            ],
            "default-nameserver": dns_servers,
            "nameserver": dns_servers,
            "proxy-server-nameserver": dns_servers,
        },
        "proxies": proxies,
        "proxy-groups": proxy_groups,
        "rules": rules,
    }

    if tun_enabled:
        cfg["tun"] = {
            "enable": True,
            "stack": "mixed",
            "auto-route": True,
            "auto-detect-interface": True,
            "strict-route": True,
            "route-exclude-address": [
                "127.0.0.0/8",
                "10.0.0.0/8",
                "172.16.0.0/12",
                "192.168.0.0/16",
                *tun_exclude_cidrs,
            ],
            "dns-hijack": ["any:53", "tcp://any:53"],
            "mtu": 1500,
        }
    return cfg


def convert_node_to_singbox_outbound(node: dict[str, Any], tag_override: str = "") -> dict[str, Any]:
    """将统一节点字典转换为 sing-box outbound 格式。"""
    ptype = str(node.get("type", "")).lower()
    tag = tag_override or str(node["name"])
    server = str(node["server"])
    port = int(node["port"])

    def _attach_transport(out_obj: dict[str, Any]) -> None:
        net = str(node.get("network", "tcp")).lower()
        if net == "ws":
            ws_opts = node.get("ws-opts") or {}
            if ws_opts.get("v2ray-http-upgrade"):
                hu: dict[str, Any] = {"type": "httpupgrade", "path": str(ws_opts.get("path", "/"))}
                host = (ws_opts.get("headers") or {}).get("Host")
                if host:
                    hu["host"] = str(host)
                out_obj["transport"] = hu
            else:
                out_obj["transport"] = {
                    "type": "ws",
                    "path": str(ws_opts.get("path", "/")),
                    "headers": ws_opts.get("headers") or {},
                }
        elif net == "grpc":
            grpc_opts = node.get("grpc-opts") or {}
            out_obj["transport"] = {
                "type": "grpc",
                "service_name": str(grpc_opts.get("grpc-service-name", "")),
            }
        elif net == "h2":
            h2_opts = node.get("h2-opts") or {}
            out_obj["transport"] = {
                "type": "http",
                "path": str(h2_opts.get("path", "/")),
                "host": list(h2_opts.get("host") or []),
            }

    if ptype == "vless":
        out: dict[str, Any] = {
            "type": "vless",
            "tag": tag,
            "server": server,
            "server_port": port,
            "uuid": str(node["uuid"]),
        }
        if node.get("flow"):
            out["flow"] = str(node["flow"])
        if node.get("tls"):
            tls_cfg: dict[str, Any] = {
                "enabled": True,
                "server_name": str(node.get("servername") or server),
                "insecure": bool(node.get("skip-cert-verify", False)),
            }
            if node.get("alpn"):
                tls_cfg["alpn"] = list(node["alpn"])
            if node.get("client-fingerprint"):
                tls_cfg["utls"] = {"enabled": True, "fingerprint": str(node["client-fingerprint"])}
            if node.get("reality-opts"):
                ropts = node["reality-opts"]
                tls_cfg["reality"] = {
                    "enabled": True,
                    "public_key": str(ropts.get("public-key", "")),
                    "short_id": str(ropts.get("short-id", "")),
                }
            out["tls"] = tls_cfg
        _attach_transport(out)
        return out

    if ptype == "vmess":
        out = {
            "type": "vmess",
            "tag": tag,
            "server": server,
            "server_port": port,
            "uuid": str(node["uuid"]),
            "security": str(node.get("cipher", "auto")),
            "alter_id": int(node.get("alterId", 0)),
        }
        if node.get("tls"):
            out["tls"] = {
                "enabled": True,
                "server_name": str(node.get("servername") or server),
                "insecure": bool(node.get("skip-cert-verify", False)),
            }
        _attach_transport(out)
        return out

    if ptype == "trojan":
        out = {
            "type": "trojan",
            "tag": tag,
            "server": server,
            "server_port": port,
            "password": str(node["password"]),
            "tls": {
                "enabled": True,
                "server_name": str(node.get("sni") or server),
                "insecure": bool(node.get("skip-cert-verify", False)),
            },
        }
        if node.get("reality-opts"):
            ropts = node["reality-opts"]
            out["tls"]["reality"] = {
                "enabled": True,
                "public_key": str(ropts.get("public-key", "")),
                "short_id": str(ropts.get("short-id", "")),
            }
            out["tls"]["utls"] = {"enabled": True, "fingerprint": str(node.get("client-fingerprint") or "chrome")}
        _attach_transport(out)
        return out

    if ptype == "ss":
        return {
            "type": "shadowsocks",
            "tag": tag,
            "server": server,
            "server_port": port,
            "method": str(node["cipher"]),
            "password": str(node["password"]),
        }

    if ptype == "hysteria2":
        out = {
            "type": "hysteria2",
            "tag": tag,
            "server": server,
            "server_port": port,
            "password": str(node["password"]),
            "tls": {
                "enabled": True,
                "server_name": str(node.get("sni") or server),
                "insecure": bool(node.get("skip-cert-verify", False)),
            },
        }
        if node.get("obfs"):
            out["obfs"] = {
                "type": str(node["obfs"]),
                "password": str(node.get("obfs-password", "")),
            }
        return out

    if ptype == "tuic":
        return {
            "type": "tuic",
            "tag": tag,
            "server": server,
            "server_port": port,
            "uuid": str(node.get("uuid", "")),
            "password": str(node.get("password", "")),
            "congestion_control": str(node.get("congestion-controller", "bbr")),
            "tls": {
                "enabled": True,
                "server_name": str(node.get("sni") or server),
                "insecure": bool(node.get("skip-cert-verify", False)),
            },
        }

    if ptype in ("socks5", "http"):
        out = {
            "type": "socks" if ptype == "socks5" else "http",
            "tag": tag,
            "server": server,
            "server_port": port,
        }
        if node.get("username"):
            out["username"] = str(node["username"])
        if node.get("password"):
            out["password"] = str(node["password"])
        if node.get("tls") and ptype == "http":
            out["tls"] = {
                "enabled": True,
                "insecure": bool(node.get("skip-cert-verify", False)),
            }
        return out

    raise ValueError(f"Unsupported protocol for sing-box: {ptype}")


def build_singbox_config(nodes: list[dict[str, Any]], routing_mode: str = "smart") -> dict[str, Any]:
    """生成 sing-box 通用 JSON 配置（供 Android / iPhone 端的 sing-box 或 Hiddify 客户端一键导入）。"""
    compat_nodes = [n for n in nodes if is_singbox_supported_protocol(n)]
    grouped = group_nodes_by_region(compat_nodes)
    node_outbounds: list[dict[str, Any]] = []
    region_outbounds: list[dict[str, Any]] = []
    region_tags: list[str] = []
    all_tags: list[str] = []

    for region_label, r_nodes in grouped.items():
        r_tags: list[str] = []
        for n in r_nodes:
            sb_out = convert_node_to_singbox_outbound(n)
            node_outbounds.append(sb_out)
            r_tags.append(sb_out["tag"])
            all_tags.append(sb_out["tag"])
        if r_tags:
            region_tags.append(region_label)
            region_outbounds.append(
                {
                    "type": "urltest",
                    "tag": region_label,
                    "outbounds": r_tags,
                    "url": "https://www.gstatic.com/generate_204",
                    "interval": "3m",
                    "tolerance": 50,
                }
            )

    outbounds: list[dict[str, Any]] = []
    if all_tags:
        outbounds.append(
            {
                "type": "selector",
                "tag": "PROXY",
                "outbounds": ["⚡ 自动最快地区", *region_tags, *all_tags, "direct"],
                "default": "⚡ 自动最快地区",
            }
        )
        outbounds.append(
            {
                "type": "urltest",
                "tag": "⚡ 自动最快地区",
                "outbounds": all_tags,
                "url": "https://www.gstatic.com/generate_204",
                "interval": "3m",
                "tolerance": 50,
            }
        )
        outbounds.extend(region_outbounds)
        outbounds.extend(node_outbounds)
    else:
        outbounds.append({"type": "selector", "tag": "PROXY", "outbounds": ["direct"]})

    outbounds.extend(
        [
            {"type": "direct", "tag": "direct"},
            {"type": "block", "tag": "block"},
            {"type": "dns", "tag": "dns-out"},
        ]
    )

    route_rules: list[dict[str, Any]] = [
        {"protocol": "dns", "outbound": "dns-out"},
        {"domain_suffix": ["feishu.cn", "feishucdn.com", "larksuite.com"], "outbound": "direct"},
        {"ip_is_private": True, "outbound": "direct"},
    ]
    if routing_mode != "global":
        route_rules.append({"domain_suffix": ["cn", "qq.com", "weixin.qq.com", "aliyun.com", "taobao.com", "baidu.com"], "outbound": "direct"})

    return {
        "log": {"level": "info"},
        "dns": {
            "servers": [
                {"tag": "remote-dns", "address": "https://1.1.1.1/dns-query", "detour": "PROXY"},
                {"tag": "local-dns", "address": "223.5.5.5", "detour": "direct"},
            ],
            "final": "remote-dns",
        },
        "inbounds": [
            {
                "type": "tun",
                "tag": "tun-in",
                "inet4_address": "172.19.0.1/30",
                "auto_route": True,
                "strict_route": True,
                "sniff": True,
            }
        ],
        "outbounds": outbounds,
        "route": {
            "rules": route_rules,
            "final": "PROXY",
            "auto_detect_interface": True,
        },
    }
