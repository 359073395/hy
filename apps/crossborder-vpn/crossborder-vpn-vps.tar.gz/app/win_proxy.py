"""Windows 系统代理控制、一键网络急救重置与管理员权限(UAC)辅助。"""

from __future__ import annotations

import ctypes
import json
import subprocess
import sys
import threading
from pathlib import Path
from typing import Any

try:
    import winreg
except ImportError:  # Linux / macOS 服务端模式无 winreg 模块
    winreg = None  # type: ignore[assignment]

_INTERNET_SETTINGS_PATH = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
_INTERNET_OPTION_SETTINGS_CHANGED = 39
_INTERNET_OPTION_REFRESH = 37


def is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin(script_path: Path | None = None) -> bool:
    """触发 UAC 提权以管理员身份重启客户端（用于开启 TUN 虚拟网卡模式）。"""
    if getattr(sys, "frozen", False):
        exe = sys.executable
        params = ""
        workdir = str(Path(exe).resolve().parent)
    else:
        exe = sys.executable
        target = script_path or Path(__file__).resolve().parent.parent / "run_client.py"
        params = f'"{target}"'
        workdir = str(target.parent)
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, workdir, 1)
    return int(ret) > 32


def _notify_wininet() -> None:
    def _fire() -> None:
        try:
            wininet = ctypes.windll.wininet
            wininet.InternetSetOptionW(0, _INTERNET_OPTION_SETTINGS_CHANGED, 0, 0)
            wininet.InternetSetOptionW(0, _INTERNET_OPTION_REFRESH, 0, 0)
        except Exception:
            pass

    threading.Thread(target=_fire, daemon=True).start()


def get_active_proxy_url(self_port: int = 17892) -> str | None:
    """若当前系统代理已开启且非本客户端端口，返回 http://host:port 供下载内核或订阅使用。"""
    if sys.platform != "win32" or winreg is None:
        return None
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_READ) as k:
            enable, _ = winreg.QueryValueEx(k, "ProxyEnable")
            if int(enable) != 1:
                return None
            srv, _ = winreg.QueryValueEx(k, "ProxyServer")
            srv = str(srv).strip()
            if srv and f":{self_port}" not in srv:
                return f"http://{srv}" if "://" not in srv else srv
    except Exception:
        return None
    return None


def _read_snapshot() -> dict[str, Any]:
    snap: dict[str, Any] = {"enable": 0, "server": "", "override": "", "auto_config": ""}
    if winreg is None:
        return snap
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_READ) as k:
            for reg_key, field in (
                ("ProxyEnable", "enable"),
                ("ProxyServer", "server"),
                ("ProxyOverride", "override"),
                ("AutoConfigURL", "auto_config"),
            ):
                try:
                    val, _ = winreg.QueryValueEx(k, reg_key)
                    snap[field] = val
                except FileNotFoundError:
                    pass
    except Exception:
        pass
    return snap


def set_system_proxy(port: int, snapshot_file: Path) -> None:
    if sys.platform != "win32" or winreg is None:
        return
    snap = _read_snapshot()
    target = f"127.0.0.1:{port}"
    if snap.get("server") == target:
        snap["enable"] = 0
        snap["server"] = ""

    snapshot_file.parent.mkdir(parents=True, exist_ok=True)
    snapshot_file.write_text(json.dumps(snap, ensure_ascii=False, indent=2), encoding="utf-8")

    # 关键：将飞书告警域名与局域网加入系统代理豁免列表，双重保障故障直连上报
    bypass = "<local>;localhost;127.*;10.*;172.16.*;192.168.*;*.feishu.cn;*.larksuite.com"
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_SET_VALUE) as k:
        winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(k, "ProxyServer", 0, winreg.REG_SZ, target)
        winreg.SetValueEx(k, "ProxyOverride", 0, winreg.REG_SZ, bypass)
        try:
            winreg.DeleteValue(k, "AutoConfigURL")
        except FileNotFoundError:
            pass
    _notify_wininet()


def restore_system_proxy(snapshot_file: Path, self_port: int = 17892) -> None:
    if sys.platform != "win32" or winreg is None:
        return
    if not snapshot_file.exists():
        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE
            ) as k:
                try:
                    srv, _ = winreg.QueryValueEx(k, "ProxyServer")
                    if str(srv).startswith(f"127.0.0.1:{self_port}"):
                        winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 0)
                except FileNotFoundError:
                    pass
        except Exception:
            pass
        _notify_wininet()
        return

    try:
        snap = json.loads(snapshot_file.read_text(encoding="utf-8"))
    except Exception:
        snap = {"enable": 0, "server": "", "override": "", "auto_config": ""}

    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_SET_VALUE) as k:
        winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, int(snap.get("enable", 0)))
        if snap.get("server"):
            winreg.SetValueEx(k, "ProxyServer", 0, winreg.REG_SZ, str(snap["server"]))
        else:
            try:
                winreg.DeleteValue(k, "ProxyServer")
            except FileNotFoundError:
                pass
        if snap.get("override"):
            winreg.SetValueEx(k, "ProxyOverride", 0, winreg.REG_SZ, str(snap["override"]))
        if snap.get("auto_config"):
            winreg.SetValueEx(k, "AutoConfigURL", 0, winreg.REG_SZ, str(snap["auto_config"]))

    try:
        snapshot_file.unlink()
    except Exception:
        pass
    _notify_wininet()


def emergency_network_reset(snapshot_file: Path | None = None) -> str:
    """一键网络急救修复：强制清空系统代理注册表残留 + 刷新 Windows DNS 缓存。"""
    if sys.platform != "win32" or winreg is None:
        return "非 Windows 系统无需重置注册表代理"

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_SET_VALUE) as k:
            winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 0)
            for key_name in ("ProxyServer", "AutoConfigURL"):
                try:
                    winreg.DeleteValue(k, key_name)
                except FileNotFoundError:
                    pass
        if snapshot_file and snapshot_file.exists():
            try:
                snapshot_file.unlink()
            except Exception:
                pass
        _notify_wininet()
    except Exception as exc:
        return f"清理系统代理时出现异常: {exc}"

    try:
        subprocess.run(
            ["ipconfig", "/flushdns"],
            capture_output=True,
            timeout=5,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception:
        pass
    return "已成功清空系统代理残留并刷新本地 DNS 缓存，国内网络已恢复直连"


def cleanup_stale_self_proxy(self_port: int = 17892, snapshot_file: Path | None = None) -> bool:
    """客户端刚启动（尚未连接）时，若注册表仍残留自身上一次异常退出留下的系统代理，自动静默还原。"""
    if sys.platform != "win32" or winreg is None:
        return False
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_READ) as k:
            enable, _ = winreg.QueryValueEx(k, "ProxyEnable")
            if int(enable) != 1:
                return False
            srv, _ = winreg.QueryValueEx(k, "ProxyServer")
            srv_str = str(srv).strip()
        if srv_str.startswith(f"127.0.0.1:{self_port}") or srv_str.startswith("127.0.0.1:17892"):
            if snapshot_file is not None and snapshot_file.exists():
                restore_system_proxy(snapshot_file, self_port=self_port)
            else:
                with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_SET_VALUE) as k:
                    winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 0)
                    try:
                        winreg.DeleteValue(k, "ProxyServer")
                    except FileNotFoundError:
                        pass
                _notify_wininet()
            return True
    except Exception:
        pass
    return False


_JOB_LOCK = threading.Lock()
_JOB_HANDLE: int | None = None


def _ensure_kill_on_close_job() -> int | None:
    """创建 Windows Job Object (JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE)，主进程任何方式退出时自动销毁子内核。"""
    global _JOB_HANDLE
    if sys.platform != "win32":
        return None
    with _JOB_LOCK:
        if _JOB_HANDLE:
            return _JOB_HANDLE
        try:
            import ctypes.wintypes as wt

            k32 = ctypes.WinDLL("kernel32", use_last_error=True)

            class _IO_COUNTERS(ctypes.Structure):
                _fields_ = [
                    ("ReadOperationCount", ctypes.c_uint64),
                    ("WriteOperationCount", ctypes.c_uint64),
                    ("OtherOperationCount", ctypes.c_uint64),
                    ("ReadTransferCount", ctypes.c_uint64),
                    ("WriteTransferCount", ctypes.c_uint64),
                    ("OtherTransferCount", ctypes.c_uint64),
                ]

            class _JOBOBJECT_BASIC_LIMIT_INFORMATION(ctypes.Structure):
                _fields_ = [
                    ("PerProcessUserTimeLimit", ctypes.c_int64),
                    ("PerJobUserTimeLimit", ctypes.c_int64),
                    ("LimitFlags", wt.DWORD),
                    ("MinimumWorkingSetSize", ctypes.c_size_t),
                    ("MaximumWorkingSetSize", ctypes.c_size_t),
                    ("ActiveProcessLimit", wt.DWORD),
                    ("Affinity", ctypes.c_size_t),
                    ("PriorityClass", wt.DWORD),
                    ("SchedulingClass", wt.DWORD),
                ]

            class _JOBOBJECT_EXTENDED_LIMIT_INFORMATION(ctypes.Structure):
                _fields_ = [
                    ("BasicLimitInformation", _JOBOBJECT_BASIC_LIMIT_INFORMATION),
                    ("IoInfo", _IO_COUNTERS),
                    ("ProcessMemoryLimit", ctypes.c_size_t),
                    ("JobMemoryLimit", ctypes.c_size_t),
                    ("PeakProcessMemoryUsed", ctypes.c_size_t),
                    ("PeakJobMemoryUsed", ctypes.c_size_t),
                ]

            k32.CreateJobObjectW.restype = wt.HANDLE
            k32.SetInformationJobObject.argtypes = [wt.HANDLE, wt.INT, wt.LPVOID, wt.DWORD]
            k32.SetInformationJobObject.restype = wt.BOOL
            job = k32.CreateJobObjectW(None, None)
            if not job:
                return None
            info = _JOBOBJECT_EXTENDED_LIMIT_INFORMATION()
            info.BasicLimitInformation.LimitFlags = 0x2000  # JOB_OBJECT_LIMIT_KILL_ON_JOB_CLOSE
            if not k32.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)):
                k32.CloseHandle(job)
                return None
            _JOB_HANDLE = int(job)
            return _JOB_HANDLE
        except Exception:
            return None


def attach_process_to_job(proc: subprocess.Popen[Any] | None) -> bool:
    """将子内核进程绑定到主进程 Job Object，杜绝强杀/闪退后残留孤儿 xray/sing-box/mihomo。"""
    if sys.platform != "win32" or proc is None:
        return False
    handle = getattr(proc, "_handle", None)
    if not handle:
        return False
    job = _ensure_kill_on_close_job()
    if not job:
        return False
    try:
        import ctypes.wintypes as wt

        k32 = ctypes.WinDLL("kernel32", use_last_error=True)
        k32.AssignProcessToJobObject.argtypes = [wt.HANDLE, wt.HANDLE]
        k32.AssignProcessToJobObject.restype = wt.BOOL
        return bool(k32.AssignProcessToJobObject(wt.HANDLE(job), wt.HANDLE(int(handle))))
    except Exception:
        return False
