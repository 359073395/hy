"""Windows 系统代理控制、一键网络急救重置与管理员权限(UAC)辅助。"""

from __future__ import annotations

import ctypes
import json
import subprocess
import sys
from pathlib import Path
from typing import Any

try:
    import winreg
except ImportError:  # Linux / macOS 服务端模式无 winreg 模块
    winreg = None  # type: ignore[assignment]

_INTERNET_SETTINGS_PATH = r"Software\Microsoft\Windows\CurrentVersion\Internet Settings"
_INTERNET_OPTION_SETTINGS_CHANGED = 39
_INTERNET_OPTION_REFRESH = 37


def is_admin() -> bool:
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return False


def relaunch_as_admin(script_path: Path | None = None) -> bool:
    """触发 UAC 提权以管理员身份重启客户端（用于开启 TUN 虚拟网卡模式）。"""
    if getattr(sys, "frozen", False):
        exe = sys.executable
        params = ""
        workdir = str(Path(exe).resolve().parent)
    else:
        exe = sys.executable
        target = script_path or Path(__file__).resolve().parent.parent / "run_client.py"
        params = f'"{target}"'
        workdir = str(target.parent)
    ret = ctypes.windll.shell32.ShellExecuteW(None, "runas", exe, params, workdir, 1)
    return int(ret) > 32


def _notify_wininet() -> None:
    try:
        wininet = ctypes.windll.wininet
        wininet.InternetSetOptionW(0, _INTERNET_OPTION_SETTINGS_CHANGED, 0, 0)
        wininet.InternetSetOptionW(0, _INTERNET_OPTION_REFRESH, 0, 0)
    except Exception:
        pass


def get_active_proxy_url(self_port: int = 17892) -> str | None:
    """若当前系统代理已开启且非本客户端端口，返回 http://host:port 供下载内核或订阅使用。"""
    if sys.platform != "win32" or winreg is None:
        return None
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_READ) as k:
            enable, _ = winreg.QueryValueEx(k, "ProxyEnable")
            if int(enable) != 1:
                return None
            srv, _ = winreg.QueryValueEx(k, "ProxyServer")
            srv = str(srv).strip()
            if srv and f":{self_port}" not in srv:
                return f"http://{srv}" if "://" not in srv else srv
    except Exception:
        return None
    return None


def _read_snapshot() -> dict[str, Any]:
    snap: dict[str, Any] = {"enable": 0, "server": "", "override": "", "auto_config": ""}
    if winreg is None:
        return snap
    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_READ) as k:
            for reg_key, field in (
                ("ProxyEnable", "enable"),
                ("ProxyServer", "server"),
                ("ProxyOverride", "override"),
                ("AutoConfigURL", "auto_config"),
            ):
                try:
                    val, _ = winreg.QueryValueEx(k, reg_key)
                    snap[field] = val
                except FileNotFoundError:
                    pass
    except Exception:
        pass
    return snap


def set_system_proxy(port: int, snapshot_file: Path) -> None:
    if sys.platform != "win32" or winreg is None:
        return
    snap = _read_snapshot()
    target = f"127.0.0.1:{port}"
    if snap.get("server") == target:
        snap["enable"] = 0
        snap["server"] = ""

    snapshot_file.parent.mkdir(parents=True, exist_ok=True)
    snapshot_file.write_text(json.dumps(snap, ensure_ascii=False, indent=2), encoding="utf-8")

    # 关键：将飞书告警域名与局域网加入系统代理豁免列表，双重保障故障直连上报
    bypass = "<local>;localhost;127.*;10.*;172.16.*;192.168.*;*.feishu.cn;*.larksuite.com"
    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_SET_VALUE) as k:
        winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 1)
        winreg.SetValueEx(k, "ProxyServer", 0, winreg.REG_SZ, target)
        winreg.SetValueEx(k, "ProxyOverride", 0, winreg.REG_SZ, bypass)
        try:
            winreg.DeleteValue(k, "AutoConfigURL")
        except FileNotFoundError:
            pass
    _notify_wininet()


def restore_system_proxy(snapshot_file: Path, self_port: int = 17892) -> None:
    if sys.platform != "win32" or winreg is None:
        return
    if not snapshot_file.exists():
        try:
            with winreg.OpenKey(
                winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_READ | winreg.KEY_SET_VALUE
            ) as k:
                try:
                    srv, _ = winreg.QueryValueEx(k, "ProxyServer")
                    if str(srv).startswith(f"127.0.0.1:{self_port}"):
                        winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 0)
                except FileNotFoundError:
                    pass
        except Exception:
            pass
        _notify_wininet()
        return

    try:
        snap = json.loads(snapshot_file.read_text(encoding="utf-8"))
    except Exception:
        snap = {"enable": 0, "server": "", "override": "", "auto_config": ""}

    with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_SET_VALUE) as k:
        winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, int(snap.get("enable", 0)))
        if snap.get("server"):
            winreg.SetValueEx(k, "ProxyServer", 0, winreg.REG_SZ, str(snap["server"]))
        else:
            try:
                winreg.DeleteValue(k, "ProxyServer")
            except FileNotFoundError:
                pass
        if snap.get("override"):
            winreg.SetValueEx(k, "ProxyOverride", 0, winreg.REG_SZ, str(snap["override"]))
        if snap.get("auto_config"):
            winreg.SetValueEx(k, "AutoConfigURL", 0, winreg.REG_SZ, str(snap["auto_config"]))

    try:
        snapshot_file.unlink()
    except Exception:
        pass
    _notify_wininet()


def emergency_network_reset(snapshot_file: Path | None = None) -> str:
    """一键网络急救修复：强制清空系统代理注册表残留 + 刷新 Windows DNS 缓存。"""
    if sys.platform != "win32" or winreg is None:
        return "非 Windows 系统无需重置注册表代理"

    try:
        with winreg.OpenKey(winreg.HKEY_CURRENT_USER, _INTERNET_SETTINGS_PATH, 0, winreg.KEY_SET_VALUE) as k:
            winreg.SetValueEx(k, "ProxyEnable", 0, winreg.REG_DWORD, 0)
            for key_name in ("ProxyServer", "AutoConfigURL"):
                try:
                    winreg.DeleteValue(k, key_name)
                except FileNotFoundError:
                    pass
        if snapshot_file and snapshot_file.exists():
            try:
                snapshot_file.unlink()
            except Exception:
                pass
        _notify_wininet()
    except Exception as exc:
        return f"清理系统代理时出现异常: {exc}"

    try:
        subprocess.run(
            ["ipconfig", "/flushdns"],
            capture_output=True,
            timeout=5,
            creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0),
        )
    except Exception:
        pass
    return "已成功清空系统代理残留并刷新本地 DNS 缓存，国内网络已恢复直连"
