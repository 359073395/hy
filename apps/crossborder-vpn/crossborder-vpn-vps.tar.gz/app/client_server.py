"""Windows 员工端极简一键 VPN 客户端本地服务：
- 采用「姓名/工号 + 专属激活码」授权激活（不限设备数，异常地区/外泄可由管理员在后台一键封禁并立即断网失效）
- 节点配置与个人飞书 Webhook 均使用加密包 (client_bundle.dat) 内存解密运行，不落地明文，零网速损耗
- 支持多备用 VPS 地址与动态导航发现 (discovery_url)，换 VPS 无需重发安装包，且内置飞书绑定永不掉绑
- 自动巡检 + 全自动静默故障上报个人飞书，员工端仅展示友好提示
"""

from __future__ import annotations

import base64
import concurrent.futures
import datetime
import hashlib
import http.server
import json
import os
import platform
import subprocess
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

from app import __version__, crypto_store, feishu_notifier, mihomo_engine, node_parser, win_proxy


def _parse_ver_tuple(ver: str) -> tuple[int, ...]:
    parts: list[int] = []
    for p in str(ver or "0").strip().lstrip("vV").split("."):
        digits = "".join(ch for ch in p if ch.isdigit())
        parts.append(int(digits) if digits else 0)
    return tuple(parts or [0])


def resolve_client_data_dir(base_dir: Path) -> Path:
    """标准安装版将员工授权与加密缓存放在 %LOCALAPPDATA%\\RunliangVPN\\data，避免重装/升级覆盖丢失授权，也无需安装目录写权限。"""
    is_installed = (base_dir / "installed.marker").is_file() or (
        getattr(sys, "frozen", False) and "program files" in str(base_dir).lower()
    )
    if is_installed and sys.platform == "win32":
        local_app = os.environ.get("LOCALAPPDATA") or str(Path.home() / "AppData" / "Local")
        return Path(local_app) / "RunliangVPN" / "data"
    return base_dir / "data"


class ClientManager:
    def __init__(self, base_dir: Path) -> None:
        self.base_dir = base_dir
        self.data_dir = resolve_client_data_dir(base_dir)
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.profile_file = self.data_dir / "client_profile.json"
        self.bundle_dat_file = self.data_dir / "client_bundle.dat"
        self.hub_store_file = self.data_dir / "hub_store.json"

        self.engine = mihomo_engine.MihomoEngine(
            base_dir=base_dir,
            mixed_port=17892,
            controller_port=19092,
            data_dir=self.data_dir,
        )
        # 启动自愈：若上次异常关机/强杀留下指向自身 17892 的系统代理，立即自动清理恢复上网
        win_proxy.cleanup_stale_self_proxy(
            self_port=self.engine.mixed_port,
            snapshot_file=self.engine.snapshot_file,
        )
        self._lock = threading.Lock()
        self.profile = self._load_profile()
        self.device_id = self._ensure_device_id()
        self.bundle = self._load_bundle()
        self.last_health: dict[str, Any] = {"ok": True, "delay": 0, "message": "准备就绪 · 点击连接即可使用"}
        self.banned_message: str = ""
        self.force_update_info: dict[str, Any] | None = None

        self._should_be_connected: bool = False
        self._action_seq: int = 0
        self._last_report_ts: dict[str, float] = {}
        self._live_delays: dict[str, int] = {}
        self._probing: bool = False
        self._probe_lock = threading.Lock()
        self._local_exe_sha256_cache: str | None = None
        self._upgrade_state: dict[str, Any] = {
            "running": False,
            "ok": None,
            "progress": 0,
            "downloaded_mb": 0.0,
            "total_mb": 0.0,
            "message": "",
            "error": "",
        }
        self._on_quit_cb: Any = None
        self._on_focus_cb: Any = None
        self._stop_watchdog = threading.Event()
        self._watchdog_thread = threading.Thread(target=self._watchdog_loop, daemon=True)
        self._watchdog_thread.start()

    def _load_profile(self) -> dict[str, Any]:
        default = {
            "employee": "",
            "activation_code": "",
            "hub_url": "",
            "selected_region": "⚡ 自动最快地区",
            "selected_node": "",
            "routing_mode": "smart",
            "tun_enabled": False,
            "port_only_mode": False,
        }
        if self.profile_file.exists():
            try:
                data = json.loads(self.profile_file.read_text(encoding="utf-8"))
                default.update(data)
            except Exception:
                pass
        return default

    def save_profile(self) -> None:
        self.profile_file.write_text(
            json.dumps(self.profile, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )

    def _ensure_device_id(self) -> str:
        did = str(self.profile.get("device_id") or "").strip().lower()
        if did:
            return did
        import uuid
        raw = f"{platform.node()}::{uuid.getnode()}::{os.environ.get('USERNAME', '')}"
        did = "win-" + hashlib.sha1(raw.encode("utf-8", errors="ignore")).hexdigest()[:12]
        self.profile["device_id"] = did
        try:
            self.save_profile()
        except Exception:
            pass
        return did

    def is_autostart_enabled(self) -> bool:
        if sys.platform != "win32":
            return False
        try:
            import winreg
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, r"Software\Microsoft\Windows\CurrentVersion\Run", 0, winreg.KEY_READ) as k:
                val, _ = winreg.QueryValueEx(k, "CompanyVPN")
                return bool(str(val or "").strip())
        except Exception:
            return False

    def set_autostart(self, enabled: bool) -> tuple[bool, str]:
        if sys.platform != "win32":
            return False, "仅 Windows 支持开机自启"
        try:
            import winreg
            key_path = r"Software\Microsoft\Windows\CurrentVersion\Run"
            with winreg.OpenKey(winreg.HKEY_CURRENT_USER, key_path, 0, winreg.KEY_SET_VALUE) as k:
                if enabled:
                    if getattr(sys, "frozen", False):
                        cmd = f'"{Path(sys.executable).resolve()}" --minimized'
                    else:
                        cmd = f'"{Path(sys.executable).resolve()}" "{(self.base_dir / "run_client.py").resolve()}" --minimized'
                    winreg.SetValueEx(k, "CompanyVPN", 0, winreg.REG_SZ, cmd)
                else:
                    try:
                        winreg.DeleteValue(k, "CompanyVPN")
                    except FileNotFoundError:
                        pass
            self.profile["autostart"] = bool(enabled)
            self.save_profile()
            return True, "已开启随 Windows 开机自启（静默缩小到托盘）" if enabled else "已关闭开机自启"
        except Exception as exc:
            return False, f"设置开机自启失败: {exc}"

    def heartbeat_hub(self) -> None:
        """25 秒轻量化心跳校验（<=1KB），发现封禁或强更要求立即处理。"""
        emp = (self.profile.get("employee") or "").strip()
        code = (self.profile.get("activation_code") or "").strip().upper()
        if not emp or not code:
            return
        payload = json.dumps(
            {
                "employee": emp,
                "activation_code": code,
                "device_id": self.device_id,
                "app_version": __version__,
            },
            ensure_ascii=False,
        ).encode("utf-8")
        direct_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for hub_url in self._collect_hub_candidates():
            req = urllib.request.Request(
                f"{hub_url}/api/client/heartbeat",
                data=payload,
                headers={"Content-Type": "application/json; charset=utf-8"},
                method="POST",
            )
            try:
                with direct_opener.open(req, timeout=3.0) as resp:
                    res = json.loads(resp.read().decode("utf-8", errors="ignore"))
                if res.get("ok"):
                    new_notice = str(res.get("notice") or "").strip()
                    if new_notice != str(self.bundle.get("notice") or "").strip():
                        self.bundle["notice"] = new_notice
                        crypto_store.save_encrypted_file(self.bundle_dat_file, self.bundle)
                    min_v = str(res.get("min_client_version") or "").strip()
                    rem_v = str(res.get("app_version") or "").strip()
                    force_flg = bool(res.get("force_update", False))
                    need_force = False
                    if min_v and _parse_ver_tuple(__version__) < _parse_ver_tuple(min_v):
                        need_force = True
                    elif force_flg and rem_v and _parse_ver_tuple(__version__) < _parse_ver_tuple(rem_v):
                        need_force = True
                    if need_force:
                        self.force_update_info = {
                            "required": True,
                            "min_version": min_v or rem_v,
                            "remote_version": rem_v or min_v,
                        }
                    else:
                        self.force_update_info = None
                    return
            except urllib.error.HTTPError as exc:
                if exc.code == 403:
                    try:
                        err_obj = json.loads(exc.read().decode("utf-8", errors="ignore"))
                        if err_obj.get("banned"):
                            self._wipe_nodes_on_ban(str(err_obj.get("error") or "员工账号已被管理员封禁"))
                    except Exception:
                        pass
                    return
            except Exception:
                continue

    def get_diagnostics(self) -> dict[str, Any]:
        """本机排障自检：系统时间偏差、代理端口占用、内核运行态与最近错误日志。"""
        import email.utils
        import socket
        clock_skew_sec: int | None = None
        clock_msg = "未能连接管控端校时"
        hub_reachable = False
        direct_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for hub_url in self._collect_hub_candidates():
            try:
                req = urllib.request.Request(f"{hub_url}/api/public/site_info", method="GET")
                with direct_opener.open(req, timeout=3.0) as resp:
                    hub_reachable = True
                    date_hdr = resp.headers.get("Date")
                    if date_hdr:
                        srv_dt = email.utils.parsedate_to_datetime(date_hdr)
                        skew = abs(int(datetime.datetime.now(datetime.timezone.utc).timestamp() - srv_dt.timestamp()))
                        clock_skew_sec = skew
                        clock_msg = f"正常（偏差 {skew} 秒）" if skew <= 60 else f"⚠️ 偏差 {skew} 秒（大于 60 秒将导致 Reality/TLS/VMess 全部失效，请校准电脑系统时间！）"
                    break
            except Exception:
                continue

        port_in_use = False
        try:
            with socket.create_connection(("127.0.0.1", self.engine.mixed_port), timeout=0.3):
                port_in_use = True
        except Exception:
            port_in_use = False

        active_node, _ = self.engine.get_active_node_info() if self.engine.is_running() else ("", {})
        return {
            "ok": True,
            "app_version": __version__,
            "device_id": self.device_id,
            "hub_reachable": hub_reachable,
            "clock_ok": True if clock_skew_sec is None else clock_skew_sec <= 60,
            "clock_skew_sec": clock_skew_sec,
            "clock_message": clock_msg,
            "mixed_port": self.engine.mixed_port,
            "port_listening": port_in_use,
            "engine_running": self.engine.is_running(),
            "active_node": active_node,
            "is_admin": win_proxy.is_admin(),
            "autostart": self.is_autostart_enabled(),
            "recent_logs": self.engine.get_recent_logs(12),
        }

    def _load_bundle(self) -> dict[str, Any]:
        return crypto_store.load_client_bundle(self.base_dir, data_dir=self.data_dir)

    def _canonicalize_region(self, region: str) -> str:
        reg = (region or "").strip()
        if not reg or reg == "⚡ 自动最快地区":
            return reg
        grouped = node_parser.group_nodes_by_region(self.bundle.get("nodes", []))
        if reg in grouped:
            return reg
        mapped = node_parser.detect_region("", "", explicit_region=reg)
        if mapped in grouped:
            return mapped
        return reg

    def _collect_hub_candidates(self, extra_url: str = "") -> list[str]:
        """收集按优先级排列的管控后台地址列表（当前配置 -> 内置主VPS -> 备用VPS -> 动态导航地址 -> 本机默认）。"""
        raw_urls: list[str] = []
        for u in (
            extra_url,
            self.profile.get("hub_url", ""),
            self.bundle.get("hub_url", ""),
        ):
            if u and str(u).strip():
                raw_urls.append(str(u).strip().rstrip("/"))

        backups = str(self.bundle.get("backup_hub_urls") or "")
        for part in backups.replace("\n", ",").split(","):
            p = part.strip().rstrip("/")
            if p:
                raw_urls.append(p)

        # 若配置了动态导航地址（如 Gitee/Gist/OSS 纯文本），尝试拉取最新 VPS 地址
        disc_url = str(self.bundle.get("discovery_url") or "").strip()
        if disc_url:
            try:
                opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
                req = urllib.request.Request(disc_url, headers={"User-Agent": "CrossBorderVPN/2.0"})
                with opener.open(req, timeout=2.5) as resp:
                    txt = resp.read().decode("utf-8", errors="ignore").strip()
                if txt.startswith("{"):
                    j = json.loads(txt)
                    cand = str(j.get("hub_url") or j.get("url") or "").strip().rstrip("/")
                    if cand:
                        raw_urls.insert(0, cand)
                elif txt.startswith(("http://", "https://")):
                    first_line = txt.splitlines()[0].strip().rstrip("/")
                    raw_urls.insert(0, first_line)
            except Exception:
                pass

        raw_urls.append("http://127.0.0.1:18800")

        seen: set[str] = set()
        out: list[str] = []
        for u in raw_urls:
            if u not in seen:
                seen.add(u)
                out.append(u)
        return out

    def _wipe_nodes_on_ban(self, reason_msg: str) -> None:
        self._should_be_connected = False
        self.engine.stop()
        self.banned_message = reason_msg
        self.profile["activation_code"] = ""
        self.save_profile()
        # 清空本地节点缓存并打上封禁清空标记，防止回退读取内置包；保留飞书通道以防断绑
        self.bundle["nodes"] = []
        self.bundle["wiped_on_ban"] = True
        crypto_store.save_encrypted_file(self.bundle_dat_file, self.bundle)

    def sync_from_hub(self, strict_auth: bool = False) -> tuple[bool, str]:
        """从管控后台同步加密节点与最新设置（强制走直连，支持主备 VPS 自动切换）。"""
        self.bundle = self._load_bundle()
        emp = (self.profile.get("employee") or "").strip()
        act_code = (self.profile.get("activation_code") or "").strip().upper()
        if not emp or not act_code:
            nodes_cnt = len(self.bundle.get("nodes", []))
            return False if strict_auth else True, f"请先输入姓名与激活码（当前缓存 {nodes_cnt} 条）"

        payload = {
            "employee": emp,
            "activation_code": act_code,
            "device": f"Windows ({platform.node()})",
            "device_id": self.device_id,
            "platform": "Windows",
            "current_region": self.profile.get("selected_region", "⚡ 自动最快地区"),
        }
        body_bytes = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        direct_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))

        last_err = ""
        for hub_url in self._collect_hub_candidates():
            req = urllib.request.Request(
                f"{hub_url}/api/client/bootstrap",
                data=body_bytes,
                headers={"Content-Type": "application/json; charset=utf-8"},
                method="POST",
            )
            try:
                with direct_opener.open(req, timeout=3.5) as resp:
                    res = json.loads(resp.read().decode("utf-8", errors="ignore"))
                if res.get("ok"):
                    self.banned_message = ""
                    # 若成功连上了备用或新的导航 VPS，自动记忆新地址
                    if self.profile.get("hub_url") != hub_url and hub_url != "http://127.0.0.1:18800":
                        self.profile["hub_url"] = hub_url
                        self.save_profile()

                    decoded_payload = res
                    if res.get("encrypted_bundle"):
                        decoded_payload = crypto_store.decrypt_json(res["encrypted_bundle"])

                    # 关键：保留已内置的飞书 Webhook，永不因切换空 VPS 而覆盖丢绑
                    for k in ("company_name", "notice", "feishu_webhook", "feishu_secret", "hub_url", "backup_hub_urls", "discovery_url"):
                        val = decoded_payload.get(k)
                        if val:
                            self.bundle[k] = val
                    if isinstance(decoded_payload.get("nodes"), list):
                        self.bundle["nodes"] = decoded_payload["nodes"]
                    self.bundle["wiped_on_ban"] = False

                    crypto_store.save_encrypted_file(self.bundle_dat_file, self.bundle)
                    return True, f"已同步最新云端线路 ({len(self.bundle.get('nodes', []))} 条)"
            except urllib.error.HTTPError as exc:
                try:
                    err_body = exc.read().decode("utf-8", errors="ignore")
                finally:
                    exc.close()
                try:
                    err_json = json.loads(err_body)
                    err_msg = str(err_json.get("error") or "授权校验未通过")
                    is_banned = bool(err_json.get("banned"))
                except Exception:
                    err_msg = f"授权校验失败 ({exc.code})"
                    is_banned = exc.code == 403
                if exc.code == 403:
                    if is_banned:
                        self._wipe_nodes_on_ban(err_msg)
                    return False, err_msg
                last_err = err_msg
            except Exception as exc:
                last_err = str(exc)

        if strict_auth and last_err:
            # 若明确指定了远程服务器但完全连不上，若有本地有效加密包允许离线兜底，否则报错
            if self.bundle.get("nodes"):
                return True, f"云端暂不可达，已启用本地加密缓存线路 ({len(self.bundle['nodes'])} 条)"
            return False, f"无法连接公司服务器: {last_err}"

        nodes_cnt = len(self.bundle.get("nodes", []))
        return True, f"已加载本地加密线路 ({nodes_cnt} 条)"

    def get_status(self) -> dict[str, Any]:
        self.bundle = self._load_bundle()
        raw_nodes = self.bundle.get("nodes", [])
        grouped = node_parser.group_nodes_by_region(raw_nodes)

        active_node = ""
        live_delays: dict[str, int] = {}
        if self.engine.is_running():
            active_node, live_delays = self.engine.get_active_node_info()

        regions: list[dict[str, Any]] = []
        all_node_names: set[str] = set()
        for r, r_nodes in grouped.items():
            node_items: list[dict[str, Any]] = []
            positive_delays: list[int] = []
            has_failed = False
            for n in r_nodes:
                n_name = str(n.get("name", ""))
                all_node_names.add(n_name)
                delay_val = live_delays.get(n_name)
                if delay_val is None and n_name in self._live_delays:
                    delay_val = self._live_delays[n_name]
                if delay_val is None and isinstance(n.get("real_delay"), int) and n["real_delay"] != 0:
                    delay_val = n["real_delay"]
                final_delay = int(delay_val) if delay_val is not None else 0
                if final_delay > 0:
                    positive_delays.append(final_delay)
                elif final_delay == -1:
                    has_failed = True
                node_items.append(
                    {
                        "id": n.get("id", ""),
                        "name": n_name,
                        "type": str(n.get("type", "")).upper(),
                        "region": r,
                        "delay": final_delay,
                    }
                )
            best_delay = min(positive_delays) if positive_delays else (-1 if has_failed else 0)
            regions.append(
                {
                    "region": r,
                    "count": len(node_items),
                    "best_delay": best_delay,
                    "protocols": sorted({item["type"] for item in node_items}),
                    "nodes": node_items,
                }
            )

        selected = self.profile.get("selected_region") or "⚡ 自动最快地区"
        valid_names = {"⚡ 自动最快地区", *[r["region"] for r in regions]}
        if selected not in valid_names:
            selected = "⚡ 自动最快地区"
            self.profile["selected_region"] = selected

        selected_node = self.profile.get("selected_node") or ""
        if selected_node and selected_node not in all_node_names:
            selected_node = ""
            self.profile["selected_node"] = ""

        emp = (self.profile.get("employee") or "").strip()
        act_code = (self.profile.get("activation_code") or "").strip()

        return {
            "ok": True,
            "company_name": self.bundle.get("company_name", "跑量众创 · 内部专线 VPN"),
            "notice": self.bundle.get("notice", ""),
            "employee": emp,
            "activation_code": act_code,
            "group_name": self.bundle.get("group_name", ""),
            "activated": bool(emp and act_code and not self.banned_message),
            "banned_message": self.banned_message,
            "hub_url": self.profile.get("hub_url") or self.bundle.get("hub_url") or "",
            "feishu_configured": bool((self.bundle.get("feishu_webhook") or "").strip()),
            "connected": self.engine.is_running(),
            "uptime": self.engine.get_uptime_seconds(),
            "selected_region": selected,
            "selected_node": selected_node,
            "active_node": active_node,
            "routing_mode": self.profile.get("routing_mode", "smart"),
            "tun_enabled": bool(self.profile.get("tun_enabled", False)),
            "port_only_mode": bool(self.profile.get("port_only_mode", False)),
            "mixed_port": self.engine.mixed_port,
            "controller_port": self.engine.controller_port,
            "is_admin": win_proxy.is_admin(),
            "autostart": self.is_autostart_enabled(),
            "device_id": self.device_id,
            "force_update_info": self.force_update_info,
            "core_ready": self.engine.is_core_ready(),
            "probing": self._probing,
            "app_version": __version__,
            "node_count": len(all_node_names),
            "regions": regions,
            "last_health": self.last_health,
        }

    def _get_local_exe_sha256(self) -> str:
        if not getattr(sys, "frozen", False):
            return ""
        if self._local_exe_sha256_cache is not None:
            return self._local_exe_sha256_cache
        try:
            h = hashlib.sha256()
            with Path(sys.executable).resolve().open("rb") as fp:
                while True:
                    chunk = fp.read(262144)
                    if not chunk:
                        break
                    h.update(chunk)
            self._local_exe_sha256_cache = h.hexdigest()
            return self._local_exe_sha256_cache
        except Exception:
            return ""

    def get_upgrade_status(self) -> dict[str, Any]:
        return {"ok": True, **self._upgrade_state}

    def check_for_update(self) -> dict[str, Any]:
        """向当前可用的管控后台查询是否有新版客户端（强制走直连）。"""
        direct_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        local_sha = self._get_local_exe_sha256()
        for hub_url in self._collect_hub_candidates():
            try:
                req = urllib.request.Request(f"{hub_url}/api/client/version", method="GET")
                with direct_opener.open(req, timeout=3.5) as resp:
                    data = json.loads(resp.read().decode("utf-8", errors="ignore"))
                if not data.get("ok"):
                    continue
                remote_ver = str(data.get("version") or "").strip()
                dl_url = str(data.get("download_url") or "").strip()
                remote_sha = str(data.get("exe_sha256") or "").strip().lower()
                pkg_type = str(data.get("package_type") or "exe").strip().lower()
                if dl_url.startswith("/"):
                    dl_url = f"{hub_url}{dl_url}"

                if local_sha and remote_sha and local_sha == remote_sha:
                    has_new = False
                elif (
                    remote_sha
                    and remote_sha == str(self.profile.get("installed_exe_sha256") or "").lower()
                    and remote_ver == str(self.profile.get("installed_remote_version") or "")
                ):
                    has_new = False
                elif (
                    local_sha
                    and local_sha == str(self.profile.get("installed_exe_sha256") or "").lower()
                    and remote_ver
                    and remote_ver == str(self.profile.get("installed_remote_version") or "")
                ):
                    has_new = False
                else:
                    min_ver = str(data.get("min_client_version") or "").strip()
                    below_min = bool(min_ver) and _parse_ver_tuple(__version__) < _parse_ver_tuple(min_ver)
                    has_new = bool(dl_url) and (below_min or _parse_ver_tuple(remote_ver) > _parse_ver_tuple(__version__))

                return {
                    "ok": True,
                    "current_version": __version__,
                    "remote_version": remote_ver or __version__,
                    "has_update": has_new,
                    "changelog": str(data.get("changelog") or ""),
                    "download_url": dl_url,
                    "remote_sha256": remote_sha,
                    "package_type": pkg_type,
                    "force_update": bool(data.get("force_update", False)),
                    "min_client_version": str(data.get("min_client_version") or ""),
                }
            except Exception:
                continue
        return {"ok": True, "current_version": __version__, "has_update": False}

    def start_online_upgrade(self, download_url: str = "") -> dict[str, Any]:
        """在后台线程异步下载并执行热升级，避免前端请求 85MB 安装包时超时。"""
        if not getattr(sys, "frozen", False):
            return {"ok": False, "error": "当前为源码运行模式，直接拉取或重启即可；员工端 .exe 支持一键在线升级"}
        if self._upgrade_state.get("running"):
            return {**self._upgrade_state, "ok": True, "started": False}
        self._upgrade_state = {
            "running": True,
            "ok": None,
            "progress": 0,
            "downloaded_mb": 0.0,
            "total_mb": 0.0,
            "message": "正在连接服务器下载新版客户端...",
            "error": "",
        }
        threading.Thread(
            target=self.perform_online_upgrade,
            kwargs={"download_url": download_url},
            daemon=True,
        ).start()
        return {**self._upgrade_state, "ok": True, "started": True}

    def perform_online_upgrade(self, download_url: str = "") -> dict[str, Any]:
        """在线下载新版 CompanyVPN.exe 并无感替换重启（支持中文路径、进度显示，免重新激活）。"""
        if not getattr(sys, "frozen", False):
            res = {"ok": False, "error": "当前为源码运行模式，直接拉取或重启即可；员工端 .exe 支持一键在线升级"}
            self._upgrade_state.update({"running": False, "ok": False, "error": res["error"]})
            return res

        dl_url = download_url.strip()
        remote_ver = ""
        expected_sha = ""
        pkg_type = "exe"
        try:
            info = self.check_for_update()
            if not dl_url:
                dl_url = str(info.get("download_url") or "")
            remote_ver = str(info.get("remote_version") or "")
            expected_sha = str(info.get("remote_sha256") or "").lower()
            pkg_type = str(info.get("package_type") or "exe").lower()
        except Exception:
            pass
        if not dl_url:
            err = "未找到可用的升级包地址"
            self._upgrade_state.update({"running": False, "ok": False, "error": err})
            return {"ok": False, "error": err}

        current_exe = Path(sys.executable).resolve()
        tmp_dl_exe = self.data_dir / "CompanyVPN_download.tmp"
        update_exe = self.data_dir / "CompanyVPN_update.exe"
        direct_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        is_setup_installer = pkg_type == "setup" or "setup" in dl_url.lower()
        try:
            req = urllib.request.Request(dl_url, headers={"User-Agent": "CrossBorderVPN-Updater/1.2"})
            h = hashlib.sha256()
            downloaded = 0
            with direct_opener.open(req, timeout=120.0) as resp:
                total_hdr = int(resp.headers.get("Content-Length") or 0)
                total_mb = round(total_hdr / (1024 * 1024), 1) if total_hdr > 0 else 0.0
                self._upgrade_state["total_mb"] = total_mb
                with tmp_dl_exe.open("wb") as fp:
                    while True:
                        chunk = resp.read(131072)
                        if not chunk:
                            break
                        fp.write(chunk)
                        h.update(chunk)
                        downloaded += len(chunk)
                        dl_mb = round(downloaded / (1024 * 1024), 1)
                        pct = int(min(99, (downloaded * 100) / total_hdr)) if total_hdr > 0 else 0
                        self._upgrade_state.update(
                            {
                                "progress": pct,
                                "downloaded_mb": dl_mb,
                                "message": f"正在下载新版 {pct}% ({dl_mb}/{total_mb} MB)..." if total_mb else f"正在下载新版 ({dl_mb} MB)...",
                            }
                        )
            if total_hdr > 0 and downloaded < total_hdr:
                raise RuntimeError(f"下载未完整 ({downloaded}/{total_hdr} 字节)，请重试")
            with tmp_dl_exe.open("rb") as fp:
                head_probe = fp.read(2 * 1024 * 1024)
            if tmp_dl_exe.stat().st_size < 1_000_000 or head_probe[:2] != b"MZ":
                raise RuntimeError("下载的升级包格式校验失败，请确认后台上传了正确的 Windows 安装程序")
            if b"Inno Setup" in head_probe:
                is_setup_installer = True
            actual_sha = h.hexdigest().lower()
            if expected_sha and actual_sha != expected_sha:
                raise RuntimeError("下载包 SHA256 校验不一致，请重新点击升级")
            tmp_dl_exe.replace(update_exe)
        except Exception as exc:
            tmp_dl_exe.unlink(missing_ok=True)
            update_exe.unlink(missing_ok=True)
            err = f"下载更新包失败: {exc}"
            self._upgrade_state.update({"running": False, "ok": False, "error": err, "message": ""})
            return {"ok": False, "error": err}

        if remote_ver:
            self.profile["installed_remote_version"] = remote_ver
        self.profile["installed_exe_sha256"] = actual_sha
        self.save_profile()

        self._upgrade_state.update(
            {"running": True, "ok": True, "progress": 100, "message": "下载完成，正在自动安装并重启客户端..."}
        )

        def _do_swap_and_exit() -> None:
            time.sleep(0.7)
            try:
                self.disconnect()
            except Exception:
                pass
            cur_escaped = str(current_exe).replace("'", "''")
            upd_escaped = str(update_exe).replace("'", "''")
            work_escaped = str(current_exe.parent).replace("'", "''")
            pid = os.getpid()
            if is_setup_installer:
                ps_script = (
                    f"$pidToWait = {pid}\n"
                    "$cur = '" + cur_escaped + "'\n"
                    "$upd = '" + upd_escaped + "'\n"
                    "$wd  = '" + work_escaped + "'\n"
                    "for ($i = 0; $i -lt 40; $i++) {\n"
                    "  if (-not (Get-Process -Id $pidToWait -ErrorAction SilentlyContinue)) { break }\n"
                    "  Start-Sleep -Milliseconds 250\n"
                    "}\n"
                    "Start-Sleep -Milliseconds 400\n"
                    "$argsList = @('/VERYSILENT','/SUPPRESSMSGBOXES','/NORESTART','/CLOSEAPPLICATIONS',('/DIR=\"' + $wd + '\"'))\n"
                    "if (Test-Path -LiteralPath $upd) {\n"
                    "  Start-Process -FilePath $upd -ArgumentList $argsList -Wait\n"
                    "  Remove-Item -LiteralPath $upd -Force -ErrorAction SilentlyContinue\n"
                    "}\n"
                    "if (Test-Path -LiteralPath $cur) {\n"
                    "  Start-Process -FilePath $cur -WorkingDirectory $wd\n"
                    "}\n"
                )
            else:
                ps_script = (
                    f"$pidToWait = {pid}\n"
                    "$cur = '" + cur_escaped + "'\n"
                    "$upd = '" + upd_escaped + "'\n"
                    "$wd  = '" + work_escaped + "'\n"
                    "for ($i = 0; $i -lt 40; $i++) {\n"
                    "  if (-not (Get-Process -Id $pidToWait -ErrorAction SilentlyContinue)) { break }\n"
                    "  Start-Sleep -Milliseconds 250\n"
                    "}\n"
                    "Start-Sleep -Milliseconds 500\n"
                    "for ($i = 0; $i -lt 30; $i++) {\n"
                    "  try {\n"
                    "    if (Test-Path -LiteralPath $upd) {\n"
                    "      Move-Item -LiteralPath $upd -Destination $cur -Force -ErrorAction Stop\n"
                    "      break\n"
                    "    }\n"
                    "  } catch {\n"
                    "    Start-Sleep -Milliseconds 400\n"
                    "  }\n"
                    "}\n"
                    "if (Test-Path -LiteralPath $cur) {\n"
                    "  Start-Process -FilePath $cur -WorkingDirectory $wd\n"
                    "}\n"
                )
            encoded = base64.b64encode(ps_script.encode("utf-16le")).decode("ascii")
            creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            try:
                subprocess.Popen(
                    ["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", encoded],
                    cwd=str(self.data_dir),
                    creationflags=creation_flags,
                )
            except Exception:
                swap_bat = self.data_dir / "update_swap.bat"
                if is_setup_installer:
                    bat_content = (
                        "@echo off\r\n"
                        "chcp 65001 >nul\r\n"
                        "ping 127.0.0.1 -n 3 >nul\r\n"
                        f'"{update_exe}" /VERYSILENT /SUPPRESSMSGBOXES /NORESTART /CLOSEAPPLICATIONS /DIR="{current_exe.parent}"\r\n'
                        f'del /f /q "{update_exe}" >nul 2>&1\r\n'
                        f'start "" "{current_exe}"\r\n'
                        'del "%~f0"\r\n'
                    )
                else:
                    bat_content = (
                        "@echo off\r\n"
                        "chcp 65001 >nul\r\n"
                        "ping 127.0.0.1 -n 3 >nul\r\n"
                        "set /a tries=0\r\n"
                        ":retry\r\n"
                        f'move /y "{update_exe}" "{current_exe}" >nul 2>&1\r\n'
                        "if errorlevel 1 (\r\n"
                        "    set /a tries+=1\r\n"
                        "    if %tries% GEQ 25 goto launch\r\n"
                        "    ping 127.0.0.1 -n 2 >nul\r\n"
                        "    goto retry\r\n"
                        ")\r\n"
                        ":launch\r\n"
                        f'start "" "{current_exe}"\r\n'
                        'del "%~f0"\r\n'
                    )
                swap_bat.write_text(bat_content, encoding="utf-8")
                subprocess.Popen(["cmd", "/c", str(swap_bat)], cwd=str(self.data_dir), creationflags=creation_flags)
            time.sleep(0.3)
            os._exit(0)

        threading.Thread(target=_do_swap_and_exit, daemon=True).start()
        return {"ok": True, "message": "升级包已下载，正在自动更新并重启客户端（免重新激活）..."}

    def activate_employee(
        self,
        employee: str,
        activation_code: str = "",
        hub_url: str = "",
    ) -> tuple[bool, str]:
        emp = employee.strip()
        code = activation_code.strip().upper()
        if not emp:
            return False, "请输入您的姓名或工号"
        if not code:
            return False, "请输入管理员发放的专属激活码"

        self.banned_message = ""
        self.profile["employee"] = emp
        self.profile["activation_code"] = code
        if hub_url.strip():
            self.profile["hub_url"] = hub_url.strip().rstrip("/")
        self.save_profile()

        ok, msg = self.sync_from_hub(strict_auth=True)
        if not ok:
            self.profile["activation_code"] = ""
            self.save_profile()
            return False, msg
        return True, f"欢迎使用，{emp}！"

    def auto_check_nodes(self, report_all_down: bool = True) -> dict[str, Any]:
        """自动并发检测所有线路的真实连通性与延迟（无需员工手动点击）。"""
        with self._probe_lock:
            self._probing = True
            try:
                self.bundle = self._load_bundle()
                raw_nodes = self.bundle.get("nodes", [])
                clean_nodes = node_parser.deduplicate_node_names(raw_nodes)
                if not clean_nodes:
                    return {"ok": True, "delays": {}, "status": self.get_status()}

                new_delays: dict[str, int] = {}
                if self.engine.is_running():
                    def _probe_live(n: dict[str, Any]) -> tuple[str, int]:
                        n_name = str(n.get("name", ""))
                        ok, d, _ = self.engine.test_proxy_delay(n_name, timeout_ms=6500)
                        return n_name, (d if ok and d > 0 else -1)

                    with concurrent.futures.ThreadPoolExecutor(max_workers=min(12, len(clean_nodes))) as pool:
                        for n_name, d_ms in pool.map(_probe_live, clean_nodes):
                            new_delays[n_name] = d_ms
                else:
                    real_res, id_core_map = mihomo_engine.test_nodes_real_connection(
                        base_dir=self.base_dir,
                        nodes=clean_nodes,
                        timeout_ms=6500,
                    )
                    bundle_by_id = {str(item.get("id", "")): item for item in raw_nodes}
                    for n in clean_nodes:
                        nid = str(n.get("id", ""))
                        n_name = str(n.get("name", ""))
                        r_delay, _ = real_res.get(nid, (-1, ""))
                        new_delays[n_name] = r_delay if r_delay > 0 else -1
                        if r_delay > 0 and nid in bundle_by_id:
                            bundle_by_id[nid]["resolved_core"] = id_core_map.get(nid, "mihomo")

                self._live_delays = new_delays

                if report_all_down and self.profile.get("employee") and self.profile.get("activation_code"):
                    sel_region = str(self.profile.get("selected_region") or "⚡ 自动最快地区")
                    if sel_region == "⚡ 自动最快地区":
                        target_nodes = clean_nodes
                    else:
                        target_nodes = [n for n in clean_nodes if n.get("region") == sel_region] or clean_nodes
                    any_ok = any(new_delays.get(str(n.get("name", "")), -1) > 0 for n in target_nodes)
                    if target_nodes and not any_ok:
                        self.verify_and_auto_report_if_failed(
                            region=sel_region,
                            node_name=str(target_nodes[0].get("name", "")),
                            user_note=f"客户端自动巡检发现【{sel_region}】全部 {len(target_nodes)} 条线路均不可用",
                            force_report=False,
                        )

                return {"ok": True, "delays": new_delays, "status": self.get_status()}
            finally:
                self._probing = False

    def _pick_representative_node(self, region: str, node_name: str = "") -> dict[str, Any] | None:
        nodes = node_parser.deduplicate_node_names(self.bundle.get("nodes", []))
        if not nodes:
            return None
        if node_name:
            for n in nodes:
                if n.get("name") == node_name:
                    return n
        if region and region != "⚡ 自动最快地区":
            matched = [n for n in nodes if n.get("region") == region]
            if matched:
                return matched[0]
        return nodes[0]

    def verify_and_auto_report_if_failed(
        self,
        region: str,
        node_name: str = "",
        user_note: str = "连接外网时自动检测失败",
        force_report: bool = False,
    ) -> dict[str, Any]:
        proxy_target = node_name or region or "⚡ 自动最快地区"
        target_node = self._pick_representative_node(region, node_name=node_name)
        if not target_node:
            return {
                "ok": False,
                "health_ok": False,
                "auto_reported": False,
                "message": "当前暂无可用线路，请联系管理员配置",
            }

        if not force_report and self.engine.is_running():
            ok, delay, _msg = self.engine.test_proxy_delay(proxy_target, timeout_ms=4500)
            if ok and delay > 0:
                active_n, _ = self.engine.get_active_node_info()
                display_n = active_n or proxy_target
                self.last_health = {
                    "ok": True,
                    "delay": delay,
                    "message": f"外网加速已开启 · 当前线路：{display_n} ({delay}ms)",
                }
                return {
                    "ok": True,
                    "health_ok": True,
                    "delay": delay,
                    "auto_reported": False,
                    "message": self.last_health["message"],
                }

        cooldown_key = f"{region}::{target_node.get('name', '')}"
        now_ts = time.time()
        if not force_report and (now_ts - self._last_report_ts.get(cooldown_key, 0.0)) < 180:
            friendly = "⚠️ 当前线路暂时不可用，已通知管理员处理，请切换其他线路"
            self.last_health = {"ok": False, "delay": -1, "message": friendly}
            return {
                "ok": True,
                "health_ok": False,
                "auto_reported": True,
                "message": friendly,
            }
        self._last_report_ts[cooldown_key] = now_ts

        srv = str(target_node.get("server", ""))
        port = int(target_node.get("port", 443))
        proto = str(target_node.get("type", "vless"))
        actual_node_name = str(target_node.get("name", ""))

        diag = feishu_notifier.diagnose_node_failure(srv, port, protocol=proto, timeout=2.5)
        admin_reason = diag.get("summary", "节点真连接握手失败或超时")
        core_logs = self.engine.get_recent_logs(4)
        if core_logs:
            last_err_lines = [
                ln for ln in core_logs
                if any(k in ln.lower() for k in ("err", "fail", "timeout", "refused", "eof"))
            ]
            if last_err_lines:
                admin_reason = f"{admin_reason} | 内核日志: {last_err_lines[-1][-120:]}"

        emp_label = self.profile.get("employee") or "未填写姓名员工"
        code_label = self.profile.get("activation_code") or ""
        if code_label:
            emp_label = f"{emp_label} ({code_label})"

        report_payload: dict[str, Any] = {
            "employee": emp_label,
            "device": f"Windows ({platform.node()})",
            "region": region,
            "node_name": actual_node_name,
            "protocol": proto.upper(),
            "server_addr": f"{srv}:{port}",
            "reason": admin_reason,
            "user_note": user_note,
            "created_at": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        }

        # 1. 客户端内置飞书 Webhook 强制直连推送（即使更换 VPS 或 VPS 失联也能 100% 推到你的飞书）
        feishu_ok = False
        webhook = (self.bundle.get("feishu_webhook") or "").strip()
        secret = (self.bundle.get("feishu_secret") or "").strip()
        if webhook:
            feishu_ok, _ = feishu_notifier.send_feishu_alert(webhook, report_payload, secret=secret)
            report_payload["already_pushed_feishu"] = feishu_ok

        # 2. 同步静默写入管理后台故障看板（按主备 VPS 候选列表尝试）
        hub_ok = False
        direct_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        for hub_url in self._collect_hub_candidates():
            req = urllib.request.Request(
                f"{hub_url}/api/client/report",
                data=json.dumps(report_payload, ensure_ascii=False).encode("utf-8"),
                headers={"Content-Type": "application/json; charset=utf-8"},
                method="POST",
            )
            try:
                with direct_opener.open(req, timeout=3.5) as resp:
                    res = json.loads(resp.read().decode("utf-8", errors="ignore"))
                    if res.get("ok"):
                        hub_ok = True
                        if res.get("report", {}).get("feishu_pushed"):
                            feishu_ok = True
                        break
            except Exception:
                continue

        if not hub_ok and self.hub_store_file.exists():
            try:
                from app import hub_server
                local_store = hub_server.HubStore(self.data_dir, base_dir=self.base_dir)
                local_store.add_failure_report(report_payload, push_feishu=not feishu_ok)
                hub_ok = True
            except Exception:
                pass

        friendly_msg = "⚠️ 当前线路暂时连接失败，已自动通知管理员处理，请尝试切换其他线路"
        self.last_health = {
            "ok": False,
            "delay": -1,
            "message": friendly_msg,
        }

        return {
            "ok": True,
            "health_ok": False,
            "auto_reported": True,
            "feishu_pushed": feishu_ok,
            "hub_recorded": hub_ok,
            "message": friendly_msg,
        }

    def _rescue_active_group_if_needed(self, target: str, is_manual_node: bool = False) -> tuple[bool, str, int]:
        """只要当前通道可用就保持不变；仅当真正不通且选择了地区/自动组时才顺延切换到同组可用节点。"""
        ok, delay, _ = self.engine.test_proxy_delay(target, timeout_ms=4500)
        if ok and delay > 0:
            active_n, _ = self.engine.get_active_node_info()
            return True, active_n or target, delay

        if is_manual_node:
            return False, target, -1

        now_node, candidates = self.engine.get_group_candidates(target)
        for cand in candidates:
            if cand == now_node:
                continue
            ok_c, d_c, _ = self.engine.test_proxy_delay(cand, timeout_ms=4500)
            if ok_c and d_c > 0:
                if self.engine.select_node_in_group(target, cand):
                    return True, cand, d_c
        return False, now_node or target, -1

    def _watchdog_loop(self) -> None:
        consecutive_fails = 0
        tick_count = 0
        while not self._stop_watchdog.wait(25.0):
            tick_count += 1
            # 每 25 秒轻量心跳秒查封禁状态（发现封禁立刻踢线）；每约 150 秒全量同步一次节点与配置
            if self.profile.get("employee") and self.profile.get("activation_code"):
                self.heartbeat_hub()
                if self.banned_message:
                    consecutive_fails = 0
                    continue
                if tick_count % 6 == 0:
                    ok, _msg = self.sync_from_hub(strict_auth=False)
                    if not ok and self.banned_message:
                        consecutive_fails = 0
                        continue

            if not self._should_be_connected:
                consecutive_fails = 0
                continue

            region = self._canonicalize_region(str(self.profile.get("selected_region") or "⚡ 自动最快地区"))
            sel_node = str(self.profile.get("selected_node") or "")
            target = sel_node or region

            if not self.engine.is_running():
                consecutive_fails = 0
                self._should_be_connected = False
                self.verify_and_auto_report_if_failed(
                    region=region,
                    node_name=sel_node,
                    user_note="员工使用过程中代理内核异常退出（自动巡检上报）",
                    force_report=True,
                )
                continue

            if not self.engine.are_bridges_alive():
                # Xray/sing-box 桥接子进程意外退出时自动拉起自愈，避免无声断流
                nodes = list(self.bundle.get("nodes", []))
                ok_restart, _ = self.engine.start(
                    nodes=nodes,
                    selected_region=target,
                    routing_mode=str(self.profile.get("routing_mode") or "smart"),
                    tun_enabled=bool(self.profile.get("tun_enabled", False)),
                    port_only_mode=bool(self.profile.get("port_only_mode", False)),
                )
                if ok_restart:
                    self._rescue_active_group_if_needed(target, is_manual_node=bool(sel_node))
                    consecutive_fails = 0
                    continue

            ok, delay, _ = self.engine.test_proxy_delay(target, timeout_ms=4500)
            if ok and delay > 0:
                consecutive_fails = 0
                active_n, _ = self.engine.get_active_node_info()
                display_n = active_n or target
                self.last_health = {
                    "ok": True,
                    "delay": delay,
                    "message": f"外网加速已开启 · 当前线路：{display_n} ({delay}ms)",
                }
            else:
                consecutive_fails += 1
                if consecutive_fails >= 2:
                    consecutive_fails = 0
                    rescued_ok, rescued_name, rescued_delay = self._rescue_active_group_if_needed(
                        target, is_manual_node=bool(sel_node)
                    )
                    if rescued_ok:
                        self.last_health = {
                            "ok": True,
                            "delay": rescued_delay,
                            "message": f"原节点波动，已自动切换至：{rescued_name} ({rescued_delay}ms)",
                        }
                        continue
                    self.verify_and_auto_report_if_failed(
                        region=region,
                        node_name=sel_node,
                        user_note="员工连接使用期间线路突然断流/超时（自动巡检上报）",
                        force_report=False,
                    )

    def _schedule_post_action_verify(
        self,
        seq: int,
        region: str,
        node_name: str,
        target: str,
        user_note: str,
        sync_hub_bg: bool = False,
        notify_connect: bool = False,
    ) -> None:
        """异步在后台执行云端校验、自动容灾切换、健康测速与飞书汇报，确保点击/切线零延迟秒响应。"""
        mode = str(self.profile.get("routing_mode") or "smart")
        tun = bool(self.profile.get("tun_enabled", False))

        def _worker() -> None:
            if sync_hub_bg and self.profile.get("employee") and self.profile.get("activation_code"):
                ok_sync, _ = self.sync_from_hub(strict_auth=False)
                if not ok_sync and self.banned_message:
                    return
            if self._action_seq != seq or not self._should_be_connected or not self.engine.is_running():
                return
            _ok_r, active_used, _d_r = self._rescue_active_group_if_needed(target, is_manual_node=bool(node_name))
            if self._action_seq != seq or not self._should_be_connected or not self.engine.is_running():
                return
            check_res = self.verify_and_auto_report_if_failed(
                region=region,
                node_name=node_name,
                user_note=user_note,
                force_report=False,
            )
            if notify_connect and check_res.get("health_ok", True) and self._action_seq == seq:
                self._report_connect_event_async(
                    region=region,
                    active_node=active_used or node_name or target,
                    routing_mode=mode,
                    tun_enabled=tun,
                )

        threading.Thread(target=_worker, daemon=True).start()

    def connect(
        self,
        region: str = "",
        node_name: str | None = None,
        routing_mode: str = "",
        tun_enabled: bool | None = None,
        port_only_mode: bool | None = None,
    ) -> dict[str, Any]:
        emp = (self.profile.get("employee") or "").strip()
        act_code = (self.profile.get("activation_code") or "").strip()
        has_cached_nodes = bool(self.bundle.get("nodes"))
        need_sync_first = bool(self.banned_message) or not emp or not act_code or not has_cached_nodes
        if need_sync_first:
            sync_ok, sync_msg = self.sync_from_hub(strict_auth=True)
            if not sync_ok:
                return {"ok": False, "banned": bool(self.banned_message), "error": sync_msg}

        if region:
            region = self._canonicalize_region(region)
            if region != self.profile.get("selected_region") and node_name is None:
                self.profile["selected_node"] = ""
            self.profile["selected_region"] = region
        else:
            self.profile["selected_region"] = self._canonicalize_region(
                str(self.profile.get("selected_region") or "⚡ 自动最快地区")
            )
        if node_name is not None:
            self.profile["selected_node"] = node_name
        if routing_mode:
            self.profile["routing_mode"] = routing_mode
        if tun_enabled is not None:
            self.profile["tun_enabled"] = bool(tun_enabled)
        if port_only_mode is not None:
            self.profile["port_only_mode"] = bool(port_only_mode)
        self.save_profile()

        nodes = list(self.bundle.get("nodes", []))
        if self._live_delays:
            def _node_sort_key(item: dict[str, Any]) -> tuple[int, int]:
                d = self._live_delays.get(str(item.get("name") or ""), int(item.get("last_delay") or 0))
                if d > 0:
                    return (0, d)
                if d == 0:
                    return (1, 0)
                return (2, 99999)
            nodes.sort(key=_node_sort_key)

        sel_region = self.profile.get("selected_region", "⚡ 自动最快地区")
        sel_node = self.profile.get("selected_node", "")
        target = sel_node or sel_region
        mode = self.profile.get("routing_mode", "smart")
        tun = bool(self.profile.get("tun_enabled", False))
        port_only = bool(self.profile.get("port_only_mode", False))

        self._action_seq += 1
        seq = self._action_seq

        ok, msg = self.engine.start(
            nodes=nodes,
            selected_region=target,
            routing_mode=mode,
            tun_enabled=tun,
            port_only_mode=port_only,
        )
        if not ok:
            self._should_be_connected = False
            self.verify_and_auto_report_if_failed(
                region=sel_region,
                node_name=sel_node,
                user_note=f"员工启动连接失败: {msg}",
                force_report=True,
            )
            return {
                "ok": False,
                "error": "连接启动失败，已自动通知管理员排查，请重试或切换其他线路",
            }

        self._should_be_connected = True
        coexist_hint = f" · 仅端口 {self.engine.mixed_port}" if (port_only and not tun) else ""
        init_msg = f"外网加速已开启 · 正在校验 {target}{coexist_hint}"
        self.last_health = {"ok": True, "delay": 0, "message": init_msg}
        self._schedule_post_action_verify(
            seq=seq,
            region=sel_region,
            node_name=sel_node,
            target=target,
            user_note=f"员工点击连接【{target}】时自动检测不可用",
            sync_hub_bg=not need_sync_first,
            notify_connect=True,
        )
        return {
            "ok": True,
            "connected": True,
            "health_ok": True,
            "auto_reported": False,
            "message": init_msg,
        }

    def _report_connect_event_async(
        self,
        region: str,
        active_node: str,
        routing_mode: str,
        tun_enabled: bool,
    ) -> None:
        emp = (self.profile.get("employee") or "").strip() or "未填写姓名员工"
        code = (self.profile.get("activation_code") or "").strip().upper()
        if not code:
            return
        payload = {
            "employee": emp,
            "activation_code": code,
            "device": f"Windows ({platform.node()})",
            "region": region,
            "active_node": active_node,
            "routing_mode": routing_mode,
            "tun_enabled": tun_enabled,
            "app_version": __version__,
        }
        candidates = self._collect_hub_candidates()
        webhook = (self.bundle.get("feishu_webhook") or "").strip()
        secret = (self.bundle.get("feishu_secret") or "").strip()

        def _worker() -> None:
            direct_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            hub_sent = False
            for hub_url in candidates:
                req = urllib.request.Request(
                    f"{hub_url}/api/client/connect_event",
                    data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
                    headers={"Content-Type": "application/json; charset=utf-8"},
                    method="POST",
                )
                try:
                    with direct_opener.open(req, timeout=4.0) as resp:
                        res = json.loads(resp.read().decode("utf-8", errors="ignore"))
                        if res.get("ok"):
                            hub_sent = True
                            break
                except urllib.error.HTTPError as exc:
                    if exc.code == 403:
                        try:
                            err_obj = json.loads(exc.read().decode("utf-8", errors="ignore"))
                            if err_obj.get("banned"):
                                self._wipe_nodes_on_ban(str(err_obj.get("error") or "账号已被管理员封禁"))
                                return
                        except Exception:
                            pass
                    continue
                except Exception:
                    continue
            if not hub_sent and webhook:
                try:
                    feishu_notifier.send_feishu_connect_notice(webhook, payload, secret=secret)
                except Exception:
                    pass

        threading.Thread(target=_worker, daemon=True).start()

    def disconnect(self) -> dict[str, Any]:
        self._action_seq += 1
        self._should_be_connected = False
        self.engine.stop()
        self.last_health = {"ok": True, "delay": 0, "message": "已断开 · 点击上方按钮一键连接"}
        return {"ok": True, "connected": False, "message": "已断开连接并恢复正常网络"}

    def switch_region(self, region: str, node_name: str = "") -> dict[str, Any]:
        region = self._canonicalize_region(region)
        self.profile["selected_region"] = region
        self.profile["selected_node"] = node_name
        self.save_profile()

        target = node_name or region
        if not self.engine.is_running():
            return {
                "ok": True,
                "connected": False,
                "selected_region": region,
                "selected_node": node_name,
                "message": f"已选定 {target}，点击一键连接即可生效",
            }

        self._action_seq += 1
        seq = self._action_seq
        self.engine.select_region(target)
        msg = f"已切换至 {target} · 正在测速校验..."
        self.last_health = {"ok": True, "delay": 0, "message": msg}
        self._schedule_post_action_verify(
            seq=seq,
            region=region,
            node_name=node_name,
            target=target,
            user_note=f"员工切换至【{target}】时自动检测不可用",
            sync_hub_bg=False,
            notify_connect=False,
        )
        return {
            "ok": True,
            "connected": True,
            "selected_region": region,
            "selected_node": node_name,
            "health_ok": True,
            "auto_reported": False,
            "message": msg,
        }


def create_client_handler(mgr: ClientManager, static_dir: Path):
    class ClientRequestHandler(http.server.BaseHTTPRequestHandler):
        def log_message(self, fmt: str, *args: Any) -> None:
            return

        def _send_json(self, data: Any, status: int = 200) -> None:
            raw = json.dumps(data, ensure_ascii=False).encode("utf-8")
            self.send_response(status)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Length", str(len(raw)))
            self.end_headers()
            self.wfile.write(raw)

        def _read_json_body(self) -> dict[str, Any]:
            length = int(self.headers.get("Content-Length") or 0)
            if length <= 0:
                return {}
            raw = self.rfile.read(length).decode("utf-8", errors="ignore")
            try:
                return json.loads(raw)
            except Exception:
                return {}

        def do_GET(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            if parsed.path in ("/", "/client"):
                html = (static_dir / "client.html").read_text(encoding="utf-8")
                raw = html.encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Content-Length", str(len(raw)))
                self.end_headers()
                self.wfile.write(raw)
                return

            if parsed.path == "/api/status":
                self._send_json(mgr.get_status())
                return

            if parsed.path == "/api/check_update":
                self._send_json(mgr.check_for_update())
                return

            if parsed.path == "/api/upgrade_status":
                self._send_json(mgr.get_upgrade_status())
                return

            if parsed.path == "/api/diagnostics":
                self._send_json(mgr.get_diagnostics())
                return

            self._send_json({"ok": False, "error": "Not found"}, status=404)

        def do_POST(self) -> None:
            parsed = urllib.parse.urlparse(self.path)
            body = self._read_json_body()

            if parsed.path == "/api/activate":
                ok, msg = mgr.activate_employee(
                    employee=str(body.get("employee") or ""),
                    activation_code=str(body.get("activation_code") or ""),
                    hub_url=str(body.get("hub_url") or ""),
                )
                self._send_json({"ok": ok, "message": msg, "status": mgr.get_status()})
                return

            if parsed.path == "/api/sync":
                ok, msg = mgr.sync_from_hub(strict_auth=True)
                self._send_json({"ok": ok, "message": msg, "status": mgr.get_status()})
                return

            if parsed.path == "/api/auto_check":
                res = mgr.auto_check_nodes(report_all_down=True)
                self._send_json(res)
                return

            if parsed.path == "/api/connect":
                res = mgr.connect(
                    region=str(body.get("region") or ""),
                    node_name=str(body["node_name"]) if "node_name" in body else None,
                    routing_mode=str(body.get("routing_mode") or ""),
                    tun_enabled=body.get("tun_enabled") if "tun_enabled" in body else None,
                    port_only_mode=body.get("port_only_mode") if "port_only_mode" in body else None,
                )
                self._send_json(res)
                return

            if parsed.path == "/api/disconnect":
                res = mgr.disconnect()
                self._send_json(res)
                return

            if parsed.path == "/api/select_region":
                res = mgr.switch_region(
                    region=str(body.get("region") or "⚡ 自动最快地区"),
                    node_name=str(body.get("node_name") or ""),
                )
                self._send_json(res)
                return

            if parsed.path == "/api/select_node":
                region = str(body.get("region") or mgr.profile.get("selected_region") or "⚡ 自动最快地区")
                node_name = str(body.get("node_name") or "")
                res = mgr.switch_region(region=region, node_name=node_name)
                self._send_json(res)
                return

            if parsed.path == "/api/set_mode":
                old_mode = str(mgr.profile.get("routing_mode") or "smart")
                old_tun = bool(mgr.profile.get("tun_enabled", False))
                mode = str(body.get("routing_mode") or old_mode)
                tun = bool(body.get("tun_enabled", old_tun))
                port_only = bool(body.get("port_only_mode", mgr.profile.get("port_only_mode", False)))
                mgr.profile["routing_mode"] = mode
                mgr.profile["tun_enabled"] = tun
                mgr.profile["port_only_mode"] = port_only
                mgr.save_profile()
                if mgr.engine.is_running():
                    if mode == old_mode and tun == old_tun:
                        # 仅切换系统代理/纯端口共存模式，无需重启内核，毫秒级直接生效
                        mgr.engine._port_only_mode = port_only
                        if not tun and not port_only:
                            win_proxy.set_system_proxy(mgr.engine.mixed_port, mgr.engine.snapshot_file)
                        else:
                            win_proxy.restore_system_proxy(mgr.engine.snapshot_file, self_port=mgr.engine.mixed_port)
                        self._send_json({"ok": True, "connected": True, "message": "已切换为仅端口共存模式" if port_only else "已接管系统代理"})
                    else:
                        res = mgr.connect(routing_mode=mode, tun_enabled=tun, port_only_mode=port_only)
                        self._send_json(res)
                else:
                    self._send_json({"ok": True, "message": "模式已更新"})
                return

            if parsed.path == "/api/focus_window":
                if callable(mgr._on_focus_cb):
                    try:
                        mgr._on_focus_cb()
                    except Exception:
                        pass
                self._send_json({"ok": True})
                return

            if parsed.path == "/api/network_reset":
                mgr.disconnect()
                msg = win_proxy.emergency_network_reset(mgr.engine.snapshot_file)
                self._send_json({"ok": True, "message": msg})
                return

            if parsed.path == "/api/relaunch_admin":
                ok = win_proxy.relaunch_as_admin()
                self._send_json({"ok": ok, "message": "正在请求管理员权限重启..." if ok else "未授予管理员权限"})
                return

            if parsed.path == "/api/upgrade_app":
                res = mgr.start_online_upgrade(download_url=str(body.get("download_url") or ""))
                self._send_json(res)
                return

            if parsed.path == "/api/set_autostart":
                ok_as, msg_as = mgr.set_autostart(bool(body.get("enabled", False)))
                self._send_json({"ok": ok_as, "autostart": mgr.is_autostart_enabled(), "message": msg_as})
                return

            if parsed.path == "/api/quit_app":
                def _graceful_exit() -> None:
                    time.sleep(0.25)
                    mgr.disconnect()
                    if callable(mgr._on_quit_cb):
                        try:
                            mgr._on_quit_cb()
                            return
                        except Exception:
                            pass
                    os._exit(0)

                threading.Thread(target=_graceful_exit, daemon=True).start()
                self._send_json({"ok": True, "message": "正在断开 VPN 并退出客户端..."})
                return

            self._send_json({"ok": False, "error": "Unknown endpoint"}, status=404)

    return ClientRequestHandler


class ClientServerThread:
    def __init__(self, base_dir: Path, host: str = "127.0.0.1", port: int = 18801) -> None:
        self.base_dir = base_dir
        self.host = host
        self.port = port
        self.mgr = ClientManager(base_dir)
        import sys
        meipass = getattr(sys, "_MEIPASS", None)
        self.static_dir = (Path(meipass) if meipass else base_dir) / "app" / "static"
        self._httpd: http.server.ThreadingHTTPServer | None = None
        self._thread: threading.Thread | None = None

    def start(self) -> int:
        handler_cls = create_client_handler(self.mgr, self.static_dir)
        try:
            self._httpd = http.server.ThreadingHTTPServer((self.host, self.port), handler_cls)
        except OSError:
            self._httpd = http.server.ThreadingHTTPServer((self.host, 0), handler_cls)
        self.port = self._httpd.server_address[1]
        self._thread = threading.Thread(target=self._httpd.serve_forever, daemon=True)
        self._thread.start()
        return self.port

    def stop(self) -> None:
        self.mgr._stop_watchdog.set()
        self.mgr.disconnect()
        if self._httpd:
            self._httpd.shutdown()
            self._httpd.server_close()
            self._httpd = None
