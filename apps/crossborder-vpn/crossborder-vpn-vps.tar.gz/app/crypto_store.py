"""本地加密配置存储模块（纯 Python 标准库实现，零外部依赖，零网速损耗）：
- 使用随机 16 字节盐 + SHA-256 CTR 流加密 + HMAC-SHA256 完整性校验
- 用于加密保存客户端的节点池、个人飞书 Webhook 密钥与 VPS 路由配置，防止员工或外人直接拆包看到明文节点链接
- 支持优先读取同目录 data/client_bundle.dat，若缺失则回退读取编译内置在 EXE 内部的 embedded_data/client_bundle.dat（保证飞书绑定永不丢失）
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import sys
from pathlib import Path
from typing import Any

# 编译期应用主密钥材料（与随机盐混洗生成每次加密独立的密钥流）
_APP_MASTER_KEY = b"CrossBorderVPN::ZeroPlaintext::2026::SecureBundleKey!"
_PREFIX = "CBV1:"


def _derive_keys(salt: bytes, extra_key: str = "") -> tuple[bytes, bytes]:
    material = _APP_MASTER_KEY + extra_key.encode("utf-8") + salt
    enc_key = hashlib.sha256(b"ENC|" + material).digest()
    mac_key = hashlib.sha256(b"MAC|" + material).digest()
    return enc_key, mac_key


def _ctr_xor(data: bytes, enc_key: bytes, nonce: bytes) -> bytes:
    out = bytearray(len(data))
    counter = 0
    offset = 0
    while offset < len(data):
        block = hashlib.sha256(enc_key + nonce + counter.to_bytes(4, "big")).digest()
        chunk = data[offset : offset + 32]
        for i, b in enumerate(chunk):
            out[offset + i] = b ^ block[i]
        offset += len(chunk)
        counter += 1
    return bytes(out)


def encrypt_json(obj: Any, extra_key: str = "") -> str:
    raw = json.dumps(obj, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    salt = os.urandom(16)
    enc_key, mac_key = _derive_keys(salt, extra_key=extra_key)
    cipher = _ctr_xor(raw, enc_key, salt)
    tag = hmac.new(mac_key, salt + cipher, hashlib.sha256).digest()[:16]
    blob = base64.urlsafe_b64encode(salt + tag + cipher).decode("ascii")
    return _PREFIX + blob


def decrypt_json(token: str, extra_key: str = "") -> Any:
    text = (token or "").strip()
    if not text.startswith(_PREFIX):
        raise ValueError("无效的加密配置格式")
    raw_blob = base64.urlsafe_b64decode(text[len(_PREFIX) :].encode("ascii"))
    if len(raw_blob) < 32:
        raise ValueError("加密数据包损坏")
    salt = raw_blob[:16]
    tag = raw_blob[16:32]
    cipher = raw_blob[32:]
    enc_key, mac_key = _derive_keys(salt, extra_key=extra_key)
    expected_tag = hmac.new(mac_key, salt + cipher, hashlib.sha256).digest()[:16]
    if not hmac.compare_digest(tag, expected_tag):
        raise ValueError("加密配置校验失败或已被篡改")
    plain = _ctr_xor(cipher, enc_key, salt)
    return json.loads(plain.decode("utf-8"))


def save_encrypted_file(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(encrypt_json(obj), encoding="utf-8")


def load_encrypted_file(path: Path) -> dict[str, Any] | None:
    if not path.is_file():
        return None
    try:
        content = path.read_text(encoding="utf-8").strip()
        if not content:
            return None
        if content.startswith(_PREFIX):
            data = decrypt_json(content)
        else:
            data = json.loads(content)
        return data if isinstance(data, dict) else None
    except Exception:
        return None


def get_embedded_bundle_path() -> Path | None:
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        p = Path(meipass) / "embedded_data" / "client_bundle.dat"
        if p.is_file():
            return p
    return None


def load_client_bundle(base_dir: Path) -> dict[str, Any]:
    """按优先级合并内置飞书绑定与本地加密节点缓存：
    1. 编译进 EXE 内部的 embedded_data/client_bundle.dat（保证飞书 Webhook 永不掉绑）
    2. 外部同目录 data/client_bundle.dat（加密包）
    3. 兼容同目录 data/client_bundle.json 或 data/hub_store.json（若本机刚跑过后台）
    """
    merged: dict[str, Any] = {
        "company_name": "跨境内部专线 VPN",
        "notice": "遇到连接异常系统会自动通知管理员处理",
        "hub_url": "",
        "backup_hub_urls": "",
        "discovery_url": "",
        "feishu_webhook": "",
        "feishu_secret": "",
        "nodes": [],
    }

    # 0. 最优先读取编译进 EXE 字节码内部的加密绑定配置（永不掉绑）
    try:
        from app import embedded_secrets
        tok = (getattr(embedded_secrets, "EMBEDDED_BUNDLE_TOKEN", "") or "").strip()
        if tok:
            emb_obj = decrypt_json(tok)
            if isinstance(emb_obj, dict):
                for k in ("company_name", "notice", "feishu_webhook", "feishu_secret", "backup_hub_urls", "discovery_url"):
                    if emb_obj.get(k):
                        merged[k] = emb_obj[k]
                if emb_obj.get("hub_public_url") or emb_obj.get("hub_url"):
                    merged["hub_url"] = emb_obj.get("hub_public_url") or emb_obj.get("hub_url")
                if isinstance(emb_obj.get("nodes"), list) and emb_obj["nodes"]:
                    merged["nodes"] = emb_obj["nodes"]
    except Exception:
        pass

    candidates: list[Path] = []
    emb = get_embedded_bundle_path()
    if emb is not None:
        candidates.append(emb)
    data_dir = base_dir / "data"
    candidates.extend(
        [
            data_dir / "client_bundle.dat",
            data_dir / "client_cache.dat",
            data_dir / "client_bundle.json",
            data_dir / "hub_store.json",
        ]
    )

    for cand in candidates:
        loaded = load_encrypted_file(cand)
        if not loaded:
            continue
        for k in ("company_name", "notice", "feishu_webhook", "feishu_secret", "backup_hub_urls", "discovery_url"):
            if loaded.get(k):
                merged[k] = loaded[k]
        if loaded.get("hub_public_url") or loaded.get("hub_url"):
            merged["hub_url"] = loaded.get("hub_public_url") or loaded.get("hub_url")
        if loaded.get("wiped_on_ban"):
            merged["nodes"] = []
            merged["wiped_on_ban"] = True
            break
        if "nodes" in loaded and isinstance(loaded["nodes"], list) and loaded["nodes"]:
            merged["nodes"] = loaded["nodes"]
    return merged
