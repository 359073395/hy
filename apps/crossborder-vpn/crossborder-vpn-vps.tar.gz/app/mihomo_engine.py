"""多内核协同引擎管理器 (Mihomo + Xray-core + sing-box)：
借鉴 Warp Relay Panel 最终多核架构：
- 自动识别节点协议特征，将 XTLS-Reality / XHTTP(SplitHTTP) / mKCP / QUIC / VLESS加密 等节点交由 Xray-core 桥接，
  将指定 sing-box 的节点交由 sing-box 桥接，并由 Mihomo 统一管理地区 url-test 自动容灾、分流与真连接实测。
"""

from __future__ import annotations

import base64
import collections
import concurrent.futures
import json
import os
import socket
import ssl
import stat
import subprocess
import sys
import tempfile
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Any

import yaml

from app import core_updater, node_parser, win_proxy, xray_bridge


def pick_free_port(start: int = 18200, attempts: int = 60) -> int:
    for port in range(start, start + attempts):
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            try:
                s.bind(("127.0.0.1", port))
                return port
            except OSError:
                continue
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.bind(("127.0.0.1", 0))
        return int(s.getsockname()[1])


def get_core_dir(base_dir: Path) -> Path:
    bin_name = "mihomo.exe" if sys.platform == "win32" else "mihomo"
    candidates = [
        base_dir / "core",
        base_dir / "_internal" / "core",
        Path(__file__).resolve().parent.parent / "core",
    ]
    meipass = getattr(sys, "_MEIPASS", None)
    if meipass:
        candidates.append(Path(meipass) / "core")
    for cand in candidates:
        if (cand / bin_name).exists():
            return cand
    return candidates[0]


def get_core_binary_path(base_dir: Path) -> Path:
    core_dir = get_core_dir(base_dir)
    bin_name = "mihomo.exe" if sys.platform == "win32" else "mihomo"
    candidate = core_dir / bin_name
    if sys.platform != "win32" and candidate.exists():
        try:
            st = candidate.stat().st_mode
            if not (st & stat.S_IXUSR):
                candidate.chmod(st | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        except Exception:
            pass
    return candidate


def _socks5h_http_probe(
    proxy_host: str,
    proxy_port: int,
    test_urls: tuple[str, ...],
    timeout_s: float = 6.5,
) -> tuple[int, str]:
    """通过桥接内核本地 SOCKS5h（远程 DNS 解析，与 v2rayNG 一致）直连实测 HTTP/HTTPS 延迟。"""
    last_err = "SOCKS5 探活无响应"
    for target_url in test_urls:
        parsed = urllib.parse.urlparse(target_url)
        scheme = (parsed.scheme or "http").lower()
        host = parsed.hostname or ""
        if not host:
            continue
        port = parsed.port or (443 if scheme == "https" else 80)
        req_path = parsed.path or "/"
        if parsed.query:
            req_path = f"{req_path}?{parsed.query}"

        raw_sock: socket.socket | None = None
        wrapped_sock: socket.socket | None = None
        t0 = time.perf_counter()
        try:
            raw_sock = socket.create_connection((proxy_host, proxy_port), timeout=timeout_s)
            raw_sock.settimeout(timeout_s)
            raw_sock.sendall(b"\x05\x01\x00")
            greeting = raw_sock.recv(2)
            if len(greeting) < 2 or greeting != b"\x05\x00":
                last_err = "SOCKS5 握手被拒绝"
                continue
            host_b = host.encode("utf-8")
            req_pkt = b"\x05\x01\x00\x03" + bytes([len(host_b)]) + host_b + port.to_bytes(2, "big")
            raw_sock.sendall(req_pkt)
            reply_hdr = raw_sock.recv(4)
            if len(reply_hdr) < 4 or reply_hdr[1] != 0:
                code = reply_hdr[1] if len(reply_hdr) >= 2 else -1
                last_err = f"远程拨号失败 (SOCKS5 code={code})"
                continue
            atyp = reply_hdr[3]
            if atyp == 1:
                raw_sock.recv(6)
            elif atyp == 3:
                alen = raw_sock.recv(1)
                if alen:
                    raw_sock.recv(alen[0] + 2)
            elif atyp == 4:
                raw_sock.recv(18)

            io_sock: socket.socket = raw_sock
            if scheme == "https":
                ctx = ssl.create_default_context()
                wrapped_sock = ctx.wrap_socket(raw_sock, server_hostname=host)
                io_sock = wrapped_sock

            http_req = (
                f"GET {req_path} HTTP/1.1\r\n"
                f"Host: {host}\r\n"
                "User-Agent: Mozilla/5.0\r\n"
                "Connection: close\r\n\r\n"
            ).encode("ascii")
            io_sock.sendall(http_req)
            resp_head = io_sock.recv(256).decode("latin-1", errors="ignore")
            status_line = resp_head.splitlines()[0] if resp_head else ""
            if any(f" {code}" in status_line for code in ("204", "200", "301", "302")):
                ms = max(1, int((time.perf_counter() - t0) * 1000))
                return ms, ""
            last_err = status_line or "远端返回空HTTP响应"
        except Exception as exc:
            last_err = str(exc)
        finally:
            for s in (wrapped_sock, raw_sock):
                if s is not None:
                    try:
                        s.close()
                    except Exception:
                        pass
    return -1, last_err


def _run_batch_real_delay(
    core_dir: Path,
    core_exe: Path,
    clean_nodes: list[dict[str, Any]],
    test_urls: tuple[str, ...],
    timeout_ms: int,
    force_core: str | None = None,
) -> tuple[dict[str, tuple[int, str]], dict[str, str]]:
    """启动临时多核桥接 (Xray / sing-box) + 无头 Mihomo 实例，并发测定真实代理延迟。"""
    ctrl_port = pick_free_port(19200)
    cfg = node_parser.build_mihomo_config(
        nodes=clean_nodes,
        mixed_port=0,
        controller_port=ctrl_port,
        routing_mode="global",
        tun_enabled=False,
        has_geosite=False,
        for_verify=True,
    )
    bridged_proxies, bridge_proc, core_map = xray_bridge.prepare_proxies_with_multicore(
        core_dir=core_dir,
        proxies=clean_nodes,
        pick_port_fn=pick_free_port,
        base_port=18400,
        force_core=force_core,
    )
    cfg["proxies"] = bridged_proxies
    bridge_ports: dict[str, int] = {
        str(bp.get("name") or ""): int(bp.get("port") or 0)
        for bp in bridged_proxies
        if bp.get("server") == "127.0.0.1" and bp.get("type") == "socks5" and int(bp.get("port") or 0) > 0
    }

    with tempfile.TemporaryDirectory(prefix="multicore_verify_") as tmp_dir:
        tmp_path = Path(tmp_dir)
        cfg_file = tmp_path / "verify_config.yaml"
        cfg_file.write_text(yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False), encoding="utf-8")

        creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        proc: subprocess.Popen[Any] | None = None
        try:
            if bridge_proc is not None:
                try:
                    bridge_proc.start(proxy_url=win_proxy.get_active_proxy_url())
                except Exception as exc:
                    if len(clean_nodes) > 1:
                        merged_res: dict[str, tuple[int, str]] = {}
                        merged_cores: dict[str, str] = {}
                        for single in clean_nodes:
                            s_res, s_cores = _run_batch_real_delay(
                                core_dir, core_exe, [single], test_urls, timeout_ms, force_core=force_core
                            )
                            merged_res.update(s_res)
                            merged_cores.update(s_cores)
                        return merged_res, merged_cores
                    return (
                        {str(n.get("id", "")): (-1, f"多核桥接启动异常: {exc}") for n in clean_nodes},
                        {str(n.get("id", "")): core_map.get(str(n.get("name", "")), "mihomo") for n in clean_nodes},
                    )

            proc = subprocess.Popen(
                [str(core_exe), "-d", str(core_dir), "-f", str(cfg_file)],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                creationflags=creation_flags,
            )
            win_proxy.attach_process_to_job(proc)

            opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
            ready = False
            for _ in range(100):
                if proc.poll() is not None:
                    break
                try:
                    with opener.open(f"http://127.0.0.1:{ctrl_port}/version", timeout=0.3) as resp:
                        if resp.status == 200:
                            ready = True
                            break
                except Exception:
                    time.sleep(0.03)

            if not ready:
                return (
                    {str(n.get("id", "")): (-1, "真连接测速内核启动超时") for n in clean_nodes},
                    {str(n.get("id", "")): core_map.get(str(n.get("name", "")), "mihomo") for n in clean_nodes},
                )

            def _probe_one(node_item: dict[str, Any]) -> tuple[str, int, str, str]:
                nid = str(node_item.get("id", ""))
                name = str(node_item.get("name", ""))
                used_core = core_map.get(name, "mihomo")
                quoted_name = urllib.parse.quote(name, safe="")
                local_opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
                last_err_msg = "无响应"

                if name in bridge_ports:
                    b_ms, b_err = _socks5h_http_probe(
                        "127.0.0.1",
                        bridge_ports[name],
                        test_urls,
                        timeout_s=max(3.5, timeout_ms / 1000.0),
                    )
                    if b_ms > 0:
                        return nid, b_ms, f"真连接通过 ({b_ms}ms · {used_core})", used_core
                    if b_err:
                        last_err_msg = b_err

                probe_list = test_urls[:1] if name in bridge_ports else test_urls
                for t_url in probe_list:
                    q_url = urllib.parse.quote(t_url, safe="")
                    api_url = f"http://127.0.0.1:{ctrl_port}/proxies/{quoted_name}/delay?timeout={timeout_ms}&url={q_url}"
                    req = urllib.request.Request(api_url, method="GET")
                    try:
                        with local_opener.open(req, timeout=(timeout_ms / 1000.0) + 1.5) as r:
                            data = json.loads(r.read().decode("utf-8", errors="ignore"))
                            d = int(data.get("delay", -1))
                            if d > 0:
                                return nid, d, f"真连接通过 ({d}ms · {used_core})", used_core
                            last_err_msg = str(data.get("message") or "无响应")
                    except urllib.error.HTTPError as exc:
                        try:
                            err_data = json.loads(exc.read().decode("utf-8", errors="ignore"))
                            last_err_msg = str(err_data.get("message") or exc)
                        except Exception:
                            last_err_msg = str(exc)
                    except Exception as exc:
                        last_err_msg = str(exc)

                return nid, -1, f"真连接失败 ({used_core}): {last_err_msg}", used_core

            results: dict[str, tuple[int, str]] = {}
            id_core_map: dict[str, str] = {}
            with concurrent.futures.ThreadPoolExecutor(max_workers=min(16, max(1, len(clean_nodes)))) as pool:
                for nid, delay_ms, status_msg, u_core in pool.map(_probe_one, clean_nodes):
                    results[nid] = (delay_ms, status_msg)
                    id_core_map[nid] = u_core
            return results, id_core_map
        except Exception as exc:
            return (
                {str(n.get("id", "")): (-1, f"多核桥接启动异常: {exc}") for n in clean_nodes},
                {str(n.get("id", "")): core_map.get(str(n.get("name", "")), "mihomo") for n in clean_nodes},
            )
        finally:
            if proc is not None and proc.poll() is None:
                try:
                    proc.terminate()
                    proc.wait(timeout=2)
                except Exception:
                    try:
                        proc.kill()
                    except Exception:
                        pass
            if bridge_proc is not None:
                bridge_proc.stop()


def test_nodes_real_connection(
    base_dir: Path,
    nodes: list[dict[str, Any]],
    test_url: str = "http://cp.cloudflare.com/generate_204",
    timeout_ms: int = 7000,
) -> tuple[dict[str, tuple[int, str]], dict[str, str]]:
    """多内核协同【真连接】实测（Mihomo + Xray-core + sing-box）：
    1. 同时覆盖 HTTPS (Google/gstatic 204，与 v2rayNG 一致) 与 HTTP 探测地址，按匹配内核并发测速；
    2. 对桥接内核节点额外启用 SOCKS5h 远程 DNS 探活兜底，返回 ({node_id: (delay, msg)}, {node_id: core})
    """
    if not nodes:
        return {}, {}

    core_dir = get_core_dir(base_dir)
    core_exe = get_core_binary_path(base_dir)
    if not core_exe.exists():
        return (
            {str(n.get("id", "")): (-1, f"未安装内核文件({core_exe.name})，仅完成TCP测试") for n in nodes},
            {str(n.get("id", "")): "mihomo" for n in nodes},
        )

    clean_nodes = node_parser.deduplicate_node_names(nodes)
    candidate_urls: list[str] = []
    for u in (
        "https://www.gstatic.com/generate_204",
        test_url,
        "https://www.google.com/generate_204",
    ):
        u_clean = (u or "").strip()
        if u_clean and u_clean not in candidate_urls:
            candidate_urls.append(u_clean)
    urls = tuple(candidate_urls)
    results, id_core_map = _run_batch_real_delay(core_dir, core_exe, clean_nodes, urls, timeout_ms)

    status = core_updater.get_core_status(core_dir)
    if status.get("has_xray"):
        xray_retry_nodes = []
        for n in clean_nodes:
            nid = str(n.get("id", ""))
            pref = str(n.get("preferred_core") or "auto").lower()
            r_delay, _ = results.get(nid, (-1, ""))
            if pref == "auto" and r_delay <= 0 and id_core_map.get(nid) != "xray" and node_parser.is_xray_supported_protocol(n):
                xray_retry_nodes.append(n)
        if xray_retry_nodes:
            x_res, x_cores = _run_batch_real_delay(core_dir, core_exe, xray_retry_nodes, urls, timeout_ms, force_core="xray")
            for n in xray_retry_nodes:
                nid = str(n.get("id", ""))
                d_ms, d_msg = x_res.get(nid, (-1, ""))
                if d_ms > 0:
                    results[nid] = (d_ms, d_msg)
                    id_core_map[nid] = x_cores.get(nid, "xray")

    if status.get("has_singbox"):
        sb_retry_nodes = []
        for n in clean_nodes:
            nid = str(n.get("id", ""))
            pref = str(n.get("preferred_core") or "auto").lower()
            r_delay, _ = results.get(nid, (-1, ""))
            if pref == "auto" and r_delay <= 0 and id_core_map.get(nid) != "sing-box" and node_parser.is_singbox_supported_protocol(n):
                sb_retry_nodes.append(n)
        if sb_retry_nodes:
            sb_res, sb_cores = _run_batch_real_delay(core_dir, core_exe, sb_retry_nodes, urls, timeout_ms, force_core="sing-box")
            for n in sb_retry_nodes:
                nid = str(n.get("id", ""))
                d_ms, d_msg = sb_res.get(nid, (-1, ""))
                if d_ms > 0:
                    results[nid] = (d_ms, d_msg)
                    id_core_map[nid] = sb_cores.get(nid, "sing-box")

    return results, id_core_map


class MihomoEngine:
    def __init__(
        self,
        base_dir: Path,
        mixed_port: int = 17892,
        controller_port: int = 19092,
        data_dir: Path | None = None,
    ) -> None:
        self.base_dir = base_dir
        self.core_dir = get_core_dir(base_dir)
        self.data_dir = data_dir if data_dir is not None else (base_dir / "data")
        self.data_dir.mkdir(parents=True, exist_ok=True)

        self._preferred_mixed_port = mixed_port
        self._preferred_controller_port = controller_port
        self.mixed_port = mixed_port
        self.controller_port = controller_port
        self.config_path = self.data_dir / "runtime_mihomo.yaml"
        self.snapshot_file = self.data_dir / "proxy_snapshot.json"

        self._proc: subprocess.Popen[str] | None = None
        self._bridge_proc: xray_bridge.MultiCoreBridgeProcess | None = None
        self._lock = threading.Lock()
        self._logs: collections.deque[str] = collections.deque(maxlen=150)
        self._connected_since: float | None = None
        self._selected_region: str = "⚡ 自动最快地区"
        self._routing_mode: str = "smart"
        self._tun_enabled: bool = False
        self._port_only_mode: bool = False
        self.active_core_map: dict[str, str] = {}

    @property
    def core_exe(self) -> Path:
        return get_core_binary_path(self.base_dir)

    def get_multicore_status(self) -> dict[str, Any]:
        return core_updater.get_core_status(self.core_dir)

    def is_core_ready(self) -> bool:
        return self.core_exe.exists()

    def is_running(self) -> bool:
        return self._proc is not None and self._proc.poll() is None

    def get_uptime_seconds(self) -> int:
        if not self.is_running() or not self._connected_since:
            return 0
        return max(0, int(time.time() - self._connected_since))

    def get_recent_logs(self, limit: int = 30) -> list[str]:
        return list(self._logs)[-limit:]

    def start(
        self,
        nodes: list[dict[str, Any]],
        selected_region: str = "⚡ 自动最快地区",
        routing_mode: str = "smart",
        tun_enabled: bool = False,
        port_only_mode: bool = False,
    ) -> tuple[bool, str]:
        if not nodes:
            return False, "当前暂无可用节点，请联系管理员在后台添加节点"
        if not self.is_core_ready():
            return False, f"未找到代理内核文件: {self.core_exe}"
        if tun_enabled and sys.platform == "win32" and not win_proxy.is_admin():
            return False, "开启 TUN 虚拟网卡模式需要管理员权限，请点击「以管理员身份开启 TUN」"

        self.stop()

        with self._lock:
            self._selected_region = selected_region or "⚡ 自动最快地区"
            self._routing_mode = routing_mode
            self._tun_enabled = tun_enabled
            self._port_only_mode = port_only_mode
            self.mixed_port = pick_free_port(self._preferred_mixed_port)
            ctrl_cand = pick_free_port(self._preferred_controller_port)
            if ctrl_cand == self.mixed_port:
                ctrl_cand = pick_free_port(self.mixed_port + 1)
            self.controller_port = ctrl_cand

            clean_nodes = node_parser.deduplicate_node_names(nodes)
            has_geo = (self.core_dir / "geosite.dat").exists() and (self.core_dir / "geoip.dat").exists()
            cfg = node_parser.build_mihomo_config(
                nodes=clean_nodes,
                mixed_port=self.mixed_port,
                controller_port=self.controller_port,
                routing_mode=routing_mode,
                tun_enabled=tun_enabled,
                has_geosite=has_geo,
            )

            # 核心升级：自动调用 Xray-core / sing-box 多核桥接器处理 Reality / XHTTP / mKCP / QUIC 等节点
            try:
                bridged_proxies, bridge_proc, core_map = xray_bridge.prepare_proxies_with_multicore(
                    core_dir=self.core_dir,
                    proxies=clean_nodes,
                    pick_port_fn=pick_free_port,
                    base_port=18200,
                )
                cfg["proxies"] = bridged_proxies
                self.active_core_map = core_map
                if bridge_proc is not None:
                    bridge_proc.start(proxy_url=win_proxy.get_active_proxy_url(self_port=self.mixed_port))
                    self._bridge_proc = bridge_proc
            except Exception as exc:
                self._logs.append(f"[WARN] 多核桥接回退至单核模式: {exc}")

            yaml_text = yaml.safe_dump(cfg, allow_unicode=True, sort_keys=False)
            b64_cfg = base64.b64encode(yaml_text.encode("utf-8")).decode("ascii")

            # 清理历史明文配置残留，优先通过内存 Base64 参数启动 Mihomo，做到节点配置不落地明文
            try:
                self.config_path.unlink(missing_ok=True)
            except Exception:
                pass

            use_temp_file = len(b64_cfg) > 24000
            cmd = [str(self.core_exe), "-d", str(self.core_dir)]
            if use_temp_file:
                self.config_path.write_text(yaml_text, encoding="utf-8")
                cmd.extend(["-f", str(self.config_path)])
            else:
                cmd.extend(["-config", b64_cfg])

            self._logs.clear()
            creation_flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
            try:
                self._proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    encoding="utf-8",
                    errors="replace",
                    creationflags=creation_flags,
                )
                win_proxy.attach_process_to_job(self._proc)
            except Exception as exc:
                self._proc = None
                if self._bridge_proc:
                    self._bridge_proc.stop()
                    self._bridge_proc = None
                return False, f"启动代理内核失败: {exc}"

            threading.Thread(target=self._read_stdout_loop, args=(self._proc,), daemon=True).start()

        ready = False
        for _ in range(120):
            if not self.is_running():
                break
            if self._api_request("GET", "/version", timeout=0.4) is not None:
                ready = True
                break
            time.sleep(0.025)

        # 若超长配置使用了临时文件，内核加载就绪后立即删除磁盘明文
        if use_temp_file:
            try:
                self.config_path.unlink(missing_ok=True)
            except Exception:
                pass

        if not ready or not self.is_running():
            err_tail = " | ".join(self.get_recent_logs(5))
            self.stop()
            return False, f"代理内核启动异常退出: {err_tail or '端口冲突或配置错误'}"

        self.select_region(self._selected_region)

        try:
            if not tun_enabled and not port_only_mode:
                win_proxy.set_system_proxy(self.mixed_port, self.snapshot_file)
            else:
                win_proxy.restore_system_proxy(self.snapshot_file, self_port=self.mixed_port)
        except Exception as exc:
            self._logs.append(f"[WARN] 设置系统代理异常: {exc}")

        self._connected_since = time.time()
        return True, "多核代理引擎已启动"

    def stop(self) -> None:
        with self._lock:
            proc = self._proc
            self._proc = None
            bridge = self._bridge_proc
            self._bridge_proc = None
            self._connected_since = None

        try:
            win_proxy.restore_system_proxy(self.snapshot_file, self_port=self.mixed_port)
        except Exception:
            pass

        if proc is not None and proc.poll() is None:
            try:
                proc.terminate()
                proc.wait(timeout=3)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass

        if bridge is not None:
            try:
                bridge.stop()
            except Exception:
                pass

    def _read_stdout_loop(self, proc: subprocess.Popen[str]) -> None:
        if not proc.stdout:
            return
        try:
            for line in proc.stdout:
                ln = line.strip()
                if ln:
                    self._logs.append(ln)
        except Exception:
            pass

    def _api_request(
        self,
        method: str,
        path: str,
        payload: dict[str, Any] | None = None,
        timeout: float = 4.0,
    ) -> dict[str, Any] | None:
        url = f"http://127.0.0.1:{self.controller_port}{path}"
        data = json.dumps(payload).encode("utf-8") if payload is not None else None
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"} if data else {},
            method=method,
        )
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        try:
            with opener.open(req, timeout=timeout) as resp:
                raw = resp.read().decode("utf-8", errors="ignore")
                return json.loads(raw) if raw.strip() else {}
        except Exception:
            return None

    def are_bridges_alive(self) -> bool:
        if not self.is_running():
            return False
        if self._bridge_proc is not None and not self._bridge_proc.all_alive():
            return False
        return True

    def select_region(self, target_name: str) -> bool:
        """毫秒级切换 PROXY 选中的地区策略组或具体单节点。"""
        self._selected_region = target_name
        if not self.is_running():
            return True
        res = self._api_request("PUT", "/proxies/PROXY", {"name": target_name})
        return res is not None

    def select_node_in_group(self, group_name: str, node_name: str) -> bool:
        """毫秒级将指定策略组切换到特定具体节点。"""
        if not self.is_running() or not group_name or not node_name:
            return False
        quoted = urllib.parse.quote(group_name, safe="")
        res = self._api_request("PUT", f"/proxies/{quoted}", {"name": node_name})
        return res is not None

    def get_group_candidates(self, group_name: str) -> tuple[str, list[str]]:
        """返回策略组 (当前选中节点, 候选节点列表)；若为单节点则返回 (node, [node])。"""
        if not self.is_running():
            return "", []
        data = self._api_request("GET", "/proxies", timeout=1.5)
        if not data or not isinstance(data.get("proxies"), dict):
            return "", []
        info = data["proxies"].get(group_name)
        if not isinstance(info, dict):
            return "", []
        all_items = [str(x) for x in (info.get("all") or []) if x and str(x) != "DIRECT"]
        now_item = str(info.get("now") or (all_items[0] if all_items else group_name))
        if not all_items:
            all_items = [group_name]
        return now_item, all_items

    def get_active_node_info(self) -> tuple[str, dict[str, int]]:
        """返回 (当前实际出站节点名, {节点名: 最近延迟ms})。"""
        if not self.is_running():
            return "", {}
        data = self._api_request("GET", "/proxies", timeout=1.5)
        if not data or not isinstance(data.get("proxies"), dict):
            return "", {}
        proxies = data["proxies"]
        delays: dict[str, int] = {}
        for pname, info in proxies.items():
            if not isinstance(info, dict):
                continue
            hist = info.get("history") or []
            if hist and isinstance(hist[-1], dict) and int(hist[-1].get("delay") or 0) > 0:
                delays[pname] = int(hist[-1]["delay"])

        now_target = str((proxies.get("PROXY") or {}).get("now") or "")
        # 若顶层选中的是一个策略组（如 '🇮🇩 印度尼西亚'），继续向下解析实际选中的具体节点
        for _ in range(3):
            sub = proxies.get(now_target)
            if isinstance(sub, dict) and sub.get("now"):
                now_target = str(sub["now"])
            else:
                break
        return now_target, delays

    def test_local_proxy_internet(self, timeout_sec: float = 5.0) -> tuple[bool, int]:
        """像 v2rayN 一样直接通过本机混合代理端口实测真实外网连通性，消除内核 API 偶发假超时。"""
        if not self.is_running():
            return False, -1
        proxy_url = f"http://127.0.0.1:{self.mixed_port}"
        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({"http": proxy_url, "https": proxy_url})
        )
        for u in (
            "http://cp.cloudflare.com/generate_204",
            "https://www.gstatic.com/generate_204",
            "http://www.apple.com/library/test/success.html",
        ):
            t0 = time.perf_counter()
            req = urllib.request.Request(u, headers={"User-Agent": "Mozilla/5.0"}, method="GET")
            try:
                with opener.open(req, timeout=timeout_sec) as resp:
                    if 200 <= int(getattr(resp, "status", 200)) < 400:
                        ms = max(1, int((time.perf_counter() - t0) * 1000))
                        return True, ms
            except Exception:
                continue
        return False, -1

    def test_proxy_delay(
        self,
        target_name: str,
        test_url: str = "http://cp.cloudflare.com/generate_204",
        timeout_ms: int = 6000,
        allow_mixed_fallback: bool = True,
    ) -> tuple[bool, int, str]:
        """通过多核引擎测试指定地区组或具体节点的真实外网连通性；若控制器测速偶发超时，实测本地代理端口兜底。"""
        if not self.is_running():
            return False, -1, "内核未运行"
        opener = urllib.request.build_opener(urllib.request.ProxyHandler({}))
        last_err = "外网握手超时"

        candidates_to_try = [target_name] if target_name else ["PROXY"]
        if "PROXY" not in candidates_to_try:
            candidates_to_try.append("PROXY")

        probe_urls = (
            "https://www.gstatic.com/generate_204",
            test_url,
            "https://www.google.com/generate_204",
            "http://www.apple.com/library/test/success.html",
        )
        for idx, candidate in enumerate(candidates_to_try):
            quoted = urllib.parse.quote(candidate, safe="")
            hit_404 = False
            for url_to_try in probe_urls:
                q_url = urllib.parse.quote(url_to_try, safe="")
                path = f"/proxies/{quoted}/delay?timeout={timeout_ms}&url={q_url}"
                url = f"http://127.0.0.1:{self.controller_port}{path}"
                req = urllib.request.Request(url, method="GET")
                try:
                    with opener.open(req, timeout=(timeout_ms / 1000.0) + 1.5) as resp:
                        data = json.loads(resp.read().decode("utf-8", errors="ignore"))
                        delay = int(data.get("delay", -1))
                        if delay > 0:
                            return True, delay, "真连接正常"
                        last_err = str(data.get("message") or "外网握手返回空延迟")
                except urllib.error.HTTPError as exc:
                    if exc.code == 404 and idx == 0 and len(candidates_to_try) > 1:
                        hit_404 = True
                        break
                    try:
                        err_body = json.loads(exc.read().decode("utf-8", errors="ignore"))
                        last_err = str(err_body.get("message") or exc)
                    except Exception:
                        last_err = str(exc)
                except Exception as exc:
                    last_err = str(exc)
            if not hit_404:
                break

        if allow_mixed_fallback:
            ok_mix, ms_mix = self.test_local_proxy_internet(timeout_sec=min(6.0, max(3.0, timeout_ms / 1000.0)))
            if ok_mix and ms_mix > 0:
                return True, ms_mix, "真连接正常"

        return False, -1, f"真连接握手失败 ({last_err})"
